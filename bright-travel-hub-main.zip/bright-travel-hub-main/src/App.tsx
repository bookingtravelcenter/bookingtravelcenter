import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SecurityProvider } from "@/components/SecurityProvider";
import { AuthProvider } from "@/components/AuthProvider";
import { CurrencyProvider } from "@/components/CurrencyProvider";
import { TranslationProvider } from "@/contexts/TranslationContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import PurchaseDemo from "./pages/PurchaseDemo";
import ReferralPage from "./pages/ReferralPage";
import Auth from "./pages/Auth";
import Hotels from "./pages/Hotels";
import Flights from "./pages/Flights";
import CarRental from "./pages/CarRental";
import Tours from "./pages/Tours";
import Destinations from "./pages/Destinations";
import Dashboard from "./pages/Dashboard";
import Cruises from "./pages/Cruises";
import Insurance from "./pages/Insurance";
import Activities from "./pages/Activities";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <SecurityProvider>
      <AuthProvider>
        <CurrencyProvider>
          <TranslationProvider>
            <TooltipProvider>
              <Toaster />
              <Sonner />
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/auth" element={<Auth />} />
                  <Route path="/hotels" element={<Hotels />} />
                  <Route path="/flights" element={<Flights />} />
                  <Route path="/tours" element={<Tours />} />
                  <Route path="/destinations" element={<Destinations />} />
                  <Route path="/cars" element={<CarRental />} />
                  <Route path="/cruises" element={<Cruises />} />
                  <Route path="/insurance" element={<Insurance />} />
                  <Route path="/activities" element={<Activities />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/purchase-success" element={<PurchaseDemo />} />
                  <Route path="/referrals" element={<ReferralPage />} />
                  {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </BrowserRouter>
            </TooltipProvider>
          </TranslationProvider>
        </CurrencyProvider>
      </AuthProvider>
    </SecurityProvider>
  </QueryClientProvider>
);

export default App;
