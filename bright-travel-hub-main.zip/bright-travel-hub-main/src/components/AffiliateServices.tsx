import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Car, 
  Shield, 
  Plane, 
  Ticket, 
  Package, 
  MapPin,
  Wifi,
  CreditCard,
  Navigation,
  Luggage,
  Hotel
} from "lucide-react";

const affiliateServices = [
  // Transportation
  {
    category: "Transportation",
    icon: Car,
    services: [
      { name: "🚗 Premium Car Rentals", description: "Luxury vehicles worldwide with best prices", url: "https://www.getrentacar.com", serviceIcon: Car },
      { name: "🔍 Compare Car Deals", description: "Find the best rental prices instantly", url: "https://www.qeeq.com", serviceIcon: Car },
      { name: "💰 Budget Car Rentals", description: "Affordable cars for smart travelers", url: "https://www.economybookings.com", serviceIcon: Car },
      { name: "🏪 Local Car Specialists", description: "Authentic local rental experience", url: "https://www.localrent.com", serviceIcon: MapPin },
      { name: "🚙 City to City Rides", description: "Convenient intercity transportation", url: "https://indrive.com", serviceIcon: Navigation }
    ]
  },
  // Travel Essentials
  {
    category: "Travel Essentials",
    icon: Shield,
    services: [
      { name: "🛡️ Secure Internet", description: "Protected browsing anywhere in the world", url: "https://nordvpn.com", serviceIcon: Wifi },
      { name: "📱 Global SIM Cards", description: "Stay connected across borders", url: "https://drimsim.com", serviceIcon: Wifi },
      { name: "🏥 Travel Insurance", description: "Complete protection for your journey", url: "https://ekta.io", serviceIcon: Shield },
      { name: "🧳 Luggage Storage", description: "Safe storage in 1000+ cities worldwide", url: "https://radicalstorage.com", serviceIcon: Luggage }
    ]
  },
  // Transfers & Airport Services
  {
    category: "Transfers & Airport",
    icon: Navigation,
    services: [
      { name: "✈️ Airport Transfers", description: "Premium private transfers worldwide", url: "https://gettransfer.com", serviceIcon: Navigation },
      { name: "🚕 Reliable Taxi Service", description: "Trusted transportation in 100+ countries", url: "https://kiwitaxi.com", serviceIcon: Car },
      { name: "🌟 Premium Pickups", description: "VIP airport reception services", url: "https://welcomepickups.com", serviceIcon: Navigation }
    ]
  },
  // Flight Services
  {
    category: "Flight Services",
    icon: Plane,
    services: [
      { name: "💸 Flight Compensation", description: "Get money back for delayed flights", url: "https://compensair.com", serviceIcon: CreditCard },
      { name: "⚖️ Flight Rights Expert", description: "Professional flight compensation service", url: "https://airhelp.com", serviceIcon: CreditCard },
      { name: "🤖 Smart Flight Booking", description: "AI-powered flight search and booking", url: "https://intui.travel", serviceIcon: Plane },
      { name: "💰 Travel Cashback", description: "Earn money back on every booking", url: "https://wayaway.io", serviceIcon: CreditCard }
    ]
  },
  // Accommodation
  {
    category: "Accommodation",
    icon: Hotel,
    services: [
      { name: "🏨 Hotel Deals Worldwide", description: "Best hotel prices and instant booking", url: "/hotels", serviceIcon: Hotel },
      { name: "🚢 Cruise Vacations", description: "Amazing cruise deals to destinations worldwide", url: "/cruises", serviceIcon: Package }
    ]
  },
  // Experiences & Activities
  {
    category: "Experiences",
    icon: Ticket,
    services: [
      { name: "🎯 Tours & Activities", description: "Discover unique experiences and adventures", url: "/activities", serviceIcon: Ticket },
      { name: "🎧 Audio Travel Guides", description: "Self-guided tours and experiences", url: "https://wegotrip.com", serviceIcon: Package },
      { name: "🎫 Event Tickets", description: "Sports, concerts & shows worldwide", url: "https://ticketnetwork.com", serviceIcon: Ticket },
      { name: "⛵ Boat & Yacht Rentals", description: "Explore waters with private vessels", url: "https://searadar.com", serviceIcon: Package }
    ]
  },
  // Insurance & Protection
  {
    category: "Insurance & Protection", 
    icon: Shield,
    services: [
      { name: "🛡️ Travel Insurance", description: "Comprehensive coverage for your trip", url: "/insurance", serviceIcon: Shield },
      { name: "🏥 Medical Coverage", description: "Emergency medical protection abroad", url: "/insurance", serviceIcon: Shield }
    ]
  }
];

export const AffiliateServices = () => {
const handleServiceClick = (serviceName: string, url: string) => {
    // Check if it's an internal service
    if (url.startsWith('/')) {
      window.location.href = url;
    } else {
      // Track affiliate click and redirect to external URL
      console.log(`Affiliate click: ${serviceName}`);
      window.open(url, '_blank');
    }
  };

  return (
    <section id="affiliate-services" className="py-20 bg-gradient-to-br from-background via-background/50 to-primary/5 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/3 via-transparent to-primary-glow/3 opacity-50" />
      <div className="absolute top-10 right-10 w-72 h-72 bg-gradient-to-br from-primary/10 to-primary-glow/10 rounded-full blur-3xl" />
      <div className="absolute bottom-10 left-10 w-48 h-48 bg-gradient-to-br from-primary-glow/10 to-primary/10 rounded-full blur-2xl" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold bg-gradient-to-r from-foreground via-primary to-primary-glow bg-clip-text text-transparent mb-6">
            Complete Travel Solutions
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Everything you need for your perfect trip - from flights and hotels to security, connectivity, and unforgettable experiences
          </p>
        </div>

        <div className="grid gap-8 md:gap-10">
          {affiliateServices.map((category, categoryIndex) => {
            const IconComponent = category.icon;
            return (
              <div key={category.category} className="space-y-6">
                <div className="flex items-center gap-4 mb-8">
                  <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/10 to-primary-glow/10 shadow-elegant">
                    <IconComponent className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-3xl font-bold bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">{category.category}</h3>
                </div>
                
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {category.services.map((service, serviceIndex) => (
                    <Card 
                      key={service.name} 
                      className="group hover:shadow-elegant hover:-translate-y-2 transition-all duration-500 cursor-pointer bg-gradient-to-br from-card/80 to-card/60 backdrop-blur-sm border-primary/10 hover:border-primary/30 rounded-2xl overflow-hidden"
                      onClick={() => handleServiceClick(service.name, service.url)}
                    >
                      <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-semibold text-foreground group-hover:text-primary transition-all duration-300 leading-relaxed">
                          {service.name}
                        </CardTitle>
                        <CardDescription className="text-muted-foreground leading-relaxed">
                          {service.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button 
                          className="w-full h-12 bg-gradient-to-r from-primary/5 to-primary-glow/5 border-primary/20 text-primary hover:bg-gradient-to-r hover:from-primary hover:to-primary-glow hover:text-primary-foreground hover:shadow-glow transition-all duration-500 font-semibold"
                          variant="outline"
                        >
                          Explore Service
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Enhanced Call to Action */}
        <div className="mt-20 text-center">
          <div className="bg-gradient-to-r from-primary/5 via-primary-glow/5 to-primary/5 rounded-3xl p-12 border border-primary/10 shadow-travel relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent rounded-3xl" />
            <div className="relative z-10">
              <h3 className="text-4xl font-bold bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent mb-6">
                Ready for Your Next Adventure?
              </h3>
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto text-lg leading-relaxed">
                Join thousands of travelers who trust our curated partners for their perfect trips. Every service is handpicked for quality and reliability.
              </p>
              <Button 
                size="lg" 
                className="h-14 px-10 text-lg font-semibold bg-gradient-to-r from-primary to-primary-glow hover:from-primary-dark hover:to-primary shadow-elegant hover:shadow-glow transition-all duration-500"
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              >
                Start Planning Today
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};