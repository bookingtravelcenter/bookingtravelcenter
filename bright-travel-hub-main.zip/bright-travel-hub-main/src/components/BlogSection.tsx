import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, ArrowRight } from "lucide-react";

export const BlogSection = () => {
  const blogPosts = [
    {
      id: 1,
      title: "10 Hidden Gems in Santorini You Must Visit",
      excerpt: "Discover the secret spots that locals don't want tourists to know about. From hidden beaches to ancient ruins...",
      image: "/placeholder.svg",
      category: "Destinations",
      date: "2024-01-15",
      readTime: "5 min read",
      slug: "hidden-gems-santorini"
    },
    {
      id: 2,
      title: "Travel Budget Guide: How to Save 50% on Your Next Trip",
      excerpt: "Expert tips and tricks to make your travel budget stretch further without compromising on experiences...",
      image: "/placeholder.svg", 
      category: "Travel Tips",
      date: "2024-01-12",
      readTime: "8 min read",
      slug: "travel-budget-guide"
    },
    {
      id: 3,
      title: "Best Time to Visit Japan: Seasonal Travel Guide",
      excerpt: "From cherry blossoms to autumn leaves, discover the perfect time to experience Japan's natural beauty...",
      image: "/placeholder.svg",
      category: "Destinations",
      date: "2024-01-10", 
      readTime: "6 min read",
      slug: "best-time-visit-japan"
    }
  ];

  return (
    <section className="py-20 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-hero-gradient bg-clip-text text-transparent">
            Travel Stories & Tips
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Get inspired by travel stories, expert tips, and insider guides to plan your perfect adventure
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {blogPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-travel transition-all duration-300 hover:-translate-y-1 overflow-hidden">
              <div className="relative overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <Badge className="absolute top-3 left-3 bg-primary/90 text-white">
                  {post.category}
                </Badge>
              </div>
              
              <CardHeader className="pb-3">
                <div className="flex items-center text-sm text-muted-foreground mb-2">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span className="mr-4">{new Date(post.date).toLocaleDateString()}</span>
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{post.readTime}</span>
                </div>
                <h3 className="font-semibold text-lg group-hover:text-primary transition-colors line-clamp-2">
                  {post.title}
                </h3>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-muted-foreground mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                <Button variant="ghost" className="p-0 h-auto text-primary hover:text-primary/80">
                  Read More
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button variant="outline" size="lg" className="border-primary/20 hover:border-primary/40">
            View All Articles
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};