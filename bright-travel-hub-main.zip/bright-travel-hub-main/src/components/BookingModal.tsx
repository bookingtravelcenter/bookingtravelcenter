import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, MapPin, Users, Clock } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./AuthProvider";
import { useToast } from "@/hooks/use-toast";
import { useReferralTracking } from "@/hooks/useReferralTracking";

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingType: "hotel" | "flight" | "tour" | "car_rental" | "cruise" | "activity";
  title: string;
  price?: string;
  location?: string;
}

export function BookingModal({ isOpen, onClose, bookingType, title, price, location }: BookingModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { processReferralPurchase } = useReferralTracking();
  const [loading, setLoading] = useState(false);
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [guests, setGuests] = useState("2");
  const [specialRequests, setSpecialRequests] = useState("");
  const [contactInfo, setContactInfo] = useState({
    firstName: "",
    lastName: "",
    email: user?.email || "",
    phone: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to make a booking.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const bookingData = {
        user_id: user.id,
        booking_type: bookingType,
        title,
        location: location || "",
        check_in_date: startDate?.toISOString(),
        check_out_date: endDate?.toISOString(),
        guests: parseInt(guests),
        price: price || "",
        special_requests: specialRequests,
        contact_info: contactInfo,
        status: "pending",
      };

      const { data, error } = await (supabase as any)
        .from("bookings")
        .insert(bookingData)
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Booking Submitted!",
        description: `Your booking request has been submitted. Confirmation number: ${data.confirmation_number}`,
      });

      // Process referral purchase if applicable
      if (price) {
        const priceValue = parseFloat(price.replace(/[^0-9.]/g, '')) || 0;
        if (priceValue > 0) {
          await processReferralPurchase(
            priceValue,
            bookingType,
            data.confirmation_number
          );
        }
      }

      // Reset form
      setStartDate(undefined);
      setEndDate(undefined);
      setGuests("2");
      setSpecialRequests("");
      setContactInfo({
        firstName: "",
        lastName: "",
        email: user?.email || "",
        phone: "",
      });

      onClose();
    } catch (error: any) {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getBookingTypeLabel = () => {
    switch (bookingType) {
      case "hotel": return "Hotel Reservation";
      case "flight": return "Flight Booking";
      case "tour": return "Tour Booking";
      case "car_rental": return "Car Rental";
      case "cruise": return "Cruise Booking";
      case "activity": return "Activity Booking";
      default: return "Booking";
    }
  };

  const getDateLabels = () => {
    switch (bookingType) {
      case "hotel":
        return { start: "Check-in Date", end: "Check-out Date", required: true };
      case "flight":
        return { start: "Departure Date", end: "Return Date (Optional)", required: false };
      case "tour":
        return { start: "Tour Date", end: "End Date (if multi-day)", required: false };
      case "car_rental":
        return { start: "Pickup Date", end: "Return Date", required: true };
      case "cruise":
        return { start: "Departure Date", end: "Return Date", required: true };
      case "activity":
        return { start: "Activity Date", end: "End Date (if multi-day)", required: false };
      default:
        return { start: "Start Date", end: "End Date", required: false };
    }
  };

  const renderDateFields = () => {
    const dateLabels = getDateLabels();
    
    return (
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>{dateLabels.start} *</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !startDate && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {startDate ? format(startDate, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={startDate}
                onSelect={setStartDate}
                disabled={(date) => date < new Date()}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label>{dateLabels.end} {dateLabels.required ? "*" : ""}</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !endDate && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {endDate ? format(endDate, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={endDate}
                onSelect={setEndDate}
                disabled={(date) => date < (startDate || new Date())}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[95vh] overflow-y-auto bg-gradient-to-br from-card to-card/95 backdrop-blur-xl border-primary/20 shadow-hero">
        <DialogHeader className="pb-6">
          <DialogTitle className="text-3xl font-bold flex items-center gap-3 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            <div className="p-2 rounded-full bg-gradient-to-r from-primary/10 to-primary-glow/10">
              <MapPin className="w-7 h-7 text-primary" />
            </div>
            {getBookingTypeLabel()}: {title}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Contact Information */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name *</Label>
              <Input
                id="firstName"
                value={contactInfo.firstName}
                onChange={(e) => setContactInfo({ ...contactInfo, firstName: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name *</Label>
              <Input
                id="lastName"
                value={contactInfo.lastName}
                onChange={(e) => setContactInfo({ ...contactInfo, lastName: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={contactInfo.email}
                onChange={(e) => setContactInfo({ ...contactInfo, email: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={contactInfo.phone}
                onChange={(e) => setContactInfo({ ...contactInfo, phone: e.target.value })}
              />
            </div>
          </div>

          {/* Booking Details */}
          {renderDateFields()}

          <div className="space-y-2">
            <Label htmlFor="guests">Number of Guests</Label>
            <Select value={guests} onValueChange={setGuests}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                  <SelectItem key={num} value={num.toString()}>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      {num} {num === 1 ? "Guest" : "Guests"}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {price && (
            <div className="p-6 bg-gradient-to-r from-primary/5 via-primary-glow/5 to-primary/5 rounded-2xl border border-primary/10">
              <div className="flex items-center justify-between">
                <span className="text-lg font-semibold text-muted-foreground">Total Investment:</span>
                <span className="text-3xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">{price}</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">Best price guaranteed • Free cancellation</p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="requests">Special Requests</Label>
            <Textarea
              id="requests"
              placeholder="Any special requirements or requests..."
              value={specialRequests}
              onChange={(e) => setSpecialRequests(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex gap-6 pt-6">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 h-12 text-base">
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={loading || !startDate || (getDateLabels().required && !endDate)} 
              className="flex-1 h-12 text-base bg-gradient-to-r from-primary to-primary-glow hover:from-primary-dark hover:to-primary shadow-elegant hover:shadow-glow transition-all duration-500"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 animate-spin" />
                  Processing...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span>Confirm Booking</span>
                  <span className="text-xs opacity-80">✨</span>
                </div>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}