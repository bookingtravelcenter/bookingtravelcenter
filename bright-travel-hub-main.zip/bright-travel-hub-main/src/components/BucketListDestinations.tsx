import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mountain, Plane, Star, MapPin, Calendar, Users, Heart, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useCurrency } from "./CurrencyProvider";

import heroTravelImg from "@/assets/hero-travel.jpg";
import adventureToursImg from "@/assets/adventure-tours.jpg";
import cityToursImg from "@/assets/city-tours.jpg";
import beachResortImg from "@/assets/beach-resort.jpg";
import cruiseBannerImg from "@/assets/cruise-banner.jpg";

interface BucketListDestination {
  id: string;
  name: string;
  location: string;
  category: string;
  image: string;
  description: string;
  highlights: string[];
  bestSeason: string;
  duration: string;
  difficulty: string;
  price: string;
  rating: number;
  mustDoActivities: string[];
  whyVisit: string;
}

export const BucketListDestinations = () => {
  const [loadedImages, setLoadedImages] = useState<Set<string>>(new Set());
  const { formatPrice } = useCurrency();

  const bucketListDestinations: BucketListDestination[] = [
    {
      id: "1",
      name: "Swiss Alps Sky Resort",
      location: "Zermatt, Switzerland",
      category: "Mountain Resort",
      image: heroTravelImg,
      description: "Experience luxury at 3,000 meters above sea level with breathtaking views of the Matterhorn and world-class skiing.",
      highlights: ["Matterhorn views", "Luxury spa", "Michelin dining", "Helicopter tours"],
      bestSeason: "Dec - Mar",
      duration: "5-7 days",
      difficulty: "Moderate",
      price: formatPrice(3499),
      rating: 4.9,
      mustDoActivities: ["Skiing & Snowboarding", "Alpine Spa Experience", "Helicopter Mountain Tour", "Fine Dining"],
      whyVisit: "Once-in-a-lifetime alpine luxury experience with unmatched mountain views"
    },
    {
      id: "2", 
      name: "Northern Lights Sky Lodge",
      location: "Lapland, Finland",
      category: "Arctic Experience",
      image: adventureToursImg,
      description: "Sleep under the Northern Lights in glass igloos while enjoying Arctic adventures and Sami culture.",
      highlights: ["Glass igloo rooms", "Aurora viewing", "Husky sledding", "Reindeer farm"],
      bestSeason: "Sep - Mar",
      duration: "4-6 days", 
      difficulty: "Easy",
      price: formatPrice(2899),
      rating: 4.8,
      mustDoActivities: ["Aurora Hunting", "Husky Sledding", "Ice Hotel Visit", "Sami Cultural Experience"],
      whyVisit: "Witness one of nature's most spectacular phenomena in ultimate comfort"
    },
    {
      id: "3",
      name: "Himalayan Base Camp Trek",
      location: "Everest Region, Nepal",
      category: "Adventure Trek",
      image: cityToursImg,
      description: "Journey to the base of the world's highest mountain through stunning Sherpa villages and ancient monasteries.",
      highlights: ["Everest Base Camp", "Sherpa culture", "Mountain monasteries", "Stunning vistas"],
      bestSeason: "Mar - May, Sep - Nov",
      duration: "14-16 days",
      difficulty: "Challenging", 
      price: formatPrice(2199),
      rating: 4.7,
      mustDoActivities: ["Base Camp Hiking", "Monastery Visits", "Sherpa Village Experience", "Mountain Photography"],
      whyVisit: "Ultimate adventure to the roof of the world with incredible cultural immersion"
    },
    {
      id: "4",
      name: "Maldives Overwater Resort",
      location: "Maldives Islands",
      category: "Tropical Paradise",
      image: beachResortImg,
      description: "Stay in overwater villas surrounded by crystal-clear waters and vibrant coral reefs.",
      highlights: ["Overwater villas", "Private beaches", "Coral reefs", "World-class diving"],
      bestSeason: "Nov - Apr",
      duration: "5-8 days",
      difficulty: "Easy",
      price: formatPrice(4299),
      rating: 4.9,
      mustDoActivities: ["Snorkeling & Diving", "Sunset Dolphin Cruise", "Spa Treatments", "Private Beach Dining"],
      whyVisit: "Ultimate tropical paradise experience with unparalleled luxury and marine life"
    },
    {
      id: "5",
      name: "African Safari Adventure",
      location: "Serengeti, Tanzania",
      category: "Wildlife Safari", 
      image: adventureToursImg,
      description: "Witness the Great Migration and Big Five animals in luxury tented camps across the endless plains.",
      highlights: ["Great Migration", "Big Five viewing", "Luxury camps", "Maasai culture"],
      bestSeason: "Jun - Oct",
      duration: "7-10 days",
      difficulty: "Easy",
      price: formatPrice(3799),
      rating: 4.8,
      mustDoActivities: ["Game Drives", "Hot Air Balloon Safari", "Maasai Village Visit", "Photography Safari"],
      whyVisit: "Experience the world's greatest wildlife spectacle in its natural habitat"
    },
    {
      id: "6",
      name: "Antarctic Expedition Cruise",
      location: "Antarctic Peninsula",
      category: "Polar Expedition",
      image: cruiseBannerImg,
      description: "Explore the last wilderness on Earth with wildlife encounters and dramatic icy landscapes.",
      highlights: ["Penguin colonies", "Icebergs", "Whale watching", "Research stations"],
      bestSeason: "Nov - Mar",
      duration: "10-14 days",
      difficulty: "Moderate",
      price: formatPrice(8999),
      rating: 4.9,
      mustDoActivities: ["Zodiac Landings", "Wildlife Photography", "Ice Walking", "Educational Lectures"],
      whyVisit: "Visit the most remote continent on Earth for an unparalleled wilderness experience"
    }
  ];

  const categories = [
    { name: "Mountain Resort", icon: Mountain, color: "bg-accent" },
    { name: "Arctic Experience", icon: Star, color: "bg-ocean-blue" },
    { name: "Adventure Trek", icon: Mountain, color: "bg-tropical-green" },
    { name: "Tropical Paradise", icon: Heart, color: "bg-warm-coral" },
    { name: "Wildlife Safari", icon: MapPin, color: "bg-sunset-orange" },
    { name: "Polar Expedition", icon: Plane, color: "bg-primary" }
  ];

  const handleImageLoad = (imageSrc: string) => {
    setLoadedImages(prev => new Set(prev).add(imageSrc));
  };

  useEffect(() => {
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "TravelGuide",
      "name": "Bucket List Travel Destinations",
      "description": "Must-visit destinations and experiences for the ultimate travel bucket list",
      "publisher": {
        "@type": "Organization", 
        "name": "TravelEase"
      },
      "mainEntity": bucketListDestinations.map(dest => ({
        "@type": "TouristDestination",
        "name": dest.name,
        "address": {
          "@type": "PostalAddress",
          "addressLocality": dest.location
        },
        "description": dest.description,
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": dest.rating,
          "bestRating": 5
        },
        "offers": {
          "@type": "Offer",
          "price": dest.price,
          "priceCurrency": "USD"
        }
      }))
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <section className="py-16 bg-gradient-to-b from-background to-muted">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Bucket List Destinations
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the world's most extraordinary destinations that every traveler dreams of experiencing. From sky-high mountain resorts to remote polar expeditions.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <Badge 
                key={index}
                variant="secondary"
                className="px-4 py-2 text-sm font-medium cursor-pointer hover:scale-105 transition-transform"
              >
                <IconComponent className="h-4 w-4 mr-2" />
                {category.name}
              </Badge>
            );
          })}
        </div>

        {/* Destinations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {bucketListDestinations.map((destination) => (
            <Card key={destination.id} className="group hover:shadow-travel transition-all duration-300 border-0 bg-card/90 backdrop-blur-sm overflow-hidden">
              <div className="relative">
                <div className="relative h-56 overflow-hidden">
                  {!loadedImages.has(destination.image) && (
                    <div className="absolute inset-0 bg-muted flex items-center justify-center z-10">
                      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                    </div>
                  )}
                  <img 
                    src={destination.image}
                    alt={`${destination.name} - ${destination.location}`}
                    className={`w-full h-56 object-cover group-hover:scale-105 transition-all duration-300 ${
                      loadedImages.has(destination.image) ? 'opacity-100' : 'opacity-0'
                    }`}
                    onLoad={() => handleImageLoad(destination.image)}
                    loading="lazy"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    style={{ maxWidth: '100%', height: '224px', objectFit: 'cover' }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                </div>
                <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground font-medium">
                  {destination.category}
                </Badge>
                <div className="absolute bottom-4 left-4 text-white">
                  <div className="flex items-center gap-1 mb-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium">{destination.rating}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span className="text-sm">{destination.location}</span>
                  </div>
                </div>
              </div>

              <CardHeader className="pb-3">
                <CardTitle className="text-xl text-card-foreground line-clamp-2">
                  {destination.name}
                </CardTitle>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {destination.description}
                </p>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Key Details */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3 text-accent" />
                    <span className="text-muted-foreground">{destination.bestSeason}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-3 w-3 text-accent" />
                    <span className="text-muted-foreground">{destination.duration}</span>
                  </div>
                </div>

                {/* Why Visit */}
                <div className="bg-muted/50 rounded-lg p-3">
                  <h4 className="font-medium text-card-foreground text-sm mb-1">Why Visit?</h4>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {destination.whyVisit}
                  </p>
                </div>

                {/* Highlights */}
                <div>
                  <h4 className="font-medium text-card-foreground text-sm mb-2">Highlights</h4>
                  <div className="flex flex-wrap gap-1">
                    {destination.highlights.slice(0, 3).map((highlight, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                    {destination.highlights.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{destination.highlights.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Must-Do Activities */}
                <div>
                  <h4 className="font-medium text-card-foreground text-sm mb-2">Must-Do Activities</h4>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {destination.mustDoActivities.slice(0, 2).map((activity, index) => (
                      <li key={index} className="flex items-center gap-1">
                        <div className="h-1 w-1 bg-accent rounded-full" />
                        {activity}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Price and Booking */}
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div>
                    <span className="text-2xl font-bold text-primary">{destination.price}</span>
                    <span className="text-sm text-muted-foreground">/person</span>
                    <div className="text-xs text-muted-foreground">{destination.difficulty} level</div>
                  </div>
                  <Button 
                    size="sm" 
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={() => window.open('https://hotellook.com', '_blank')}
                  >
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16 bg-hero-gradient rounded-2xl p-8 text-white">
          <h3 className="text-3xl font-bold mb-4">Ready for Your Next Adventure?</h3>
          <p className="text-lg mb-6 max-w-2xl mx-auto">
            Let our travel experts help you plan the perfect bucket list experience tailored to your dreams and preferences.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              variant="secondary" 
              className="bg-white text-primary hover:bg-white/90"
              onClick={() => window.open('https://hotellook.com', '_blank')}
            >
              Find Hotels
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white/10"
              onClick={() => window.open('https://intui.travel', '_blank')}
            >
              Book Flights
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};