import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Calendar, Trophy, Zap, Gift, Compass } from "lucide-react";
import { PopularDestinations } from "@/components/PopularDestinations";
import { BucketListDestinations } from "@/components/BucketListDestinations";
import { ToursSection } from "@/components/ToursSection";
import { SeasonalTravelGuide } from "@/components/SeasonalTravelGuide";
import { SportsTravel } from "@/components/SportsTravel";
import { LastDaysOffers } from "@/components/LastDaysOffers";
import { PromoBanners } from "@/components/PromoBanners";
import { QuickActions } from "@/components/QuickActions";
import { BlogSection } from "@/components/BlogSection";

const categories = [
  {
    id: "destinations",
    label: "Destinations",
    icon: MapPin,
    description: "Explore amazing places around the world"
  },
  {
    id: "tours",
    label: "Tours & Packages", 
    icon: Compass,
    description: "Curated travel experiences and seasonal guides"
  },
  {
    id: "sports",
    label: "Sports & Adventure",
    icon: Trophy,
    description: "Sports events and extreme adventures"
  },
  {
    id: "deals",
    label: "Deals & Offers",
    icon: Gift,
    description: "Best travel deals and promotions"
  },
  {
    id: "planning",
    label: "Travel Planning",
    icon: Calendar,
    description: "Tools and resources for your journey"
  }
];

export const CategoryTabs = () => {
  const [activeTab, setActiveTab] = useState("destinations");

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        {/* Category Navigation */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Explore by Category
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Find exactly what you're looking for with our organized travel categories
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Tab Navigation */}
          <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full h-auto p-1 bg-muted/30 backdrop-blur-sm rounded-xl mb-8">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="flex flex-col items-center gap-2 py-4 px-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-lg transition-all duration-200"
                >
                  <IconComponent className="h-5 w-5" />
                  <div className="text-center">
                    <div className="font-medium text-sm">{category.label}</div>
                    <div className="text-xs opacity-80 hidden md:block">{category.description}</div>
                  </div>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {/* Tab Content - Lazy Loaded */}
          <TabsContent value="destinations" className="space-y-0">
            {activeTab === "destinations" && (
              <>
                <PopularDestinations />
                <BucketListDestinations />
              </>
            )}
          </TabsContent>

          <TabsContent value="tours" className="space-y-0">
            {activeTab === "tours" && (
              <>
                <ToursSection />
                <SeasonalTravelGuide />
              </>
            )}
          </TabsContent>

          <TabsContent value="sports" className="space-y-0">
            {activeTab === "sports" && <SportsTravel />}
          </TabsContent>

          <TabsContent value="deals" className="space-y-0">
            {activeTab === "deals" && (
              <>
                <LastDaysOffers />
                <PromoBanners />
              </>
            )}
          </TabsContent>

          <TabsContent value="planning" className="space-y-0">
            {activeTab === "planning" && (
              <>
                <QuickActions />
                <BlogSection />
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};