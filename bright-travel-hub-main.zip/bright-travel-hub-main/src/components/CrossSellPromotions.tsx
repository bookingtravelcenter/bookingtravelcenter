import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Car, 
  Hotel, 
  Compass, 
  UtensilsCrossed, 
  Camera, 
  Shield,
  X,
  Plane,
  MapPin,
  Clock,
  Star,
  Users,
  Percent
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface CrossSellItem {
  id: string;
  category: 'hotel' | 'car' | 'tour' | 'restaurant' | 'activity' | 'insurance';
  title: string;
  description: string;
  originalPrice: string;
  salePrice: string;
  discountPercent: number;
  icon: React.ReactNode;
  image: string;
  highlights: string[];
  location?: string;
  duration?: string;
  rating?: number;
  urgencyMessage?: string;
  priority: number;
}

interface CrossSellPromotionsProps {
  isOpen: boolean;
  onClose: () => void;
  destination: string;
  bookingDate: string;
  passengerCount: number;
  bookingType: 'flight' | 'hotel' | 'car' | 'tour';
}

export const CrossSellPromotions = ({ 
  isOpen, 
  onClose, 
  destination, 
  bookingDate, 
  passengerCount,
  bookingType 
}: CrossSellPromotionsProps) => {
  const [selectedTab, setSelectedTab] = useState<'all' | 'hotel' | 'car' | 'activities'>('all');

  const getPromotionTitle = () => {
    switch (bookingType) {
      case 'flight': return `🎉 Complete Your Trip to ${destination}!`;
      case 'hotel': return `🎉 Enhance Your Stay in ${destination}!`;
      case 'car': return `🎉 Explore More in ${destination}!`;
      case 'tour': return `🎉 Discover More in ${destination}!`;
      default: return `🎉 Complete Your Trip to ${destination}!`;
    }
  };

  const getFilteredItems = (allItems: CrossSellItem[]) => {
    // Filter out the same category as the booking type
    return allItems.filter(item => {
      if (bookingType === 'flight') return true; // Show all for flights
      if (bookingType === 'hotel') return item.category !== 'hotel';
      if (bookingType === 'car') return item.category !== 'car';
      if (bookingType === 'tour') return !['tour', 'activity'].includes(item.category);
      return true;
    });
  };

  const crossSellItems: CrossSellItem[] = [
    {
      id: '1',
      category: 'hotel',
      title: `Luxury Hotels in ${destination}`,
      description: bookingType === 'flight' 
        ? 'Book your perfect accommodation with exclusive rates for flight customers'
        : 'Upgrade to luxury accommodations near your location',
      originalPrice: '$299',
      salePrice: '$199',
      discountPercent: 33,
      icon: <Hotel className="w-6 h-6" />,
      image: '🏨',
      highlights: ['Free WiFi', 'Breakfast Included', 'City Center'],
      location: destination,
      rating: 4.8,
      urgencyMessage: 'Limited rooms for your dates',
      priority: 1
    },
    {
      id: '2',
      category: 'car',
      title: 'Car Rental',
      description: 'Explore at your own pace with our premium car rental service',
      originalPrice: '$89',
      salePrice: '$59',
      discountPercent: 34,
      icon: <Car className="w-6 h-6" />,
      image: '🚗',
      highlights: ['Full Insurance', 'Free GPS', 'Unlimited Miles'],
      location: destination,
      duration: 'Per day',
      urgencyMessage: 'Book within 2 hours for this rate',
      priority: 2
    },
    {
      id: '3',
      category: 'tour',
      title: `${destination} City Tour`,
      description: 'Discover the best attractions with our expert local guides',
      originalPrice: '$149',
      salePrice: '$99',
      discountPercent: 34,
      icon: <Compass className="w-6 h-6" />,
      image: '🗺️',
      highlights: ['Expert Guide', 'Skip-the-Line', 'Small Groups'],
      location: destination,
      duration: 'Full day',
      rating: 4.9,
      priority: 3
    },
    {
      id: '4',
      category: 'restaurant',
      title: 'Fine Dining Experience',
      description: 'Reserve tables at the best restaurants in the city',
      originalPrice: '$120',
      salePrice: '$89',
      discountPercent: 26,
      icon: <UtensilsCrossed className="w-6 h-6" />,
      image: '🍽️',
      highlights: ['Michelin Rated', 'Prime Time', 'Wine Pairing'],
      location: destination,
      rating: 4.7,
      priority: 4
    },
    {
      id: '5',
      category: 'activity',
      title: 'Adventure Activities',
      description: 'Thrilling experiences and unique local adventures',
      originalPrice: '$199',
      salePrice: '$129',
      discountPercent: 35,
      icon: <Camera className="w-6 h-6" />,
      image: '🎯',
      highlights: ['Equipment Included', 'Photo Package', 'Safety Gear'],
      location: destination,
      duration: '4 hours',
      rating: 4.6,
      priority: 5
    },
    {
      id: '6',
      category: 'insurance',
      title: 'Travel Insurance',
      description: 'Protect your trip with comprehensive travel coverage',
      originalPrice: '$49',
      salePrice: '$29',
      discountPercent: 41,
      icon: <Shield className="w-6 h-6" />,
      image: '🛡️',
      highlights: ['Medical Coverage', 'Trip Cancellation', '24/7 Support'],
      urgencyMessage: 'Must purchase before departure',
      priority: 6
    }
  ];

  const availableItems = getFilteredItems(crossSellItems);
  
  const filteredItems = selectedTab === 'all' 
    ? availableItems.sort((a, b) => a.priority - b.priority)
    : availableItems.filter(item => {
        if (selectedTab === 'hotel') return item.category === 'hotel';
        if (selectedTab === 'car') return item.category === 'car';
        if (selectedTab === 'activities') return ['tour', 'activity', 'restaurant'].includes(item.category);
        return true;
      }).sort((a, b) => a.priority - b.priority);

  const tabs = [
    { id: 'all', label: 'All Offers', count: availableItems.length },
    { id: 'hotel', label: 'Hotels', count: availableItems.filter(i => i.category === 'hotel').length },
    { id: 'car', label: 'Car Rental', count: availableItems.filter(i => i.category === 'car').length },
    { id: 'activities', label: 'Activities', count: availableItems.filter(i => ['tour', 'activity', 'restaurant'].includes(i.category)).length }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="pb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 p-3 rounded-full">
                <Plane className="w-6 h-6 text-primary" />
              </div>
              <div>
                <DialogTitle className="text-2xl font-bold">
                  {getPromotionTitle()}
                </DialogTitle>
                <p className="text-muted-foreground mt-1">
                  Exclusive offers for {bookingType} customers • Save up to 40% when you book now
                </p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Trip Summary */}
          <div className="bg-primary/5 rounded-lg p-4 mt-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span>{destination}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-primary" />
                  <span>{bookingDate}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  <span>{passengerCount} {passengerCount === 1 ? 'traveler' : 'travelers'}</span>
                </div>
              </div>
              <Badge className="bg-green-100 text-green-800">
                {bookingType === 'flight' && 'Flight Confirmed ✈️'}
                {bookingType === 'hotel' && 'Hotel Confirmed 🏨'}
                {bookingType === 'car' && 'Car Confirmed 🚗'}
                {bookingType === 'tour' && 'Tour Confirmed 🗺️'}
              </Badge>
            </div>
          </div>
        </DialogHeader>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b">
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              variant={selectedTab === tab.id ? "default" : "ghost"}
              size="sm"
              onClick={() => setSelectedTab(tab.id as any)}
              className="relative"
            >
              {tab.label}
              <Badge variant="secondary" className="ml-2 text-xs">
                {tab.count}
              </Badge>
            </Button>
          ))}
        </div>

        {/* Offers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/30">
              <CardContent className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="font-bold text-lg group-hover:text-primary transition-colors">
                        {item.title}
                      </h3>
                      {item.location && (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MapPin className="w-3 h-3" />
                          <span>{item.location}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-3xl">{item.image}</div>
                </div>

                {/* Rating & Duration */}
                <div className="flex items-center gap-4 mb-3 text-sm">
                  {item.rating && (
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{item.rating}</span>
                    </div>
                  )}
                  {item.duration && (
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-primary" />
                      <span>{item.duration}</span>
                    </div>
                  )}
                </div>

                {/* Description */}
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                  {item.description}
                </p>

                {/* Highlights */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {item.highlights.map((highlight, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {highlight}
                    </Badge>
                  ))}
                </div>

                {/* Price & Urgency */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-primary">{item.salePrice}</span>
                        <span className="text-lg text-muted-foreground line-through">{item.originalPrice}</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800 mt-1">
                        <Percent className="w-3 h-3 mr-1" />
                        Save {item.discountPercent}%
                      </Badge>
                    </div>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      Add to Trip
                    </Button>
                  </div>

                  {item.urgencyMessage && (
                    <div className="text-xs text-red-600 font-medium text-center bg-red-50 p-2 rounded">
                      ⚠️ {item.urgencyMessage}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="border-t pt-6 mt-6">
          <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-lg p-6 text-center">
            <h3 className="text-xl font-bold mb-2">💎 Bundle & Save Even More!</h3>
            <p className="text-primary-foreground/80 mb-4">
              Book 3+ services together and get an additional 15% off your total
            </p>
            <div className="flex gap-3 justify-center">
              <Button variant="secondary" className="bg-white text-primary hover:bg-white/90">
                Create Custom Package
              </Button>
              <Button variant="outline" className="border-white text-white hover:bg-white/10">
                Book Selected Items
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};