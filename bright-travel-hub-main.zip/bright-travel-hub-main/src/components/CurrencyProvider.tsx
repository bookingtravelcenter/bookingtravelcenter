import React, { createContext, useContext, ReactNode } from 'react';
import { useCurrencyDetection, Currency, CurrencySymbol } from '@/hooks/useCurrencyDetection';

interface CurrencyContextType {
  currency: Currency;
  symbol: CurrencySymbol;
  country: string | null;
  loading: boolean;
  formatPrice: (amount: number) => string;
  setCurrency: (currency: Currency) => void;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const currencyData = useCurrencyDetection();

  return (
    <CurrencyContext.Provider value={currencyData}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};