import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCurrency } from './CurrencyProvider';
import { Globe } from 'lucide-react';

export const CurrencySwitcher = () => {
  const { currency, country, loading, setCurrency } = useCurrency();

  if (loading) {
    return (
      <div className="flex items-center space-x-2">
        <Globe className="h-4 w-4 animate-pulse" />
        <Badge variant="secondary" className="animate-pulse">
          Loading...
        </Badge>
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <Globe className="h-4 w-4 text-muted-foreground" />
      <div className="flex space-x-1">
        <Button
          variant={currency === 'EUR' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrency('EUR')}
          className="h-8 px-2 text-xs"
        >
          EUR €
        </Button>
        <Button
          variant={currency === 'USD' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrency('USD')}
          className="h-8 px-2 text-xs"
        >
          USD $
        </Button>
      </div>
      {country && (
        <Badge variant="outline" className="text-xs">
          {country}
        </Badge>
      )}
    </div>
  );
};