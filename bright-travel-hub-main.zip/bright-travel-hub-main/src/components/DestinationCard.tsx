import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, MapPin } from "lucide-react";
import { BookingModal } from "./BookingModal";

interface DestinationCardProps {
  image: string;
  title: string;
  location: string;
  rating: number;
  price: string;
  tag?: string;
}

export const DestinationCard = ({ 
  image, 
  title, 
  location, 
  rating, 
  price, 
  tag 
}: DestinationCardProps) => {
  const [showBookingModal, setShowBookingModal] = useState(false);

  return (
    <>
      <Card className="group cursor-pointer overflow-hidden border-0 shadow-card hover:shadow-travel transition-all duration-300 hover:-translate-y-2">
        <div className="relative overflow-hidden">
          <img 
            src={image} 
            alt={title}
            className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
          />
          {tag && (
            <Badge className="absolute top-3 left-3 bg-sunset-gradient text-white border-0 shadow-lg">
              {tag}
            </Badge>
          )}
          <div className="absolute top-3 right-3 flex items-center bg-black/20 backdrop-blur-sm rounded-full px-2 py-1">
            <Star className="h-3 w-3 text-yellow-400 fill-current mr-1" />
            <span className="text-white text-sm font-medium">{rating}</span>
          </div>
        </div>
        
        <div className="p-4">
          <div className="flex items-center text-muted-foreground mb-2">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="text-sm">{location}</span>
          </div>
          <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
            {title}
          </h3>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-2xl font-bold text-primary">{price}</span>
              <span className="text-muted-foreground text-sm ml-1">per night</span>
            </div>
          </div>
          <Button 
            variant="booking" 
            className="w-full"
            onClick={() => setShowBookingModal(true)}
          >
            Book Now
          </Button>
        </div>
      </Card>

      <BookingModal
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
        bookingType="hotel"
        title={title}
        price={price}
        location={location}
      />
    </>
  );
};