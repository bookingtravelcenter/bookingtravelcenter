import { Phone, Mail, MapPin, Clock, MessageCircle, Shield, Globe, Facebook, Twitter, Instagram, Youtube } from "lucide-react";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { useTranslation } from "@/contexts/TranslationContext";

export const Footer = () => {
  const currentYear = new Date().getFullYear();
  const { t } = useTranslation();

  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-foreground">{t('footer.companyName')}</h3>
            <p className="text-muted-foreground">
              {t('footer.companyDesc')}
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Facebook size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Twitter size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Instagram size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Youtube size={20} />
              </Button>
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-foreground">{t('footer.contactUs')}</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-muted-foreground">
                <Phone size={18} className="text-primary" />
                <div>
                  <div className="font-medium">{t('footer.support24x7')}</div>
                  <div>+1 (800) 123-4567</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 text-muted-foreground">
                <Mail size={18} className="text-primary" />
                <div>
                  <div className="font-medium">{t('footer.emailSupport')}</div>
                  <div>support@travelease.com</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 text-muted-foreground">
                <MapPin size={18} className="text-primary" />
                <div>
                  <div className="font-medium">{t('footer.headOffice')}</div>
                  <div>123 Travel Street, City, Country</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 text-muted-foreground">
                <Clock size={18} className="text-primary" />
                <div>
                  <div className="font-medium">{t('footer.businessHours')}</div>
                  <div>{t('footer.available24x7')}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Support & Help */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-foreground">{t('footer.supportHelp')}</h4>
            <div className="space-y-2">
              <a href="/help" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.helpCenter')}
              </a>
              <a href="/faq" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.faq')}
              </a>
              <a href="/booking-help" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.bookingProblems')}
              </a>
              <a href="/cancellation" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.cancellationPolicy')}
              </a>
              <a href="/payment-issues" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.paymentIssues')}
              </a>
              <a href="/travel-insurance" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.travelInsurance')}
              </a>
              <div className="pt-2">
                <Button variant="outline" size="sm" className="w-full">
                  <MessageCircle size={16} className="mr-2" />
                  {t('footer.liveChatSupport')}
                </Button>
              </div>
            </div>
          </div>

          {/* Company Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-foreground">{t('footer.aboutCompany')}</h4>
            <div className="space-y-2">
              <a href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.aboutUs')}
              </a>
              <a href="/careers" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.careers')}
              </a>
              <a href="/press" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.pressMedia')}
              </a>
              <a href="/partners" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.partnerWithUs')}
              </a>
              <a href="/referrals" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('header.earnMoney')}
              </a>
              <a href="/affiliates" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.affiliateProgram')}
              </a>
              <a href="/sustainability" className="block text-muted-foreground hover:text-primary transition-colors">
                {t('footer.sustainability')}
              </a>
            </div>
          </div>
        </div>

        <Separator className="mb-8" />

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex flex-wrap items-center space-x-6 text-sm text-muted-foreground">
            <span>© {currentYear} {t('footer.companyName')}. {t('footer.allRightsReserved')}</span>
            <a href="/privacy" className="hover:text-primary transition-colors">
              {t('footer.privacyPolicy')}
            </a>
            <a href="/terms" className="hover:text-primary transition-colors">
              {t('footer.termsOfService')}
            </a>
            <a href="/cookies" className="hover:text-primary transition-colors">
              {t('footer.cookiePolicy')}
            </a>
          </div>
          
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-2">
              <Shield size={16} className="text-primary" />
              <span>{t('footer.secureBooking')}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Globe size={16} className="text-primary" />
              <span>{t('footer.globalCoverage')}</span>
            </div>
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="mt-8 p-4 bg-muted rounded-lg">
          <div className="text-center">
            <h5 className="font-semibold text-foreground mb-2">{t('footer.emergencySupport')}</h5>
            <p className="text-sm text-muted-foreground mb-2">
              {t('footer.emergencySupportDesc')}
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-4">
              <div className="flex items-center space-x-2">
                <Phone size={16} className="text-destructive" />
                <span className="font-medium text-destructive">{t('footer.emergency')}: +1 (800) 911-HELP</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail size={16} className="text-destructive" />
                <span className="font-medium text-destructive">emergency@travelease.com</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};