import { Button } from "@/components/ui/button";
import { Menu, User, Heart, MapPin, LogOut } from "lucide-react";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { CurrencySwitcher } from "./CurrencySwitcher";
import { Link } from "react-router-dom";
import { useAuth } from "./AuthProvider";
import { useTranslation } from "@/contexts/TranslationContext";

export const Header = () => {
  const { user, signOut } = useAuth();
  const { t } = useTranslation();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <MapPin className="h-6 w-6 md:h-8 md:w-8 text-primary" />
          <span className="text-lg md:text-xl font-bold bg-hero-gradient bg-clip-text text-transparent">
            {t('header.brandName')}
          </span>
        </Link>
        
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/destinations" className="text-foreground hover:text-primary transition-colors font-medium">
            {t('header.destinations')}
          </Link>
          <Link to="/flights" className="text-foreground hover:text-primary transition-colors font-medium">
            {t('header.flights')}
          </Link>
          <Link to="/hotels" className="text-foreground hover:text-primary transition-colors font-medium">
            {t('header.hotels')}
          </Link>
          <Link to="/cars" className="text-foreground hover:text-primary transition-colors font-medium">
            {t('header.cars')}
          </Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          <CurrencySwitcher />
          <LanguageSwitcher />
          <Button variant="ghost" size="icon" className="hidden md:flex">
            <Heart className="h-5 w-5" />
          </Button>
          
          {user ? (
            <>
              <Link to="/dashboard" className="hidden md:block text-sm text-muted-foreground hover:text-primary transition-colors">
                {t('header.dashboard')}
              </Link>
              <span className="hidden md:block text-sm text-muted-foreground">
                {t('header.welcome')}, {user.email?.split('@')[0]}!
              </span>
              <Button variant="ghost" size="icon" onClick={signOut} title={t('header.signOut')}>
                <LogOut className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <>
              <Link to="/auth">
                <Button variant="ghost" size="icon" title={t('header.signIn')}>
                  <User className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/auth">
                <Button className="hidden md:flex bg-hero-gradient hover:opacity-90">
                  {t('header.signUp')}
                </Button>
              </Link>
            </>
          )}
          
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
};