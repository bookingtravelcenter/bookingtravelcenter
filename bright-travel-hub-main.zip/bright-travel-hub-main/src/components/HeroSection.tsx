import heroImage from "@/assets/hero-travel.jpg";
import { SearchSection } from "./SearchSection";

export const HeroSection = () => {
  return (
    <section className="relative h-[60vh] md:h-[80vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Enhanced Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-1000 hover:scale-105"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-black/40 via-primary/10 to-black/50" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      </div>
      
      {/* Enhanced Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-6xl mx-auto animate-fade-in">
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-4 sm:mb-6 leading-tight">
          Your Next Adventure
          <span className="bg-hero-gradient bg-clip-text text-transparent block mt-2 animate-pulse">
            Starts Here
          </span>
        </h1>
        <p className="text-lg sm:text-xl md:text-2xl text-white/95 mb-8 sm:mb-10 max-w-3xl mx-auto leading-relaxed px-4 font-light">
          Discover amazing destinations, connect with trusted travel services, and create unforgettable memories with our curated travel partners.
        </p>
        
        <SearchSection />
      </div>
    </section>
  );
};