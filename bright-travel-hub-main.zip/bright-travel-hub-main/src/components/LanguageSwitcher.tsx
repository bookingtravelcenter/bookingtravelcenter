import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTranslation, SupportedLanguage } from "@/contexts/TranslationContext";

const languages = [
  { code: 'en' as SupportedLanguage, name: 'English', flag: '🇺🇸' },
  { code: 'es' as SupportedLanguage, name: 'Español', flag: '🇪🇸' },
  { code: 'fr' as SupportedLanguage, name: 'Français', flag: '🇫🇷' },
  { code: 'de' as SupportedLanguage, name: 'Deutsch', flag: '🇩🇪' },
  { code: 'it' as SupportedLanguage, name: 'Italiano', flag: '🇮🇹' },
  { code: 'pt' as SupportedLanguage, name: 'Português', flag: '🇵🇹' },
  { code: 'ru' as SupportedLanguage, name: 'Русский', flag: '🇷🇺' },
  { code: 'zh' as SupportedLanguage, name: '中文', flag: '🇨🇳' },
  { code: 'ja' as SupportedLanguage, name: '日本語', flag: '🇯🇵' },
  { code: 'ko' as SupportedLanguage, name: '한국어', flag: '🇰🇷' },
  { code: 'ar' as SupportedLanguage, name: 'العربية', flag: '🇸🇦' },
  { code: 'hi' as SupportedLanguage, name: 'हिन्दी', flag: '🇮🇳' },
  { code: 'el' as SupportedLanguage, name: 'Ελληνικά', flag: '🇬🇷' },
];

export const LanguageSwitcher = () => {
  const { currentLanguage, setLanguage } = useTranslation();
  const currentLang = languages.find(lang => lang.code === currentLanguage) || languages[0];

  const handleLanguageChange = (language: typeof languages[0]) => {
    setLanguage(language.code);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <Globe className="h-4 w-4" />
          <span className="hidden sm:inline">{currentLang.flag} {currentLang.name}</span>
          <span className="sm:hidden">{currentLang.flag}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48 bg-popover border border-border shadow-lg z-50">
        {languages.map((language) => (
          <DropdownMenuItem
            key={language.code}
            onClick={() => handleLanguageChange(language)}
            className={cn(
              "cursor-pointer hover:bg-accent hover:text-accent-foreground",
              currentLang.code === language.code && "bg-accent/50"
            )}
          >
            <span className="mr-2">{language.flag}</span>
            {language.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};