import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, Users, Calendar, AlertTriangle, Zap } from "lucide-react";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface LastDayOffer {
  id: string;
  destination: string;
  location: string;
  originalPrice: string;
  salePrice: string;
  discountPercent: number;
  expiresAt: Date;
  spotsLeft: number;
  duration: string;
  type: string;
  highlights: string[];
  image: string;
}

export const LastDaysOffers = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const calculateTimeLeft = (expiresAt: Date): TimeLeft => {
    const difference = expiresAt.getTime() - currentTime.getTime();
    
    if (difference > 0) {
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      };
    }
    
    return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  };

  const lastDayOffers: LastDayOffer[] = [
    {
      id: "1",
      destination: "Luxury Maldives Resort",
      location: "Maldives",
      originalPrice: "$3,999",
      salePrice: "$1,999",
      discountPercent: 50,
      expiresAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      spotsLeft: 3,
      duration: "7 Days",
      type: "Beach Resort",
      highlights: ["Overwater Villa", "All Inclusive", "Spa Access"],
      image: "🏝️"
    },
    {
      id: "2",
      destination: "Swiss Alps Adventure",
      location: "Switzerland",
      originalPrice: "$2,299",
      salePrice: "$1,149",
      discountPercent: 50,
      expiresAt: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
      spotsLeft: 1,
      duration: "5 Days",
      type: "Mountain Adventure",
      highlights: ["Skiing", "Mountain Lodge", "Equipment Included"],
      image: "🏔️"
    },
    {
      id: "3",
      destination: "Rome & Florence Tour",
      location: "Italy",
      originalPrice: "$1,599",
      salePrice: "$799",
      discountPercent: 50,
      expiresAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      spotsLeft: 5,
      duration: "6 Days",
      type: "Cultural Tour",
      highlights: ["Expert Guide", "Museum Pass", "Historic Hotels"],
      image: "🏛️"
    }
  ];

  const CountdownTimer = ({ expiresAt }: { expiresAt: Date }) => {
    const timeLeft = calculateTimeLeft(expiresAt);
    
    return (
      <div className="flex gap-2 justify-center">
        {Object.entries(timeLeft).map(([unit, value]) => (
          <div key={unit} className="text-center">
            <div className="bg-red-600 text-white px-2 py-1 rounded font-bold text-lg min-w-[40px]">
              {value.toString().padStart(2, '0')}
            </div>
            <div className="text-xs text-red-600 font-medium mt-1 capitalize">
              {unit.slice(0, -1)}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <section className="py-20 px-4 bg-gradient-to-br from-red-50 via-background to-red-50 dark:from-red-950/20 dark:via-background dark:to-red-950/20">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <AlertTriangle className="w-8 h-8 text-red-500 animate-pulse" />
            <Badge className="bg-red-500 text-white px-4 py-1 text-lg animate-pulse">
              LAST DAYS
            </Badge>
            <AlertTriangle className="w-8 h-8 text-red-500 animate-pulse" />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-red-600 dark:text-red-400">
            ⏰ Last Days Offers!
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            These incredible deals are expiring soon! Don't miss your chance to save big on premium travel experiences.
          </p>
        </div>

        {/* Urgent Banner */}
        <div className="bg-gradient-to-r from-red-500 to-red-600 text-white p-6 rounded-lg mb-12 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Zap className="w-6 h-6 animate-pulse" />
            <span className="text-xl font-bold">URGENT: Limited Time & Spots Available!</span>
            <Zap className="w-6 h-6 animate-pulse" />
          </div>
          <p className="text-red-100">Book now or lose these deals forever. Some offers have only hours left!</p>
        </div>

        {/* Last Day Offers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {lastDayOffers.map((offer) => {
            const timeLeft = calculateTimeLeft(offer.expiresAt);
            const isUrgent = timeLeft.days === 0 && timeLeft.hours < 12;
            
            return (
              <Card 
                key={offer.id} 
                className={`group overflow-hidden border-2 transition-all duration-300 hover:shadow-xl ${
                  isUrgent ? 'border-red-500 animate-pulse' : 'border-red-300'
                }`}
              >
                {/* Urgent Header */}
                {isUrgent && (
                  <div className="bg-red-500 text-white text-center py-2 font-bold text-sm">
                    🚨 EXPIRES TODAY! 🚨
                  </div>
                )}
                
                <CardContent className="p-6">
                  {/* Offer Header */}
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-2">{offer.image}</div>
                    <h3 className="text-xl font-bold mb-1">{offer.destination}</h3>
                    <div className="flex items-center justify-center gap-1 text-muted-foreground text-sm">
                      <MapPin className="w-4 h-4" />
                      <span>{offer.location}</span>
                    </div>
                  </div>

                  {/* Countdown Timer */}
                  <div className="mb-4">
                    <div className="text-center mb-2">
                      <span className="text-sm font-medium text-red-600">Expires in:</span>
                    </div>
                    <CountdownTimer expiresAt={offer.expiresAt} />
                  </div>

                  {/* Price & Discount */}
                  <div className="text-center mb-4">
                    <div className="mb-2">
                      <span className="text-3xl font-bold text-red-600">{offer.salePrice}</span>
                      <span className="text-lg text-muted-foreground line-through ml-2">{offer.originalPrice}</span>
                    </div>
                    <Badge className="bg-red-500 text-white text-lg px-3 py-1">
                      SAVE {offer.discountPercent}%
                    </Badge>
                  </div>

                  {/* Availability Warning */}
                  <div className="text-center mb-4">
                    <div className={`text-sm font-medium ${
                      offer.spotsLeft <= 2 ? 'text-red-600' : 'text-orange-600'
                    }`}>
                      <Users className="w-4 h-4 inline mr-1" />
                      Only {offer.spotsLeft} spots left!
                    </div>
                  </div>

                  {/* Details */}
                  <div className="space-y-2 mb-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-primary" />
                      <span>{offer.duration} • {offer.type}</span>
                    </div>
                  </div>

                  {/* Highlights */}
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1">
                      {offer.highlights.map((highlight, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* CTA Button */}
                  <Button 
                    className={`w-full text-lg py-3 ${
                      isUrgent 
                        ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
                        : 'bg-red-500 hover:bg-red-600'
                    } text-white`}
                  >
                    {isUrgent ? '🔥 BOOK NOW!' : 'Secure This Deal'}
                  </Button>
                  
                  <p className="text-xs text-center text-muted-foreground mt-2">
                    Free cancellation until 24h before departure
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0 inline-block">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-2">Don't Wait! These Deals Won't Last!</h3>
              <p className="mb-4 text-red-100">Join thousands of travelers who saved big with our last-minute offers</p>
              <Button variant="secondary" size="lg" className="bg-white text-red-600 hover:bg-red-50">
                <Clock className="w-5 h-5 mr-2" />
                View All Expiring Deals
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};