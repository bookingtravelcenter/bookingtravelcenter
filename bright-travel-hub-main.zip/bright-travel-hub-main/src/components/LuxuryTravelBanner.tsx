import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Plane, Car, MapPin } from "lucide-react";
import luxuryHotel from "@/assets/luxury-hotel.jpg";
import luxuryCars from "@/assets/luxury-cars.jpg";
import luxuryHelicopter from "@/assets/luxury-helicopter.jpg";
import privateJet from "@/assets/private-jet.jpg";

const LuxuryTravelBanner = () => {
  const luxuryOffers = [
    {
      id: 1,
      image: luxuryHotel,
      title: "7-Star Paradise Resort",
      location: "Maldives",
      price: "$15,000",
      period: "per night",
      category: "Ultra Luxury Hotel",
      rating: 7,
      highlights: ["Private Island", "Butler Service", "Underwater Suite"]
    },
    {
      id: 2,
      image: luxuryCars,
      title: "Bugatti Chiron Collection",
      location: "Monaco",
      price: "$8,500",
      period: "per day",
      category: "Supercar Rental",
      rating: 5,
      highlights: ["1500HP", "Limited Edition", "Chauffeur Available"]
    },
    {
      id: 3,
      image: luxuryHelicopter,
      title: "Private Helicopter Tours",
      location: "Swiss Alps",
      price: "$25,000",
      period: "per tour",
      category: "Helicopter Charter",
      rating: 5,
      highlights: ["Glacier Landing", "Champagne Service", "Professional Pilot"]
    },
    {
      id: 4,
      image: privateJet,
      title: "Gulfstream G650 Charter",
      location: "Worldwide",
      price: "$45,000",
      period: "per flight",
      category: "Private Jet",
      rating: 5,
      highlights: ["14 Passengers", "Global Range", "Luxury Interior"]
    }
  ];

  return (
    <section className="py-12 px-4 bg-gradient-to-br from-background via-background to-accent/5">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <Badge variant="secondary" className="mb-3 text-sm font-medium">
            ULTRA LUXURY COLLECTION
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            The World's Most Exclusive Experiences
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Indulge in the pinnacle of luxury travel. From 7-star resorts to private jets, 
            experience the extraordinary with our curated collection.
          </p>
        </div>

        {/* Luxury Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {luxuryOffers.map((offer) => (
            <Card key={offer.id} className="group hover:shadow-2xl transition-all duration-500 overflow-hidden border-0 bg-gradient-to-b from-card to-card/50">
              <div className="relative overflow-hidden">
                <img
                  src={offer.image}
                  alt={offer.title}
                  className="w-full h-48 object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                  sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 25vw"
                  style={{ maxWidth: '100%', height: '192px', objectFit: 'cover' }}
                />
                <div className="absolute top-4 left-4">
                  <Badge variant="secondary" className="bg-background/90 backdrop-blur-sm">
                    {offer.category}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4 flex items-center gap-1 bg-background/90 backdrop-blur-sm rounded-full px-2 py-1">
                  {[...Array(offer.rating)].map((_, i) => (
                    <Star key={i} className="h-3 w-3 fill-primary text-primary" />
                  ))}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>
              
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="text-sm text-muted-foreground">{offer.location}</span>
                </div>
                
                <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">
                  {offer.title}
                </h3>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {offer.highlights.map((highlight, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {highlight}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-2xl font-bold text-primary">{offer.price}</span>
                    <span className="text-sm text-muted-foreground ml-1">{offer.period}</span>
                  </div>
                </div>
                
                <Button className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 transition-all duration-300">
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 rounded-3xl p-8">
          <h3 className="text-2xl font-bold mb-3">Ready for the Ultimate Luxury Experience?</h3>
          <p className="text-base text-muted-foreground mb-6 max-w-xl mx-auto">
            Our luxury concierge team is available 24/7 to craft your perfect bespoke experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 px-8">
              <Plane className="mr-2 h-5 w-5" />
              Contact Luxury Concierge
            </Button>
            <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8">
              <Car className="mr-2 h-5 w-5" />
              View All Luxury Options
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LuxuryTravelBanner;