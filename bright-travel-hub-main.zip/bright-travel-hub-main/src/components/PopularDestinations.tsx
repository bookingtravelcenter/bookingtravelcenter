import santoriniImage from "@/assets/santorini.jpg";
import tokyoImage from "@/assets/tokyo.jpg";
import parisImage from "@/assets/paris.jpg";
import { DestinationCard } from "./DestinationCard";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";
import { useCurrency } from "./CurrencyProvider";
import { useTranslation } from "@/contexts/TranslationContext";

export const PopularDestinations = () => {
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();
  
  const destinations = [
    {
      image: santoriniImage,
      title: "Luxury Villa with Ocean View",
      location: "Santorini, Greece",
      rating: 4.9,
      price: formatPrice(299),
      tag: "Popular",
      seoData: {
        city: "Santorini",
        country: "Greece",
        type: "luxury villa",
        amenities: ["ocean view", "private pool", "sunset terrace"]
      }
    },
    {
      image: tokyoImage,
      title: "Modern City Apartment",
      location: "Tokyo, Japan",
      rating: 4.8,
      price: formatPrice(189),
      tag: "Hot Deal",
      seoData: {
        city: "Tokyo",
        country: "Japan",
        type: "city apartment",
        amenities: ["modern design", "city center", "metro access"]
      }
    },
    {
      image: parisImage,
      title: "Romantic Penthouse Suite",
      location: "Paris, France",
      rating: 4.9,
      price: formatPrice(349),
      seoData: {
        city: "Paris",
        country: "France",
        type: "penthouse suite",
        amenities: ["romantic setting", "eiffel tower view", "luxury amenities"]
      }
    }
  ];

  useEffect(() => {
    // Add structured data for SEO
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "name": "Popular Travel Destinations",
      "description": "Most sought-after travel destinations with luxury accommodations",
      "itemListElement": destinations.map((dest, index) => ({
        "@type": "TravelAgency",
        "position": index + 1,
        "name": dest.title,
        "description": `${dest.seoData.type} in ${dest.location}`,
        "address": {
          "@type": "PostalAddress",
          "addressLocality": dest.seoData.city,
          "addressCountry": dest.seoData.country
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": dest.rating,
          "ratingCount": "100+"
        },
        "priceRange": dest.price,
        "amenityFeature": dest.seoData.amenities.map(amenity => ({
          "@type": "LocationFeatureSpecification",
          "name": amenity
        }))
      }))
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(structuredData);
    document.head.appendChild(script);

    return () => {
      const existingScript = document.querySelector('script[type="application/ld+json"]');
      if (existingScript) {
        document.head.removeChild(existingScript);
      }
    };
  }, []);

  return (
    <section 
      className="py-20 px-4 bg-background" 
      itemScope 
      itemType="https://schema.org/TravelAgency"
      role="region"
      aria-labelledby="popular-destinations-heading"
    >
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-16">
          <h2 
            id="popular-destinations-heading"
            className="text-4xl md:text-5xl font-bold mb-6 bg-hero-gradient bg-clip-text text-transparent"
            itemProp="name"
          >
            {t('destinations.popularTitle')}
          </h2>
          <p 
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
            itemProp="description"
          >
            {t('destinations.popularSubtitle')}
          </p>
        </header>
        
        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          role="list"
          aria-label="Popular travel destinations"
        >
          {destinations.map((destination, index) => (
            <div key={index} role="listitem">
              <DestinationCard
                {...destination}
              />
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/5 via-primary-glow/5 to-primary/5 rounded-3xl p-12 border border-primary/10">
            <h3 className="text-3xl font-bold mb-4">{t('destinations.readyToBook')}</h3>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              {t('destinations.readyToBookDesc')}
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                size="lg"
                onClick={() => window.open('https://hotellook.com', '_blank')}
              >
                {t('destinations.findHotels')}
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => window.open('https://intui.travel', '_blank')}
              >
                {t('destinations.bookFlights')}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};