import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plane, MapPin, Calendar, Gift, Percent, Clock } from "lucide-react";

export const PromoBanners = () => {
  const promoOffers = [
    {
      icon: <Plane className="w-8 h-8" />,
      title: "Last Minute Deals",
      subtitle: "Save up to 60% on flights",
      description: "Book within 48 hours and save big on premium destinations",
      discount: "60% OFF",
      cta: "Book Now",
      gradient: "from-blue-500 to-cyan-400",
      urgent: true
    },
    {
      icon: <MapPin className="w-8 h-8" />,
      title: "Weekend Getaways",
      subtitle: "Perfect short escapes",
      description: "Discover amazing destinations just a few hours away",
      discount: "25% OFF",
      cta: "Explore",
      gradient: "from-green-500 to-emerald-400",
      urgent: false
    },
    {
      icon: <Calendar className="w-8 h-8" />,
      title: "Early Bird Special",
      subtitle: "Plan ahead and save",
      description: "Book 3 months in advance for exclusive discounts",
      discount: "35% OFF",
      cta: "Plan Trip",
      gradient: "from-purple-500 to-pink-400",
      urgent: false
    },
    {
      icon: <Gift className="w-8 h-8" />,
      title: "Honeymoon Packages",
      subtitle: "Romantic getaways",
      description: "Special packages for couples with luxury amenities",
      discount: "FREE Upgrade",
      cta: "See Packages",
      gradient: "from-rose-500 to-pink-400",
      urgent: false
    }
  ];

  const quickDeals = [
    {
      destination: "Bali, Indonesia",
      originalPrice: "$899",
      salePrice: "$599",
      savings: "Save $300",
      timeLeft: "2 days left",
      image: "🏝️"
    },
    {
      destination: "Rome, Italy",
      originalPrice: "$1299",
      salePrice: "$899",
      savings: "Save $400",
      timeLeft: "5 days left",
      image: "🏛️"
    },
    {
      destination: "Tokyo, Japan",
      originalPrice: "$1599",
      salePrice: "$1199",
      savings: "Save $400",
      timeLeft: "1 week left",
      image: "🗾"
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-r from-primary/10 via-background to-secondary/10">
      <div className="max-w-7xl mx-auto">
        {/* Main Promo Banners */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {promoOffers.map((offer, index) => (
            <Card key={index} className="group relative overflow-hidden border-0 bg-gradient-to-br hover:shadow-elegant transition-all duration-300">
              <div className={`absolute inset-0 bg-gradient-to-br ${offer.gradient} opacity-90`} />
              <CardContent className="relative p-6 text-white">
                {offer.urgent && (
                  <Badge className="absolute top-2 right-2 bg-red-500 text-white animate-pulse">
                    <Clock className="w-3 h-3 mr-1" />
                    URGENT
                  </Badge>
                )}
                
                <div className="mb-4 opacity-80">
                  {offer.icon}
                </div>
                
                <div className="mb-2">
                  <div className="text-2xl font-bold text-white/90 mb-1">
                    {offer.discount}
                  </div>
                  <h3 className="text-xl font-bold mb-1">{offer.title}</h3>
                  <p className="text-white/80 text-sm font-medium">{offer.subtitle}</p>
                </div>
                
                <p className="text-white/70 text-sm mb-4 line-clamp-2">
                  {offer.description}
                </p>
                
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="w-full bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm"
                >
                  {offer.cta}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Flash Deals Section */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-4 bg-hero-gradient bg-clip-text text-transparent">
              ⚡ Flash Deals - Limited Time Only!
            </h3>
            <p className="text-muted-foreground">Grab these incredible offers before they're gone</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickDeals.map((deal, index) => (
              <Card key={index} className="group overflow-hidden hover:shadow-elegant transition-all duration-300 border-primary/20">
                <CardContent className="p-6">
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-2">{deal.image}</div>
                    <h4 className="text-lg font-bold">{deal.destination}</h4>
                  </div>
                  
                  <div className="text-center mb-4">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <span className="text-2xl font-bold text-primary">{deal.salePrice}</span>
                      <span className="text-lg text-muted-foreground line-through">{deal.originalPrice}</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {deal.savings}
                    </Badge>
                  </div>
                  
                  <div className="text-center mb-4">
                    <div className="flex items-center justify-center gap-1 text-red-600 text-sm font-medium">
                      <Clock className="w-4 h-4" />
                      {deal.timeLeft}
                    </div>
                  </div>
                  
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    Book This Deal
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Newsletter Signup Banner */}
        <Card className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground border-0">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              🎯 Never Miss a Deal Again!
            </h3>
            <p className="text-primary-foreground/80 mb-6 max-w-2xl mx-auto">
              Subscribe to our newsletter and be the first to know about exclusive offers, flash sales, and travel inspiration.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 rounded-lg text-foreground bg-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <Button variant="secondary" className="bg-white text-primary hover:bg-white/90">
                Subscribe Now
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};