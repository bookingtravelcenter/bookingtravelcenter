import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CrossSellPromotions } from "./CrossSellPromotions";
import { ReferralPromotionBanner } from "./ReferralPromotionBanner";
import { 
  CheckCircle, 
  Plane, 
  MapPin, 
  Calendar, 
  Users, 
  Clock,
  Download,
  Share2,
  Star,
  Gift
} from "lucide-react";
import { useReferralTracking } from "@/hooks/useReferralTracking";

interface PurchaseSuccessPageProps {
  bookingData: {
    confirmationNumber: string;
    destination: string;
    departureDate: string;
    returnDate?: string;
    passengers: number;
    totalAmount: string;
    bookingType: 'flight' | 'hotel' | 'car' | 'tour';
    // Flight specific
    airline?: string;
    flightNumber?: string;
    // Hotel specific
    hotelName?: string;
    roomType?: string;
    // Car specific
    carModel?: string;
    pickupLocation?: string;
  };
}

export const PurchaseSuccessPage = ({ bookingData }: PurchaseSuccessPageProps) => {
  const [showCrossSell, setShowCrossSell] = useState(false);
  const [showCrossSellTimer, setShowCrossSellTimer] = useState(10);
  const [showReferralPromo, setShowReferralPromo] = useState(false);
  const { processReferralPurchase } = useReferralTracking();

  // Auto-show cross-sell after a few seconds, then referral promo
  useEffect(() => {
    const timer = setInterval(() => {
      setShowCrossSellTimer(prev => {
        if (prev <= 1) {
          setShowCrossSell(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Show referral promotion after cross-sell is closed
  useEffect(() => {
    if (!showCrossSell && showCrossSellTimer === 0) {
      const referralTimer = setTimeout(() => {
        setShowReferralPromo(true);
      }, 3000); // Show referral promo 3 seconds after cross-sell is closed

      return () => clearTimeout(referralTimer);
    }
  }, [showCrossSell, showCrossSellTimer]);

  // Process referral purchase on component mount
  useEffect(() => {
    const handleReferralPurchase = async () => {
      const amount = parseFloat(bookingData.totalAmount.replace(/[^0-9.]/g, ''));
      await processReferralPurchase(
        amount,
        bookingData.bookingType,
        bookingData.confirmationNumber
      );
    };

    handleReferralPurchase();
  }, [bookingData, processReferralPurchase]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-background to-primary/5 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Success Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-green-600 mb-4">
            🎉 Booking Confirmed!
          </h1>
          <p className="text-xl text-muted-foreground">
            Your {bookingData.bookingType} has been successfully booked. Get ready for an amazing trip!
          </p>
        </div>

        {/* Booking Details Card */}
        <Card className="mb-8 border-green-200 bg-green-50/50">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">
                {bookingData.bookingType === 'flight' && 'Flight Details'}
                {bookingData.bookingType === 'hotel' && 'Hotel Details'}
                {bookingData.bookingType === 'car' && 'Car Rental Details'}
                {bookingData.bookingType === 'tour' && 'Tour Details'}
              </h2>
              <Badge className="bg-green-600 text-white text-lg px-4 py-2">
                Confirmed
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-4">
                {bookingData.bookingType === 'flight' && bookingData.airline && bookingData.flightNumber && (
                  <div className="flex items-center gap-3">
                    <Plane className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Flight</p>
                      <p className="font-semibold">{bookingData.airline} {bookingData.flightNumber}</p>
                    </div>
                  </div>
                )}
                {bookingData.bookingType === 'hotel' && bookingData.hotelName && (
                  <div className="flex items-center gap-3">
                    <Plane className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Hotel</p>
                      <p className="font-semibold">{bookingData.hotelName}</p>
                    </div>
                  </div>
                )}
                {bookingData.bookingType === 'car' && bookingData.carModel && (
                  <div className="flex items-center gap-3">
                    <Plane className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Vehicle</p>
                      <p className="font-semibold">{bookingData.carModel}</p>
                    </div>
                  </div>
                )}
                
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Destination</p>
                    <p className="font-semibold">{bookingData.destination}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Passengers</p>
                    <p className="font-semibold">{bookingData.passengers} {bookingData.passengers === 1 ? 'traveler' : 'travelers'}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Departure</p>
                    <p className="font-semibold">{bookingData.departureDate}</p>
                  </div>
                </div>
                
                {bookingData.returnDate && (
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Return</p>
                      <p className="font-semibold">{bookingData.returnDate}</p>
                    </div>
                  </div>
                )}
                
                <div className="bg-primary/10 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground">Confirmation Number</p>
                  <p className="text-2xl font-bold text-primary font-mono">
                    {bookingData.confirmationNumber}
                  </p>
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Amount Paid</p>
                  <p className="text-3xl font-bold text-primary">{bookingData.totalAmount}</p>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download Ticket
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cross-sell Teaser */}
        <Card className="mb-8 bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <Gift className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Complete Your Perfect Trip!</h3>
                  <p className="text-muted-foreground">
                    Exclusive offers on hotels, car rentals, and activities in {bookingData.destination}
                  </p>
                </div>
              </div>
              <div className="text-center">
                {showCrossSellTimer > 0 ? (
                  <div>
                    <div className="text-2xl font-bold text-primary">{showCrossSellTimer}</div>
                    <div className="text-xs text-muted-foreground">Auto-opening...</div>
                  </div>
                ) : (
                  <Button 
                    onClick={() => setShowCrossSell(true)}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    View Offers
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-all duration-300 group cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-bold mb-2">Check-in Online</h3>
              <p className="text-sm text-muted-foreground">Available 24 hours before departure</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-all duration-300 group cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-200 transition-colors">
                <MapPin className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-bold mb-2">Destination Guide</h3>
              <p className="text-sm text-muted-foreground">Discover what to do in {bookingData.destination}</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-all duration-300 group cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                <Star className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-bold mb-2">Rate Your Experience</h3>
              <p className="text-sm text-muted-foreground">Help us improve our service</p>
            </CardContent>
          </Card>
        </div>

        {/* Important Information */}
        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-6">
            <h3 className="text-lg font-bold mb-4 text-yellow-800">Important Information</h3>
            <div className="space-y-2 text-sm text-yellow-700">
              <p>• Please arrive at the airport at least 2 hours before domestic flights, 3 hours for international</p>
              <p>• Check your passport validity and visa requirements for your destination</p>
              <p>• Review your airline's baggage policy and restrictions</p>
              <p>• Consider travel insurance for additional protection</p>
            </div>
          </CardContent>
        </Card>

        {/* Cross-sell Modal */}
        <CrossSellPromotions
          isOpen={showCrossSell}
          onClose={() => setShowCrossSell(false)}
          destination={bookingData.destination}
          bookingDate={bookingData.departureDate}
          passengerCount={bookingData.passengers}
          bookingType={bookingData.bookingType}
        />

        {/* Referral Promotion Banner */}
        <ReferralPromotionBanner
          isOpen={showReferralPromo}
          onClose={() => setShowReferralPromo(false)}
          bookingType={bookingData.bookingType}
          destination={bookingData.destination}
          bookingAmount={bookingData.totalAmount}
        />
      </div>
    </div>
  );
};