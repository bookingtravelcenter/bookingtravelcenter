import { Plane, Building, Car, MapPin, Calendar, CreditCard } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const QuickActions = () => {
  const actions = [
    {
      icon: Plane,
      title: "Flights",
      description: "Find the best deals on flights worldwide",
      color: "bg-sky-gradient"
    },
    {
      icon: Building,
      title: "Hotels",
      description: "Book amazing accommodations anywhere",
      color: "bg-sunset-gradient"
    },
    {
      icon: Car,
      title: "Car Rental",
      description: "Rent a car for your perfect road trip",
      color: "bg-hero-gradient"
    },
    {
      icon: MapPin,
      title: "Activities",
      description: "Discover local experiences and attractions",
      color: "bg-sky-gradient"
    }
  ];

  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Plan Your Perfect Trip
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need for your journey, all in one place
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {actions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Card key={index} className="p-6 text-center border-0 shadow-card hover:shadow-travel transition-all duration-300 hover:-translate-y-1 group cursor-pointer">
                <div className={`w-16 h-16 ${action.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                  {action.title}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {action.description}
                </p>
                <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  Explore
                </Button>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};