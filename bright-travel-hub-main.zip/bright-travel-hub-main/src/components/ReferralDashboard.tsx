import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Euro, 
  Users, 
  Share2, 
  Copy, 
  TrendingUp,
  Calendar,
  Gift,
  ExternalLink
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ReferralStats {
  total_earnings: number;
  total_referrals: number;
  referral_code: string;
}

interface ReferralPurchase {
  id: string;
  purchase_amount: number;
  commission_amount: number;
  created_at: string;
  referral_code: string;
  referrer_user_id: string;
  customer_user_id: string;
  status: string;
}

export const ReferralDashboard = () => {
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [recentReferrals, setRecentReferrals] = useState<ReferralPurchase[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadReferralData();
  }, []);

  const loadReferralData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      
      if (!user.user) return;

      // Get referral stats
      const { data: statsData, error: statsError } = await supabase
        .from('customer_referrals')
        .select('*')
        .eq('user_id', user.user.id)
        .single();

      if (!statsError && statsData) {
        setStats(statsData);
      }

      // Get recent referral purchases
      const { data: purchasesData, error: purchasesError } = await supabase
        .from('referral_purchases')
        .select('*')
        .eq('referrer_user_id', user.user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (!purchasesError && purchasesData) {
        setRecentReferrals(purchasesData);
      }

    } catch (error) {
      console.error('Error loading referral data:', error);
      toast({
        title: "Error",
        description: "Failed to load referral data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getReferralUrl = () => {
    return `${window.location.origin}?ref=${stats?.referral_code}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-32 bg-muted/50 rounded-lg animate-pulse" />
        <div className="h-48 bg-muted/50 rounded-lg animate-pulse" />
      </div>
    );
  }

  if (!stats) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Gift className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Start Your Referral Journey</h3>
          <p className="text-muted-foreground mb-4">
            Make your first booking to unlock your referral program and start earning!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Earned</p>
                <p className="text-3xl font-bold text-green-600">€{stats.total_earnings}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <Euro className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Successful Referrals</p>
                <p className="text-3xl font-bold text-blue-600">{stats.total_referrals}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Potential Earnings</p>
                <p className="text-3xl font-bold text-purple-600">Unlimited</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Referral Link */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Your Referral Link
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1 bg-muted/50 rounded-lg p-3 border">
                <code className="text-sm break-all">{getReferralUrl()}</code>
              </div>
              <Button onClick={() => copyToClipboard(getReferralUrl())} variant="outline">
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Share this link with friends and family. You'll earn €1 for every booking they make!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Referrals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Recent Referral Earnings
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentReferrals.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No referrals yet</h3>
              <p className="text-muted-foreground">
                Start sharing your link to see your first referral earnings here!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentReferrals.map((referral) => (
                <div key={referral.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="bg-green-100 p-2 rounded-full">
                      <Euro className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold">
                        €{referral.commission_amount} earned
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Booking • {formatDate(referral.created_at)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Status: {referral.status}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary">
                      €{referral.purchase_amount} booking
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* How to Maximize Earnings */}
      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Gift className="w-5 h-5 text-primary" />
            Tips to Maximize Your Earnings
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">📱 Share on Social Media</h4>
              <p className="text-sm text-muted-foreground">
                Post your referral link on Facebook, Twitter, Instagram stories
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">💬 Tell Friends & Family</h4>
              <p className="text-sm text-muted-foreground">
                Share directly via WhatsApp, email, or in person
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">✈️ Travel Groups</h4>
              <p className="text-sm text-muted-foreground">
                Share in travel communities and planning groups
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">🎯 Target Travelers</h4>
              <p className="text-sm text-muted-foreground">
                Share with people who are planning trips or vacations
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};