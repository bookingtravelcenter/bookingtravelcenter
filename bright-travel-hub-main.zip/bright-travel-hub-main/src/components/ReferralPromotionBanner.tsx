import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Share2, 
  Copy, 
  Facebook, 
  Twitter, 
  MessageCircle,
  Gift,
  Users,
  Euro,
  X
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ReferralPromotionBannerProps {
  isOpen: boolean;
  onClose: () => void;
  bookingType: 'flight' | 'hotel' | 'car' | 'tour';
  destination: string;
  bookingAmount: string;
}

export const ReferralPromotionBanner = ({ 
  isOpen, 
  onClose, 
  bookingType, 
  destination,
  bookingAmount 
}: ReferralPromotionBannerProps) => {
  const [referralCode, setReferralCode] = useState<string>("");
  const [referralData, setReferralData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      generateReferralCode();
    }
  }, [isOpen]);

  const generateReferralCode = async () => {
    setLoading(true);
    try {
      const { data: user } = await supabase.auth.getUser();
      
      if (!user.user) {
        toast({
          title: "Authentication Required",
          description: "Please log in to get your referral code",
          variant: "destructive"
        });
        return;
      }

      // Get or create referral code
      const { data, error } = await supabase.rpc('create_user_referral_code', {
        user_id: user.user.id
      });

      if (error) throw error;

      setReferralCode(data);

      // Get referral statistics
      const { data: stats, error: statsError } = await supabase
        .from('customer_referrals')
        .select('*')
        .eq('user_id', user.user.id)
        .single();

      if (!statsError) {
        setReferralData(stats);
      }
    } catch (error) {
      console.error('Error generating referral code:', error);
      toast({
        title: "Error",
        description: "Failed to generate referral code",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getReferralUrl = () => {
    return `${window.location.origin}?ref=${referralCode}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const shareToSocial = (platform: string) => {
    const url = getReferralUrl();
    const text = `Check out this amazing travel site! I just booked my ${bookingType} to ${destination}. Use my link to get started and I'll earn €1 for my next trip! 🌍✈️`;
    
    let shareUrl = '';
    
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        break;
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`;
        break;
    }
    
    window.open(shareUrl, '_blank', 'width=600,height=400');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto bg-gradient-to-br from-primary/5 via-background to-secondary/5 border-primary/20">
        <CardContent className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="bg-primary/20 p-3 rounded-full">
                <Gift className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-primary">
                  🎉 Earn Money for Your Next Trip!
                </h2>
                <p className="text-muted-foreground mt-1">
                  Share with friends and earn €1 for every booking they make
                </p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Success Message */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-2 rounded-full">
                <Gift className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-green-800">Your {bookingType} to {destination} is confirmed!</h3>
                <p className="text-green-700 text-sm">Amount paid: {bookingAmount}</p>
              </div>
            </div>
          </div>

          {/* How it works */}
          <div className="bg-primary/5 rounded-lg p-6 mb-6">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Euro className="w-5 h-5 text-primary" />
              How the Referral Program Works
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Share2 className="w-6 h-6 text-primary" />
                </div>
                <h4 className="font-semibold mb-2">1. Share Your Link</h4>
                <p className="text-sm text-muted-foreground">Share your unique referral link with friends and family</p>
              </div>
              <div className="text-center">
                <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <h4 className="font-semibold mb-2">2. Friends Book</h4>
                <p className="text-sm text-muted-foreground">They use your link to book flights, hotels, or activities</p>
              </div>
              <div className="text-center">
                <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Euro className="w-6 h-6 text-primary" />
                </div>
                <h4 className="font-semibold mb-2">3. You Earn €1</h4>
                <p className="text-sm text-muted-foreground">Get €1 credit for every successful booking</p>
              </div>
            </div>
          </div>

          {/* Referral Stats */}
          {referralData && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-primary/10 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-primary">€{referralData.total_earnings}</div>
                <div className="text-sm text-muted-foreground">Total Earned</div>
              </div>
              <div className="bg-secondary/10 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-secondary">{referralData.total_referrals}</div>
                <div className="text-sm text-muted-foreground">Successful Referrals</div>
              </div>
            </div>
          )}

          {/* Referral Link */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">Your Unique Referral Link</h3>
            <div className="flex gap-2">
              <div className="flex-1 bg-muted/50 rounded-lg p-3 border">
                <code className="text-sm break-all">
                  {loading ? "Generating..." : getReferralUrl()}
                </code>
              </div>
              <Button 
                onClick={() => copyToClipboard(getReferralUrl())} 
                variant="outline"
                disabled={loading}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Social Sharing */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">Share on Social Media</h3>
            <div className="flex gap-3">
              <Button 
                onClick={() => shareToSocial('facebook')} 
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                disabled={loading}
              >
                <Facebook className="w-4 h-4 mr-2" />
                Facebook
              </Button>
              <Button 
                onClick={() => shareToSocial('twitter')} 
                className="flex-1 bg-sky-500 hover:bg-sky-600 text-white"
                disabled={loading}
              >
                <Twitter className="w-4 h-4 mr-2" />
                Twitter
              </Button>
              <Button 
                onClick={() => shareToSocial('whatsapp')} 
                className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                disabled={loading}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>

          {/* Benefits */}
          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-6 text-center">
            <h3 className="text-xl font-bold mb-3">💰 Start Earning Today!</h3>
            <p className="text-muted-foreground mb-4">
              The more you share, the more you earn for your next adventure. Your friends get a great travel platform, and you get money for your next trip!
            </p>
            <div className="flex gap-3 justify-center">
              <Button 
                onClick={() => copyToClipboard(getReferralUrl())}
                className="bg-primary hover:bg-primary/90"
                disabled={loading}
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share Link Now
              </Button>
              <Button variant="outline" onClick={onClose}>
                Maybe Later
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};