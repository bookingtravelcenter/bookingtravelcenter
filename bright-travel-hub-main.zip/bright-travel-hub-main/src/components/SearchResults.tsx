import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Calendar, Users, Filter, SortAsc } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BookingModal } from "./BookingModal";
import { Skeleton } from "@/components/ui/skeleton";

interface SearchResult {
  id: string;
  title: string;
  location: string;
  price: number;
  rating: number;
  reviewCount: number;
  image: string;
  type: "hotel" | "flight" | "tour";
  amenities: string[];
  availability: boolean;
}

interface SearchResultsProps {
  searchQuery: {
    destination: string;
    checkIn: Date;
    checkOut: Date;
    guests: string;
    type: "hotel" | "flight" | "tour";
  } | null;
  isLoading?: boolean;
}

// Mock search results - in a real app, this would come from an API
const generateMockResults = (query: SearchResultsProps['searchQuery']): SearchResult[] => {
  if (!query) return [];

  const baseResults = [
    {
      id: "1",
      title: "Luxury Ocean Resort & Spa",
      location: query.destination,
      price: 299,
      rating: 4.8,
      reviewCount: 1247,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Pool", "Spa", "WiFi", "Restaurant"],
      availability: true,
    },
    {
      id: "2", 
      title: "Boutique City Hotel",
      location: query.destination,
      price: 189,
      rating: 4.6,
      reviewCount: 892,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["WiFi", "Gym", "Restaurant", "Bar"],
      availability: true,
    },
    {
      id: "3",
      title: "Mountain View Lodge",
      location: query.destination,
      price: 159,
      rating: 4.9,
      reviewCount: 654,
      image: "/api/placeholder/400/300", 
      type: query.type,
      amenities: ["Mountain View", "Fireplace", "WiFi"],
      availability: false,
    },
    {
      id: "4",
      title: "Historic Grand Hotel",
      location: query.destination,
      price: 389,
      rating: 4.7,
      reviewCount: 2156,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Historic", "Concierge", "Restaurant", "Spa"],
      availability: true,
    },
    {
      id: "5",
      title: "Modern Business Hotel",
      location: query.destination,
      price: 219,
      rating: 4.5,
      reviewCount: 743,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Business Center", "WiFi", "Gym"],
      availability: true,
    },
    {
      id: "6",
      title: "Seaside Paradise Resort",
      location: query.destination,
      price: 449,
      rating: 4.9,
      reviewCount: 1834,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Beachfront", "Pool", "Spa", "Water Sports"],
      availability: true,
    },
    {
      id: "7",
      title: "Urban Design Hotel",
      location: query.destination,
      price: 279,
      rating: 4.4,
      reviewCount: 567,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Design", "Rooftop Bar", "WiFi", "Art Gallery"],
      availability: true,
    },
    {
      id: "8",
      title: "Family Resort & Water Park",
      location: query.destination,
      price: 329,
      rating: 4.6,
      reviewCount: 1456,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Water Park", "Kids Club", "Pool", "Restaurant"],
      availability: true,
    },
    {
      id: "9",
      title: "Eco-Friendly Lodge",
      location: query.destination,
      price: 199,
      rating: 4.7,
      reviewCount: 789,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Eco-Friendly", "Nature Trails", "WiFi", "Organic Restaurant"],
      availability: true,
    },
    {
      id: "10",
      title: "Romantic Getaway Inn",
      location: query.destination,
      price: 359,
      rating: 4.8,
      reviewCount: 923,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Romantic", "Couples Spa", "Fine Dining", "Wine Cellar"],
      availability: true,
    },
    {
      id: "11",
      title: "Budget Comfort Hotel",
      location: query.destination,
      price: 99,
      rating: 4.2,
      reviewCount: 445,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Budget-Friendly", "WiFi", "Continental Breakfast"],
      availability: true,
    },
    {
      id: "12",
      title: "Executive Business Suite",
      location: query.destination,
      price: 379,
      rating: 4.6,
      reviewCount: 1234,
      image: "/api/placeholder/400/300",
      type: query.type,
      amenities: ["Executive Lounge", "Meeting Rooms", "Concierge", "WiFi"],
      availability: true,
    }
  ];

  return baseResults as SearchResult[];
};

export const SearchResults = ({ searchQuery, isLoading = false }: SearchResultsProps) => {
  const [results, setResults] = useState<SearchResult[]>([]);
  const [sortBy, setSortBy] = useState("recommended");
  const [selectedResult, setSelectedResult] = useState<SearchResult | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);

  useEffect(() => {
    if (searchQuery && !isLoading) {
      // Simulate API call delay
      const timer = setTimeout(() => {
        setResults(generateMockResults(searchQuery));
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [searchQuery, isLoading]);

  const sortedResults = [...results].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      case "recommended":
      default:
        return b.rating * b.reviewCount - a.rating * a.reviewCount;
    }
  });

  const handleBookNow = (result: SearchResult) => {
    setSelectedResult(result);
    setShowBookingModal(true);
  };

  if (!searchQuery) return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">
          {searchQuery.type === "hotel" ? "Hotels" : searchQuery.type === "flight" ? "Flights" : "Tours"} in {searchQuery.destination}
        </h2>
        <p className="text-muted-foreground">
          {searchQuery.checkIn.toLocaleDateString()} - {searchQuery.checkOut.toLocaleDateString()} • {searchQuery.guests} guest{searchQuery.guests !== "1" ? "s" : ""}
        </p>
      </div>

      {/* Filters and Sorting */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          <span className="text-sm font-medium">Sort by:</span>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recommended">Recommended</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>{results.length} results found</span>
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid gap-6">
        {isLoading ? (
          // Loading skeleton
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <div className="flex flex-col md:flex-row">
                <Skeleton className="w-full md:w-80 h-48" />
                <div className="flex-1 p-6">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </div>
            </Card>
          ))
        ) : (
          sortedResults.map((result) => (
            <Card key={result.id} className="overflow-hidden hover:shadow-xl transition-all duration-300">
              <div className="flex flex-col md:flex-row">
                {/* Image */}
                <div className="relative w-full md:w-80 h-48">
                  <img
                    src={result.image}
                    alt={result.title}
                    className="w-full h-full object-cover"
                  />
                  {!result.availability && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Badge variant="destructive">Not Available</Badge>
                    </div>
                  )}
                </div>

                {/* Content */}
                <CardContent className="flex-1 p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-semibold text-foreground">{result.title}</h3>
                    <div className="flex items-center gap-1 text-yellow-500">
                      <Star className="w-4 h-4 fill-current" />
                      <span className="font-medium">{result.rating}</span>
                      <span className="text-sm text-muted-foreground">({result.reviewCount})</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 text-muted-foreground mb-4">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{result.location}</span>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {result.amenities.map((amenity) => (
                      <Badge key={amenity} variant="secondary" className="text-xs">
                        {amenity}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-primary">${result.price}</span>
                      <span className="text-sm text-muted-foreground ml-1">per night</span>
                    </div>
                    
                    <Button
                      onClick={() => handleBookNow(result)}
                      disabled={!result.availability}
                      className="bg-primary hover:bg-primary/90"
                    >
                      {result.availability ? "Book Now" : "Unavailable"}
                    </Button>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* No results message */}
      {!isLoading && results.length === 0 && searchQuery && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold mb-2">No results found</h3>
          <p className="text-muted-foreground">
            Try adjusting your search criteria or explore other destinations
          </p>
        </div>
      )}

      {/* Booking Modal */}
      {selectedResult && (
        <BookingModal
          isOpen={showBookingModal}
          onClose={() => setShowBookingModal(false)}
          bookingType={selectedResult.type}
          title={selectedResult.title}
          price={`$${selectedResult.price}`}
          location={selectedResult.location}
        />
      )}
    </div>
  );
};