import { useState } from "react";
import { Search, MapPin, Calendar, Users, Plane, Car, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { format, addDays, addWeeks, addMonths, startOfWeek, endOfWeek, nextSaturday, nextSunday } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { SearchResults } from "./SearchResults";

// Popular destinations for autocomplete
const popularDestinations = [
  "Paris, France", "Tokyo, Japan", "New York, USA", "London, UK", "Rome, Italy",
  "Barcelona, Spain", "Dubai, UAE", "Bangkok, Thailand", "Sydney, Australia",
  "Santorini, Greece", "Bali, Indonesia", "Maldives", "Swiss Alps", "Iceland",
  "Morocco", "Egypt", "Peru", "Costa Rica", "Nepal", "Jordan"
];

// Quick date suggestions
const quickDateOptions = [
  { 
    label: "This Weekend", 
    getDates: () => {
      const now = new Date();
      const saturday = nextSaturday(now);
      const sunday = nextSunday(now);
      return { checkIn: saturday, checkOut: sunday };
    }
  },
  { label: "Next Week", getDates: () => ({ checkIn: addWeeks(new Date(), 1), checkOut: addDays(addWeeks(new Date(), 1), 7) }) },
  { label: "Next Month", getDates: () => ({ checkIn: addMonths(new Date(), 1), checkOut: addDays(addMonths(new Date(), 1), 7) }) },
  { label: "Summer 2024", getDates: () => ({ checkIn: new Date(2024, 5, 21), checkOut: new Date(2024, 5, 28) }) },
];

export const SearchSection = () => {
  const [searchType, setSearchType] = useState<"hotel" | "flight" | "tour">("hotel");
  const [destination, setDestination] = useState("");
  const [checkInDate, setCheckInDate] = useState<Date>();
  const [checkOutDate, setCheckOutDate] = useState<Date>();
  const [guests, setGuests] = useState("2");
  const [showDestinationSuggestions, setShowDestinationSuggestions] = useState(false);
  const [searchQuery, setSearchQuery] = useState<{
    destination: string;
    checkIn: Date;
    checkOut: Date;
    guests: string;
    type: "hotel" | "flight" | "tour";
  } | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const filteredDestinations = destination
    ? popularDestinations.filter(dest =>
        dest.toLowerCase().includes(destination.toLowerCase())
      )
    : popularDestinations.slice(0, 8);

  const handleDestinationSelect = (dest: string) => {
    setDestination(dest);
    setShowDestinationSuggestions(false);
  };

  const handleQuickDate = (option: typeof quickDateOptions[0]) => {
    const dates = option.getDates();
    setCheckInDate(dates.checkIn);
    setCheckOutDate(dates.checkOut);
  };

  const handleSearch = () => {
    if (!destination) {
      toast({
        title: "Please select a destination",
        description: "Choose where you'd like to go",
        variant: "destructive",
      });
      return;
    }

    if (!checkInDate || !checkOutDate) {
      toast({
        title: "Please select dates",
        description: "Choose your travel dates",
        variant: "destructive",
      });
      return;
    }

    // Redirect to dedicated pages for all search types
    if (searchType === "hotel") {
      toast({
        title: "Redirecting to Hotels!",
        description: `Finding hotels in ${destination} for ${guests} guest${guests !== "1" ? "s" : ""}`,
      });
      
      navigate(`/hotels?destination=${encodeURIComponent(destination)}&checkIn=${checkInDate.toISOString()}&checkOut=${checkOutDate.toISOString()}&guests=${guests}`);
      return;
    }

    if (searchType === "flight") {
      toast({
        title: "Redirecting to Flights!",
        description: `Finding flights to ${destination} for ${guests} guest${guests !== "1" ? "s" : ""}`,
      });
      
      navigate(`/flights?destination=${encodeURIComponent(destination)}&checkIn=${checkInDate.toISOString()}&checkOut=${checkOutDate.toISOString()}&guests=${guests}`);
      return;
    }

    if (searchType === "tour") {
      toast({
        title: "Redirecting to Tours!",
        description: `Finding tours in ${destination} for ${guests} guest${guests !== "1" ? "s" : ""}`,
      });
      
      navigate(`/tours?destination=${encodeURIComponent(destination)}&checkIn=${checkInDate.toISOString()}&checkOut=${checkOutDate.toISOString()}&guests=${guests}`);
      return;
    }
  };

  return (
    <>
      <Card className="w-full max-w-6xl mx-auto p-4 md:p-8 shadow-travel bg-card/98 backdrop-blur-md border-0 rounded-2xl">
        {/* Search Type Selector */}
        <div className="flex justify-center mb-6 md:mb-8">
          <div className="flex bg-gradient-to-r from-muted/30 to-muted/50 rounded-xl p-1.5 backdrop-blur-sm w-full sm:w-auto">
            <Button
              variant={searchType === "hotel" ? "default" : "ghost"}
              size="mobile"
              onClick={() => setSearchType("hotel")}
              className="flex-1 sm:flex-none items-center justify-center gap-2 px-4 md:px-6 py-3 rounded-lg transition-all duration-300 text-sm md:text-base"
            >
              <Building2 className="h-4 w-4" />
              <span>Hotels</span>
            </Button>
            <Button
              variant={searchType === "flight" ? "default" : "ghost"}
              size="mobile"
              onClick={() => setSearchType("flight")}
              className="flex-1 sm:flex-none items-center justify-center gap-2 px-4 md:px-6 py-3 rounded-lg transition-all duration-300 text-sm md:text-base"
            >
              <Plane className="h-4 w-4" />
              <span>Flights</span>
            </Button>
            <Button
              variant={searchType === "tour" ? "default" : "ghost"}
              size="mobile"
              onClick={() => setSearchType("tour")}
              className="flex-1 sm:flex-none items-center justify-center gap-2 px-4 md:px-6 py-3 rounded-lg transition-all duration-300 text-sm md:text-base"
            >
              <Search className="h-4 w-4" />
              <span>Tours</span>
            </Button>
          </div>
        </div>

        {/* Quick Date Suggestions - Now shown on mobile with better spacing */}
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          <span className="text-sm md:text-base text-muted-foreground flex items-center mr-2 w-full sm:w-auto text-center sm:text-left mb-2 sm:mb-0">
            Quick dates:
          </span>
          <div className="flex flex-wrap justify-center gap-2">
            {quickDateOptions.map((option) => (
              <Badge
                key={option.label}
                variant="outline"
                className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors text-sm px-3 py-1.5 h-auto min-h-[36px]"
                onClick={() => handleQuickDate(option)}
              >
                {option.label}
              </Badge>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {/* Destination Input with Autocomplete */}
          <div className="relative">
            <MapPin className="absolute left-3 top-4 h-5 w-5 text-muted-foreground z-10" />
            <Input
              placeholder="Where to?"
              className="pl-12 h-14 md:h-12 border-border/50 focus:border-primary text-base md:text-sm rounded-lg"
              value={destination}
              onChange={(e) => {
                setDestination(e.target.value);
                setShowDestinationSuggestions(true);
              }}
              onFocus={() => setShowDestinationSuggestions(true)}
            />
            
            {/* Destination Suggestions Dropdown */}
            {showDestinationSuggestions && (
              <div className="absolute top-full left-0 right-0 z-20 mt-1 bg-popover border border-border rounded-md shadow-lg max-h-48 overflow-auto">
                {filteredDestinations.map((dest, index) => (
                  <div
                    key={`${dest}-${index}`}
                    className="px-3 py-2 hover:bg-accent cursor-pointer flex items-center gap-2"
                    onClick={() => handleDestinationSelect(dest)}
                  >
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{dest}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Dynamic Date Picker */}
          <div className="relative">
            <Calendar className="absolute left-3 top-4 h-5 w-5 text-muted-foreground z-10" />
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full h-14 md:h-12 pl-12 justify-start text-left font-normal border-border/50 focus:border-primary text-base md:text-sm rounded-lg",
                    !checkInDate && "text-muted-foreground"
                  )}
                >
                  {checkInDate ? format(checkInDate, "MMM dd, yyyy") : 
                    (searchType === "hotel" ? "Check-in" : 
                     searchType === "flight" ? "Departure" : "Start Date")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={checkInDate}
                  onSelect={setCheckInDate}
                  disabled={(date) => date < new Date()}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Dynamic Second Date Picker */}
          <div className="relative">
            <Calendar className="absolute left-3 top-4 h-5 w-5 text-muted-foreground z-10" />
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full h-14 md:h-12 pl-12 justify-start text-left font-normal border-border/50 focus:border-primary text-base md:text-sm rounded-lg",
                    !checkOutDate && "text-muted-foreground"
                  )}
                >
                  {checkOutDate ? format(checkOutDate, "MMM dd, yyyy") : 
                    (searchType === "hotel" ? "Check-out" : 
                     searchType === "flight" ? "Return" : "End Date")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={checkOutDate}
                  onSelect={setCheckOutDate}
                  disabled={(date) => date < (checkInDate || new Date())}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Guests Selector */}
          <div className="relative">
            <Users className="absolute left-3 top-4 h-5 w-5 text-muted-foreground z-10" />
            <Select value={guests} onValueChange={setGuests}>
              <SelectTrigger className="w-full h-14 md:h-12 pl-12 border-border/50 focus:border-primary text-base md:text-sm rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                  <SelectItem key={num} value={num.toString()}>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      {num} {num === 1 ? "Guest" : "Guests"}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Search Results Summary - Hidden on small screens */}
        {destination && checkInDate && checkOutDate && (
          <div className="hidden md:block mb-4 p-3 bg-primary/5 rounded-lg border border-primary/20">
            <p className="text-sm text-muted-foreground">
              Searching for <span className="font-medium text-foreground">{searchType}s</span> in{" "}
              <span className="font-medium text-foreground">{destination}</span> for{" "}
              <span className="font-medium text-foreground">{guests} guest{guests !== "1" ? "s" : ""}</span> from{" "}
              <span className="font-medium text-foreground">{format(checkInDate, "MMM dd")}</span> to{" "}
              <span className="font-medium text-foreground">{format(checkOutDate, "MMM dd")}</span>
            </p>
          </div>
        )}

        <Button
          variant="cta"
          size="xl"
          className="w-full sm:w-auto sm:px-16 h-16 text-lg md:text-xl font-semibold bg-gradient-to-r from-primary to-primary-glow hover:from-primary-dark hover:to-primary shadow-elegant hover:shadow-glow transition-all duration-500 mt-2"
          onClick={handleSearch}
          disabled={isSearching}
        >
          <Search className="mr-3 h-6 w-6 md:h-7 md:w-7" />
          {isSearching ? "Searching..." : "Find My Adventure"}
        </Button>

        {/* Click outside to hide suggestions */}
        {showDestinationSuggestions && (
          <div
            className="fixed inset-0 z-10"
            onClick={() => setShowDestinationSuggestions(false)}
          />
        )}
      </Card>

      {/* Search Results */}
      <SearchResults searchQuery={searchQuery} isLoading={isSearching} />
    </>
  );
};