import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Sun, Cloud, Snowflake, Thermometer, Droplets } from "lucide-react";
import { useEffect } from "react";

interface SeasonalDestination {
  id: string;
  name: string;
  country: string;
  image: string;
  bestMonths: string[];
  season: string;
  weatherHighlights: string[];
  temperature: string;
  rainfall: string;
  activities: string[];
  price: string;
  discount?: string;
}

const seasonalDestinations: SeasonalDestination[] = [
  {
    id: "1",
    name: "Santorini",
    country: "Greece",
    image: "/src/assets/santorini.jpg",
    bestMonths: ["May", "June", "September", "October"],
    season: "Spring & Fall",
    weatherHighlights: ["Perfect temperatures", "Less crowds", "Clear skies"],
    temperature: "20-26°C",
    rainfall: "Low",
    activities: ["Sunset viewing", "Wine tasting", "Beach relaxation"],
    price: "$1,299",
    discount: "20% OFF"
  },
  {
    id: "2", 
    name: "Tokyo",
    country: "Japan",
    image: "/src/assets/tokyo.jpg",
    bestMonths: ["March", "April", "May", "November"],
    season: "Spring & Autumn",
    weatherHighlights: ["Cherry blossoms", "Mild weather", "Beautiful foliage"],
    temperature: "15-22°C",
    rainfall: "Moderate", 
    activities: ["Temple visits", "Cherry blossom viewing", "Cultural tours"],
    price: "$1,899"
  },
  {
    id: "3",
    name: "Paris",
    country: "France", 
    image: "/src/assets/paris.jpg",
    bestMonths: ["April", "May", "June", "September"],
    season: "Late Spring & Early Fall",
    weatherHighlights: ["Pleasant weather", "Blooming gardens", "Perfect for walking"],
    temperature: "16-24°C",
    rainfall: "Light",
    activities: ["City walks", "Museum visits", "Seine river cruise"],
    price: "$1,699",
    discount: "15% OFF"
  }
];

const monthlyRecommendations = [
  { month: "January", destinations: ["Dubai", "Thailand", "India"], weather: "Warm & Dry", icon: Sun },
  { month: "February", destinations: ["Japan", "Myanmar", "Vietnam"], weather: "Cool & Pleasant", icon: Cloud },
  { month: "March", destinations: ["India", "Egypt", "Morocco"], weather: "Perfect Temperatures", icon: Sun },
  { month: "April", destinations: ["Turkey", "Greece", "Spain"], weather: "Mild Spring", icon: Sun },
  { month: "May", destinations: ["Europe", "Mediterranean", "Turkey"], weather: "Warm & Sunny", icon: Sun },
  { month: "June", destinations: ["Scandinavia", "Scotland", "Eastern Europe"], weather: "Summer Peak", icon: Sun },
  { month: "July", destinations: ["Russia", "Scandinavia", "Baltics"], weather: "Warm Summer", icon: Sun },
  { month: "August", destinations: ["Central Europe", "Romania", "Scotland"], weather: "Peak Summer", icon: Sun },
  { month: "September", destinations: ["Italy", "Greece", "Turkey"], weather: "Perfect Fall", icon: Sun },
  { month: "October", destinations: ["India", "Nepal", "Morocco"], weather: "Cool & Pleasant", icon: Cloud },
  { month: "November", destinations: ["Myanmar", "India", "Egypt"], weather: "Comfortable", icon: Cloud },
  { month: "December", destinations: ["India", "Myanmar", "Philippines"], weather: "Cool & Dry", icon: Snowflake }
];

export const SeasonalTravelGuide = () => {
  useEffect(() => {
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "TravelGuide",
      "name": "Seasonal Travel Guide",
      "description": "Best times to visit popular destinations based on weather and seasons",
      "publisher": {
        "@type": "Organization",
        "name": "TravelEase"
      },
      "about": seasonalDestinations.map(dest => ({
        "@type": "TouristDestination",
        "name": dest.name,
        "address": {
          "@type": "PostalAddress",
          "addressCountry": dest.country
        },
        "description": `Best time to visit: ${dest.bestMonths.join(", ")}. ${dest.weatherHighlights.join(", ")}.`
      }))
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <section className="py-16 bg-gradient-to-br from-ocean-light via-background to-secondary">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Best Time to Travel
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the perfect seasons for your dream destinations. Plan your trips when weather conditions are ideal and prices are most favorable.
          </p>
        </div>

        {/* Featured Seasonal Destinations */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-foreground mb-8 flex items-center gap-2">
            <Calendar className="h-6 w-6 text-primary" />
            Seasonal Highlights
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {seasonalDestinations.map((destination) => (
              <Card key={destination.id} className="group hover:shadow-travel transition-all duration-300 border-0 bg-card/80 backdrop-blur-sm">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img 
                    src={destination.image} 
                    alt={`${destination.name}, ${destination.country} - Best visited during ${destination.season}`}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    style={{ maxWidth: '100%', height: '192px', objectFit: 'cover' }}
                  />
                  {destination.discount && (
                    <Badge className="absolute top-3 left-3 bg-accent text-accent-foreground font-bold">
                      {destination.discount}
                    </Badge>
                  )}
                  <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground">
                    {destination.season}
                  </Badge>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl text-card-foreground">
                    {destination.name}, {destination.country}
                  </CardTitle>
                  <div className="flex flex-wrap gap-2">
                    {destination.bestMonths.map((month) => (
                      <Badge key={month} variant="outline" className="text-xs">
                        {month}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Thermometer className="h-4 w-4 text-accent" />
                      <span className="text-muted-foreground">{destination.temperature}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Droplets className="h-4 w-4 text-ocean-blue" />
                      <span className="text-muted-foreground">{destination.rainfall}</span>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-card-foreground mb-2">Weather Highlights</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {destination.weatherHighlights.map((highlight, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <Sun className="h-3 w-3 text-accent" />
                          {highlight}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-card-foreground mb-2">Best Activities</h4>
                    <div className="flex flex-wrap gap-1">
                      {destination.activities.map((activity, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {activity}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4">
                    <div>
                      <span className="text-2xl font-bold text-primary">{destination.price}</span>
                      <span className="text-sm text-muted-foreground">/person</span>
                    </div>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Monthly Travel Calendar */}
        <div className="bg-card/60 backdrop-blur-sm rounded-lg p-8 border">
          <h3 className="text-2xl font-semibold text-foreground mb-8 flex items-center gap-2">
            <Calendar className="h-6 w-6 text-primary" />
            Year-Round Travel Calendar
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {monthlyRecommendations.map((month) => {
              const IconComponent = month.icon;
              return (
                <Card key={month.month} className="hover:shadow-card transition-all duration-200 border border-border/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <IconComponent className="h-5 w-5 text-accent" />
                      {month.month}
                    </CardTitle>
                    <p className="text-sm text-accent font-medium">{month.weather}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {month.destinations.map((destination, index) => (
                        <div key={index} className="text-sm text-muted-foreground">
                          • {destination}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <Button size="lg" className="bg-sunset-gradient text-primary-foreground hover:opacity-90 transition-opacity">
            Plan Your Perfect Trip
          </Button>
        </div>
      </div>
    </section>
  );
};