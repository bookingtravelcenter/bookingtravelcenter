
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sun, 
  Snowflake, 
  Flower, 
  MapPin,
  Calendar,
  Users,
  Heart,
  ChevronLeft,
  ChevronRight,
  Loader2
} from "lucide-react";

import tropicalSummer from "@/assets/tropical-summer.jpg";
import tropicalAutumn from "@/assets/tropical-autumn.jpg";
import tropicalWinter from "@/assets/tropical-winter.jpg";
import tropicalSpring from "@/assets/tropical-spring.jpg";

const seasons = [
  {
    id: "summer",
    name: "Summer Vibes",
    icon: Sun,
    image: tropicalSummer,
    color: "from-orange-500 to-yellow-500",
    bgColor: "bg-orange-50",
    textColor: "text-orange-600",
    title: "Paradise Awaits",
    description: "Perfect for sun seekers and beach lovers who crave endless summer days",
    features: ["25-32°C Perfect Weather", "Crystal Clear Waters", "Beach Activities", "Vibrant Nightlife"],
    appeal: "Families, Young Couples, Adventure Seekers",
    bestFor: "Swimming, Snorkeling, Beach Sports",
    months: "Jun - Aug"
  },
  {
    id: "autumn",
    name: "Golden Retreat",
    icon: MapPin,
    image: tropicalAutumn,
    color: "from-amber-600 to-orange-600",
    bgColor: "bg-amber-50",
    textColor: "text-amber-600",
    title: "Serene Golden Hours",
    description: "Ideal for couples and mature travelers seeking tranquil romantic escapes",
    features: ["22-28°C Comfortable Temps", "Stunning Sunsets", "Peaceful Atmosphere", "Local Culture"],
    appeal: "Couples, Mature Travelers, Photographers",
    bestFor: "Romance, Photography, Cultural Tours",
    months: "Sep - Nov"
  },
  {
    id: "winter",
    name: "Peaceful Escape",
    icon: Snowflake,
    image: tropicalWinter,
    color: "from-blue-500 to-cyan-500",
    bgColor: "bg-blue-50",
    textColor: "text-blue-600",
    title: "Tranquil Paradise",
    description: "Perfect for those escaping winter, seeking warmth and peaceful relaxation",
    features: ["20-26°C Mild Climate", "Misty Mornings", "Spa Weather", "Quiet Beaches"],
    appeal: "Winter Escapists, Wellness Seekers, Seniors",
    bestFor: "Relaxation, Wellness, Meditation",
    months: "Dec - Feb"
  },
  {
    id: "spring",
    name: "Fresh Awakening",
    icon: Flower,
    image: tropicalSpring,
    color: "from-green-500 to-emerald-500",
    bgColor: "bg-green-50",
    textColor: "text-green-600",
    title: "Nature's Renaissance",
    description: "Ideal for nature lovers and eco-tourists who appreciate lush landscapes",
    features: ["23-29°C Fresh Air", "Blooming Flora", "Wildlife Active", "Hiking Perfect"],
    appeal: "Nature Lovers, Eco-Tourists, Hikers",
    bestFor: "Hiking, Wildlife Watching, Eco-Tours",
    months: "Mar - May"
  }
];

export const SeasonalTropicalShowcase = () => {
  const [activeSeason, setActiveSeason] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [preloadedImages, setPreloadedImages] = useState<Set<string>>(new Set());
  const currentSeason = seasons[activeSeason];
  const IconComponent = currentSeason.icon;

  // Preload current image with optimized reflow prevention
  useEffect(() => {
    // Only update loading state if image isn't already preloaded
    if (!preloadedImages.has(currentSeason.image)) {
      setImageLoaded(false);
      
      const img = new Image();
      img.onload = () => {
        // Use requestAnimationFrame to prevent forced reflows
        requestAnimationFrame(() => {
          setImageLoaded(true);
          setPreloadedImages(prev => new Set(prev).add(currentSeason.image));
        });
      };
      img.src = currentSeason.image;
    } else {
      // Image already loaded, set state immediately
      setImageLoaded(true);
    }
  }, [currentSeason.image, preloadedImages]);

  // Preload next image in background
  useEffect(() => {
    const nextIndex = (activeSeason + 1) % seasons.length;
    const nextImage = seasons[nextIndex].image;
    
    if (!preloadedImages.has(nextImage)) {
      const img = new Image();
      img.onload = () => {
        requestAnimationFrame(() => {
          setPreloadedImages(prev => new Set(prev).add(nextImage));
        });
      };
      img.src = nextImage;
    }
  }, [activeSeason, preloadedImages]);

  const nextSeason = () => {
    setActiveSeason((prev) => (prev + 1) % seasons.length);
  };

  const prevSeason = () => {
    setActiveSeason((prev) => (prev - 1 + seasons.length) % seasons.length);
  };

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-background via-muted/20 to-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            One Paradise,
            <span className="bg-hero-gradient bg-clip-text text-transparent block">
              Four Perfect Seasons
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Discover why our tropical paradise is perfect year-round. From vibrant summers to serene winters, 
            there's always a perfect time for every traveler.
          </p>
        </div>

        {/* Main Showcase */}
        <div className="relative">
          <Card className="overflow-hidden shadow-2xl">
            <div className="relative h-[500px] md:h-[500px]">
              {/* Background Image with Loading State */}
              <div className="absolute inset-0">
                {!imageLoaded && (
                  <div className="absolute inset-0 bg-muted flex items-center justify-center z-10">
                    <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                  </div>
                )}
                <div 
                  className={`absolute inset-0 bg-cover bg-center transition-all duration-700 ${
                    imageLoaded ? 'opacity-100' : 'opacity-0'
                  }`}
                  style={{ 
                    backgroundImage: `url(${currentSeason.image})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-black/40" />
                </div>
              </div>

              {/* Navigation Arrows */}
              <Button
                variant="ghost"
                size="lg"
                onClick={prevSeason}
                className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 z-20 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border border-white/30 h-10 w-10 md:h-12 md:w-12"
              >
                <ChevronLeft className="w-4 h-4 md:w-6 md:h-6" />
              </Button>
              <Button
                variant="ghost"
                size="lg"
                onClick={nextSeason}
                className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 z-20 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border border-white/30 h-10 w-10 md:h-12 md:w-12"
              >
                <ChevronRight className="w-4 h-4 md:w-6 md:h-6" />
              </Button>

              {/* Content */}
              <div className="absolute inset-0 flex items-center z-10">
                <div className="w-full max-w-6xl mx-auto px-4 md:px-8">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-8 items-center">
                    {/* Left Content */}
                    <div className="text-white space-y-4 md:space-y-6">
                      <div className="flex items-center gap-2 md:gap-3">
                        <div className={`p-2 md:p-3 rounded-full bg-gradient-to-r ${currentSeason.color}`}>
                          <IconComponent className="w-6 h-6 md:w-8 md:h-8 text-white" />
                        </div>
                        <Badge variant="secondary" className="text-sm md:text-lg px-3 md:px-4 py-1 md:py-2">
                          {currentSeason.months}
                        </Badge>
                      </div>
                      
                      <div>
                        <h3 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-2 md:mb-3">
                          {currentSeason.title}
                        </h3>
                        <p className="text-base md:text-xl opacity-90 leading-relaxed">
                          {currentSeason.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 md:gap-6 text-xs md:text-sm">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 md:w-5 md:h-5" />
                          <span>Perfect for {currentSeason.appeal}</span>
                        </div>
                      </div>

                      <Button 
                        size="lg" 
                        className="bg-white text-black hover:bg-white/90 text-sm md:text-lg px-6 md:px-8 py-4 md:py-6"
                        onClick={() => window.open('https://hotellook.com', '_blank')}
                      >
                        <Heart className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                        Book Hotels
                      </Button>
                    </div>

                    {/* Right Content - Features */}
                    <div className="space-y-3 md:space-y-4">
                      <Card className="bg-white/10 backdrop-blur-md border-white/20">
                        <CardContent className="p-4 md:p-6 space-y-4">
                          <div>
                            <h4 className="text-white text-lg md:text-xl font-semibold mb-3">
                              Why Choose {currentSeason.name}?
                            </h4>
                            <div className="text-white/90 text-xs md:text-sm space-y-1">
                              {currentSeason.features.join(' • ')}
                            </div>
                          </div>
                          <div>
                            <h4 className="text-white text-base md:text-lg font-semibold mb-2">
                              Best Activities
                            </h4>
                            <p className="text-white/90 text-xs md:text-sm">
                              {currentSeason.bestFor}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Season Selector */}
          <div className="flex justify-center mt-6 md:mt-8 gap-2 md:gap-4 px-4">
            {seasons.map((season, index) => {
              const SeasonIcon = season.icon;
              return (
                <Button
                  key={season.id}
                  variant={index === activeSeason ? "default" : "outline"}
                  size="lg"
                  onClick={() => setActiveSeason(index)}
                  className={`flex flex-col items-center gap-1 md:gap-2 p-3 md:p-4 h-auto text-center min-w-0 ${
                    index === activeSeason 
                      ? `bg-gradient-to-r ${season.color} text-white hover:opacity-90` 
                      : "hover:bg-muted"
                  }`}
                >
                  <SeasonIcon className="w-4 h-4 md:w-6 md:h-6" />
                  <span className="text-xs md:text-sm font-medium leading-tight">{season.name}</span>
                  <span className="text-xs opacity-75 hidden md:block">{season.months}</span>
                </Button>
              );
            })}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12 md:mt-16">
          <h3 className="text-2xl md:text-3xl font-bold mb-4">Ready for Your Perfect Season?</h3>
          <p className="text-base md:text-lg text-muted-foreground mb-6 md:mb-8 max-w-2xl mx-auto px-4">
            No matter when you visit, our tropical paradise offers the perfect experience tailored to every type of traveler.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center px-4">
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-base md:text-lg px-6 md:px-8 py-4 md:py-6"
              onClick={() => window.open('https://hotellook.com', '_blank')}
            >
              <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
              Find Hotels
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-base md:text-lg px-6 md:px-8 py-4 md:py-6"
              onClick={() => window.open('https://wegotrip.com', '_blank')}
            >
              Book Tours & Activities
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
