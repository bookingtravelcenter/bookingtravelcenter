import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Car, 
  Shield, 
  Plane, 
  Ticket, 
  Navigation,
  Wifi,
  MapPin,
  CreditCard
} from "lucide-react";

const serviceCategories = [
  {
    title: "Ground Transportation",
    description: "Car rentals, transfers, and city-to-city rides",
    icon: Car,
    count: "8 Services",
    color: "from-blue-500/20 to-cyan-500/20",
    services: ["Car Rentals", "Airport Transfers", "City Rides", "Local Transport"]
  },
  {
    title: "Travel Security",
    description: "VPN, insurance, and travel protection",
    icon: Shield,
    count: "4 Services", 
    color: "from-green-500/20 to-emerald-500/20",
    services: ["VPN Protection", "Travel Insurance", "Flight Compensation", "Safety Tools"]
  },
  {
    title: "Flight Services",
    description: "Booking, compensation, and flight management",
    icon: Plane,
    count: "5 Services",
    color: "from-purple-500/20 to-violet-500/20", 
    services: ["Flight Booking", "Compensation Claims", "Travel Deals", "Cashback"]
  },
  {
    title: "Experiences & Events",
    description: "Tours, activities, and entertainment",
    icon: Ticket,
    count: "3 Services",
    color: "from-orange-500/20 to-red-500/20",
    services: ["Audio Guides", "Event Tickets", "Boat Rentals", "Local Tours"]
  },
  {
    title: "Travel Connectivity",
    description: "Stay connected anywhere in the world",
    icon: Wifi,
    count: "2 Services",
    color: "from-teal-500/20 to-cyan-500/20",
    services: ["International SIM", "Global Data", "WiFi Hotspots", "Roaming Plans"]
  },
  {
    title: "Accommodation",
    description: "Hotel bookings and lodging deals worldwide",
    icon: MapPin,
    count: "1 Service",
    color: "from-indigo-500/20 to-purple-500/20",
    services: ["Hotel Deals", "Booking Engine", "Price Comparison", "Instant Booking"]
  },
  {
    title: "Luggage & Storage",
    description: "Secure storage and luggage solutions",
    icon: MapPin,
    count: "2 Services",
    color: "from-pink-500/20 to-rose-500/20",
    services: ["Luggage Storage", "Baggage Protection", "Lost Item Recovery", "Storage Network"]
  }
];

export const ServiceCategories = () => {
  const scrollToServices = (categoryTitle: string) => {
    // Map category titles to affiliate service sections
    const sectionMap: { [key: string]: string } = {
      "Ground Transportation": "Transportation",
      "Travel Security": "Travel Essentials", 
      "Flight Services": "Flight Services",
      "Experiences & Events": "Experiences",
      "Travel Connectivity": "Travel Essentials",
      "Luggage & Storage": "Travel Essentials",
      "Accommodation": "Accommodation"
    };
    
    const targetSection = sectionMap[categoryTitle];
    if (targetSection) {
      // Scroll to the affiliate services section
      const element = document.getElementById('affiliate-services');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  return (
    <section className="py-16 md:py-20 pt-24 md:pt-16 bg-gradient-to-br from-background to-muted/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8 md:mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 leading-tight">
            Travel Service Categories
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed px-4">
            Discover our comprehensive range of travel services, organized by category for easy browsing
          </p>
        </div>

        <div className="grid gap-4 md:gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {serviceCategories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <Card 
                key={category.title}
                className="group hover:shadow-xl transition-all duration-300 cursor-pointer bg-card/50 backdrop-blur-sm border-border/50 overflow-hidden"
              >
                <div className={`h-2 bg-gradient-to-r ${category.color}`} />
                <CardHeader className="pb-3 md:pb-4 p-4 md:p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className={`flex items-center justify-center w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r ${category.color}`}>
                      <IconComponent className="h-6 w-6 md:h-7 md:w-7 text-foreground" />
                    </div>
                    <span className="text-sm md:text-base text-muted-foreground font-medium">{category.count}</span>
                  </div>
                  <CardTitle className="text-lg md:text-xl font-bold text-foreground group-hover:text-primary transition-colors leading-tight">
                    {category.title}
                  </CardTitle>
                  <CardDescription className="text-muted-foreground text-sm md:text-base leading-relaxed">
                    {category.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-4 md:p-6 pt-0">
                  <div className="flex flex-wrap gap-2">
                    {category.services.slice(0, 3).map((service, serviceIndex) => (
                      <span 
                        key={service}
                        className="px-2 py-1 text-xs md:text-sm bg-muted text-muted-foreground rounded-md font-medium"
                      >
                        {service}
                      </span>
                    ))}
                    {category.services.length > 3 && (
                      <span className="px-2 py-1 text-xs md:text-sm bg-primary/10 text-primary rounded-md font-medium">
                        +{category.services.length - 3} more
                      </span>
                    )}
                  </div>
                  <Button 
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300 h-11 md:h-10 text-base md:text-sm"
                    variant="outline"
                    onClick={() => scrollToServices(category.title)}
                  >
                    Browse Services
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Enhanced Statistics */}
        <div className="mt-12 md:mt-16 grid gap-4 md:gap-8 grid-cols-2 md:grid-cols-4 text-center">
          <div className="space-y-2 md:space-y-3 p-4 md:p-6 rounded-xl bg-gradient-to-br from-primary/5 to-primary-glow/5">
            <div className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">20+</div>
            <div className="text-xs md:text-sm text-muted-foreground font-medium">Trusted Partners</div>
          </div>
          <div className="space-y-2 md:space-y-3 p-4 md:p-6 rounded-xl bg-gradient-to-br from-secondary/20 to-muted/10">
            <div className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">7</div>
            <div className="text-xs md:text-sm text-muted-foreground font-medium">Service Categories</div>
          </div>
          <div className="space-y-2 md:space-y-3 p-4 md:p-6 rounded-xl bg-gradient-to-br from-primary/5 to-primary-glow/5">
            <div className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">100%</div>
            <div className="text-xs md:text-sm text-muted-foreground font-medium">Reliable Services</div>
          </div>
          <div className="space-y-2 md:space-y-3 p-4 md:p-6 rounded-xl bg-gradient-to-br from-secondary/20 to-muted/10">
            <div className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">24/7</div>
            <div className="text-xs md:text-sm text-muted-foreground font-medium">Customer Support</div>
          </div>
        </div>
      </div>
    </section>
  );
};