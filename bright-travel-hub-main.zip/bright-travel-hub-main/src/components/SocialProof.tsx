import { Star, Users, Shield, Award, CheckCircle } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export const SocialProof = () => {
  const trustIcons = [
    { icon: Shield, label: "Secure Payments", description: "SSL Encrypted" },
    { icon: Award, label: "Best Price Guarantee", description: "Price Match" },
    { icon: CheckCircle, label: "Instant Confirmation", description: "Real-time Booking" },
    { icon: Users, label: "2M+ Happy Customers", description: "Worldwide" }
  ];

  const testimonials = [
    {
      name: "Maria Konstantinou",
      location: "Athens, Greece",
      rating: 5,
      comment: "Απίστευτη εμπειρία! Εύκολη κράτηση και άριστη εξυπηρέτηση.",
      avatar: "/placeholder.svg"
    },
    {
      name: "John Smith",
      location: "London, UK", 
      rating: 5,
      comment: "Best travel booking platform I've ever used. Highly recommend!",
      avatar: "/placeholder.svg"
    },
    {
      name: "Sophie Martin",
      location: "Paris, France",
      rating: 5,
      comment: "Service client exceptionnel et prix imbattables. Parfait!",
      avatar: "/placeholder.svg"
    }
  ];

  const stats = [
    { number: "2M+", label: "Happy Travelers" },
    { number: "50K+", label: "Destinations" },
    { number: "4.9", label: "Average Rating" },
    { number: "24/7", label: "Support" }
  ];

  return (
    <section className="py-16 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        {/* Trust Icons */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {trustIcons.map((item, index) => (
            <div key={index} className="text-center group">
              <div className="flex justify-center mb-3">
                <div className="p-3 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="font-semibold text-sm mb-1">{item.label}</h3>
              <p className="text-xs text-muted-foreground">{item.description}</p>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                {stat.number}
              </div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Customer Reviews */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            What Our Customers Say
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Join millions of satisfied travelers who trust us for their adventures
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <Avatar className="h-12 w-12 mr-4">
                  <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                  <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>
              <div className="flex mb-3">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-sm leading-relaxed">{testimonial.comment}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};