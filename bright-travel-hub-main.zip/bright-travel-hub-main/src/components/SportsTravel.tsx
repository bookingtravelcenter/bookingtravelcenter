import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Trophy, Zap, Clock, Users, Star, Ticket } from "lucide-react";
import { useEffect } from "react";

interface SportsEvent {
  id: string;
  name: string;
  sport: string;
  location: string;
  venue: string;
  date: string;
  duration: string;
  category: string;
  image: string;
  description: string;
  highlights: string[];
  included: string[];
  price: string;
  availability: string;
  difficulty?: string;
  maxParticipants?: string;
}

const sportsEvents: SportsEvent[] = [
  {
    id: "1",
    name: "Monaco Grand Prix Formula 1",
    sport: "Formula 1",
    location: "Monte Carlo, Monaco",
    venue: "Circuit de Monaco",
    date: "May 24-26, 2024",
    duration: "3 days",
    category: "Motor Sports",
    image: "/src/assets/city-tours.jpg",
    description: "Experience the most prestigious F1 race on the planet with glamour, speed, and luxury in the heart of Monaco.",
    highlights: ["VIP Grandstand seats", "Paddock Club access", "Luxury yacht viewing", "Monaco Casino visit"],
    included: ["3-day race tickets", "Luxury accommodation", "Private transfers", "Welcome champagne"],
    price: "$8,999",
    availability: "Limited seats"
  },
  {
    id: "2",
    name: "Wimbledon Tennis Championships",
    sport: "Tennis",
    location: "London, England",
    venue: "All England Club",
    date: "June 29 - July 12, 2024",
    duration: "14 days",
    category: "Tennis",
    image: "/src/assets/paris.jpg",
    description: "Witness tennis history at the world's most prestigious tennis tournament with traditional strawberries and cream.",
    highlights: ["Centre Court finals", "Debenture seats", "Strawberries & cream", "Traditional atmosphere"],
    included: ["Tournament tickets", "London hotel", "Afternoon tea", "Ground transportation"],
    price: "$4,299",
    availability: "Few spots left"
  },
  {
    id: "3",
    name: "NBA Finals Experience",
    sport: "Basketball",
    location: "Various US Cities",
    venue: "NBA Arenas",
    date: "June 2024",
    duration: "7 days",
    category: "Basketball",
    image: "/src/assets/adventure-tours.jpg",
    description: "Be part of basketball history at the NBA Finals with courtside experiences and meet-and-greets.",
    highlights: ["Courtside seats", "Player meet & greet", "Arena tours", "VIP hospitality"],
    included: ["Game tickets", "Hotel accommodation", "Pre-game events", "Team merchandise"],
    price: "$6,799",
    availability: "Selling fast"
  },
  {
    id: "4",
    name: "UEFA Champions League Final",
    sport: "Football",
    location: "Wembley Stadium, London",
    venue: "Wembley Stadium",
    date: "May 25, 2024",
    duration: "3 days",
    category: "Football",
    image: "/src/assets/beach-resort.jpg",
    description: "Experience European football's biggest night with premium hospitality and legendary atmosphere.",
    highlights: ["Premium seats", "Pre-match hospitality", "Trophy photo", "Legend appearances"],
    included: ["Match ticket", "Hotel stay", "Welcome dinner", "Stadium tour"],
    price: "$3,999",
    availability: "Very limited"
  },
  {
    id: "5",
    name: "Skydiving World Championships",
    sport: "Skydiving",
    location: "Arizona, USA",
    venue: "Skydive Arizona",
    date: "October 2024",
    duration: "5 days",
    category: "Extreme Sports",
    image: "/src/assets/adventure-tours.jpg",
    description: "Watch the world's best skydivers compete while experiencing tandem jumps and formation flying.",
    highlights: ["Competition viewing", "Tandem jump included", "Formation flying", "Desert landscape"],
    included: ["Spectator passes", "Tandem skydive", "Accommodation", "Safety equipment"],
    price: "$2,199",
    availability: "Open",
    difficulty: "Beginner friendly",
    maxParticipants: "12 per group"
  },
  {
    id: "6",
    name: "Red Bull Air Race Championship",
    sport: "Air Racing",
    location: "Various Locations",
    venue: "Multiple Venues",
    date: "Season 2024",
    duration: "Weekend packages",
    category: "Extreme Sports",
    image: "/src/assets/cruise-banner.jpg",
    description: "Witness high-speed aerial racing with pilots navigating through air gates at incredible speeds.",
    highlights: ["Air show experience", "Pilot meet & greet", "VIP viewing areas", "Behind-scenes access"],
    included: ["Event tickets", "VIP hospitality", "Transfers", "Commemorative gear"],
    price: "$1,799",
    availability: "Multiple dates"
  }
];

const sportsCategories = [
  { name: "Motor Sports", icon: Zap, count: 4, color: "bg-accent" },
  { name: "Tennis", icon: Trophy, count: 8, color: "bg-tropical-green" },
  { name: "Basketball", icon: Users, count: 3, color: "bg-sunset-orange" },
  { name: "Football", icon: Trophy, count: 12, color: "bg-ocean-blue" },
  { name: "Extreme Sports", icon: Zap, count: 15, color: "bg-warm-coral" }
];

const upcomingEvents = [
  { event: "Australian Open", date: "Jan 14-27", sport: "Tennis", location: "Melbourne" },
  { event: "Super Bowl LVIII", date: "Feb 11", sport: "American Football", location: "Las Vegas" },
  { event: "Bahrain Grand Prix", date: "Mar 2", sport: "Formula 1", location: "Bahrain" },
  { event: "Masters Tournament", date: "Apr 11-14", sport: "Golf", location: "Augusta" },
  { event: "Champions League Final", date: "May 25", sport: "Football", location: "London" },
  { event: "French Open", date: "May 26 - Jun 9", sport: "Tennis", location: "Paris" }
];

export const SportsTravel = () => {
  useEffect(() => {
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "TravelGuide",
      "name": "Sports Travel & Events Guide",
      "description": "Premium sports travel experiences including Formula 1, tennis championships, basketball finals, and extreme sports adventures",
      "publisher": {
        "@type": "Organization",
        "name": "TravelEase"
      },
      "mainEntity": sportsEvents.map(event => ({
        "@type": "SportsEvent",
        "name": event.name,
        "sport": event.sport,
        "location": {
          "@type": "Place",
          "name": event.location,
          "address": event.venue
        },
        "startDate": event.date,
        "description": event.description,
        "offers": {
          "@type": "Offer",
          "price": event.price,
          "priceCurrency": "USD",
          "availability": "https://schema.org/InStock"
        }
      }))
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <section className="py-16 bg-gradient-to-br from-background via-muted to-secondary">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Sports Travel Experiences
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From Formula 1 Grand Prix to tennis championships and extreme sports adventures. Experience the world's greatest sporting events with premium hospitality and unforgettable moments.
          </p>
        </div>

        {/* Sports Categories */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
          {sportsCategories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <Card key={index} className="text-center hover:shadow-card transition-all duration-200 cursor-pointer group">
                <CardContent className="p-4">
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full ${category.color} text-white mb-3 group-hover:scale-110 transition-transform`}>
                    <IconComponent className="h-6 w-6" />
                  </div>
                  <h3 className="font-semibold text-card-foreground text-sm mb-1">{category.name}</h3>
                  <p className="text-xs text-muted-foreground">{category.count} events</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Featured Sports Events */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-16">
          {sportsEvents.map((event) => (
            <Card key={event.id} className="group hover:shadow-travel transition-all duration-300 border-0 bg-card/90 backdrop-blur-sm overflow-hidden">
              <div className="relative">
                <img 
                  src={event.image}
                  alt={`${event.name} at ${event.venue}`}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground font-medium">
                  {event.category}
                </Badge>
                <Badge 
                  className={`absolute top-4 right-4 text-xs ${
                    event.availability === 'Very limited' ? 'bg-destructive' :
                    event.availability === 'Limited seats' ? 'bg-accent' :
                    event.availability === 'Few spots left' ? 'bg-sunset-orange' :
                    'bg-tropical-green'
                  } text-white`}
                >
                  {event.availability}
                </Badge>
                <div className="absolute bottom-4 left-4 text-white">
                  <div className="flex items-center gap-1 mb-1">
                    <Calendar className="h-4 w-4" />
                    <span className="text-sm font-medium">{event.date}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span className="text-xs">{event.location}</span>
                  </div>
                </div>
              </div>

              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-card-foreground line-clamp-2">
                  {event.name}
                </CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Trophy className="h-4 w-4 text-accent" />
                  <span>{event.sport}</span>
                  <span>•</span>
                  <Clock className="h-4 w-4 text-accent" />
                  <span>{event.duration}</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {event.description}
                </p>

                {/* Event Highlights */}
                <div>
                  <h4 className="font-medium text-card-foreground text-sm mb-2">Event Highlights</h4>
                  <div className="grid grid-cols-2 gap-1">
                    {event.highlights.slice(0, 4).map((highlight, index) => (
                      <div key={index} className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Star className="h-3 w-3 text-accent" />
                        <span className="truncate">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* What's Included */}
                <div>
                  <h4 className="font-medium text-card-foreground text-sm mb-2">Package Includes</h4>
                  <div className="flex flex-wrap gap-1">
                    {event.included.slice(0, 3).map((item, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {item}
                      </Badge>
                    ))}
                    {event.included.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{event.included.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Additional Info for Extreme Sports */}
                {event.difficulty && (
                  <div className="bg-muted/50 rounded-lg p-3 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Difficulty:</span>
                      <span className="font-medium text-card-foreground">{event.difficulty}</span>
                    </div>
                    {event.maxParticipants && (
                      <div className="flex justify-between mt-1">
                        <span className="text-muted-foreground">Group size:</span>
                        <span className="font-medium text-card-foreground">{event.maxParticipants}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Price and Booking */}
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div>
                    <span className="text-2xl font-bold text-primary">{event.price}</span>
                    <span className="text-sm text-muted-foreground">/person</span>
                  </div>
                  <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    <Ticket className="h-4 w-4 mr-1" />
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Upcoming Events Calendar */}
        <div className="bg-card/80 backdrop-blur-sm rounded-xl p-8 border mb-12">
          <h3 className="text-2xl font-semibold text-foreground mb-6 flex items-center gap-2">
            <Calendar className="h-6 w-6 text-primary" />
            Upcoming Sports Calendar 2024
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="flex items-center gap-3 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="text-center">
                  <div className="text-lg font-bold text-primary">{event.date.split(' ')[1] || event.date.split(' ')[0]}</div>
                  <div className="text-xs text-muted-foreground">{event.date.split(' ')[0]}</div>
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-card-foreground text-sm">{event.event}</h4>
                  <p className="text-xs text-muted-foreground">{event.sport} • {event.location}</p>
                </div>
                <Button variant="outline" size="sm" className="text-xs">
                  View
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center bg-hero-gradient rounded-2xl p-8 text-white">
          <h3 className="text-3xl font-bold mb-4">Ready for the Ultimate Sports Experience?</h3>
          <p className="text-lg mb-6 max-w-2xl mx-auto">
            Join thousands of sports fans who have experienced the thrill of live sporting events with our premium travel packages.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-white/90">
              Browse All Events
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              Custom Sports Package
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};