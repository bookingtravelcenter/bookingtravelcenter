import adventureToursImage from "@/assets/adventure-tours.jpg";
import cruiseBannerImage from "@/assets/cruise-banner.jpg";
import cityToursImage from "@/assets/city-tours.jpg";
import beachResortImage from "@/assets/beach-resort.jpg";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Clock, Users } from "lucide-react";

export const ToursSection = () => {
  const tourPackages = [
    {
      image: adventureToursImage,
      title: "Mountain Adventure Tours",
      description: "Epic hiking and climbing experiences in breathtaking mountain landscapes",
      duration: "7 Days",
      groupSize: "8-12 People",
      rating: 4.9,
      price: "$1,299",
      location: "Swiss Alps",
      highlights: ["Professional Guide", "All Equipment", "Mountain Hut Stay"],
      badge: "Adventure"
    },
    {
      image: cruiseBannerImage,
      title: "Mediterranean Cruise",
      description: "Luxury cruise through the most beautiful Mediterranean destinations",
      duration: "10 Days",
      groupSize: "200+ Guests",
      rating: 4.8,
      price: "$2,599",
      location: "Mediterranean Sea",
      highlights: ["All Inclusive", "Shore Excursions", "Premium Dining"],
      badge: "Luxury"
    },
    {
      image: cityToursImage,
      title: "Cultural City Tours",
      description: "Discover rich history, art, and architecture in Europe's greatest cities",
      duration: "5 Days",
      groupSize: "15-20 People",
      rating: 4.7,
      price: "$899",
      location: "European Cities",
      highlights: ["Expert Guide", "Museum Access", "Local Cuisine"],
      badge: "Cultural"
    },
    {
      image: beachResortImage,
      title: "Tropical Paradise Escape",
      description: "Relax and unwind in luxurious beachfront resorts with pristine beaches",
      duration: "6 Days",
      groupSize: "Any Size",
      rating: 4.9,
      price: "$1,799",
      location: "Maldives",
      highlights: ["Beach Villa", "Spa Access", "Water Sports"],
      badge: "Relaxation"
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-hero-gradient bg-clip-text text-transparent">
            Unforgettable Tours & Experiences
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From thrilling adventures to cultural discoveries, find the perfect tour that matches your travel dreams
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {tourPackages.map((tour, index) => (
            <Card key={index} className="group overflow-hidden hover:shadow-elegant transition-all duration-300 bg-card/50 backdrop-blur-sm border-border/50">
              <div className="relative">
                <div className="aspect-[16/9] overflow-hidden">
                  <img
                    src={tour.image}
                    alt={tour.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground">
                  {tour.badge}
                </Badge>
                <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm rounded-lg px-3 py-2">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-semibold">{tour.rating}</span>
                  </div>
                </div>
              </div>
              
              <CardContent className="p-6">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                  <MapPin className="w-4 h-4" />
                  <span>{tour.location}</span>
                </div>
                
                <h3 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">
                  {tour.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 line-clamp-2">
                  {tour.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-primary" />
                    <span>{tour.duration}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-primary" />
                    <span>{tour.groupSize}</span>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {tour.highlights.map((highlight, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm text-muted-foreground">Starting from</span>
                    <div className="text-2xl font-bold text-primary">{tour.price}</div>
                  </div>
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
            View All Tours & Packages
          </Button>
        </div>
      </div>
    </section>
  );
};