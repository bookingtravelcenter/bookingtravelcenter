import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Language imports
import enTranslations from '@/translations/en.json';
import esTranslations from '@/translations/es.json';
import frTranslations from '@/translations/fr.json';
import deTranslations from '@/translations/de.json';
import itTranslations from '@/translations/it.json';

export type SupportedLanguage = 'en' | 'es' | 'fr' | 'de' | 'it' | 'pt' | 'ru' | 'zh' | 'ja' | 'ko' | 'ar' | 'hi' | 'el';

type Translations = typeof enTranslations;

interface TranslationContextType {
  currentLanguage: SupportedLanguage;
  setLanguage: (language: SupportedLanguage) => void;
  t: (key: string) => string;
  translations: Translations;
}

// Translation data
const translationData: Record<SupportedLanguage, Translations> = {
  en: enTranslations,
  es: esTranslations,
  fr: frTranslations,
  de: deTranslations,
  it: itTranslations,
  // For languages without translation files, fall back to English
  pt: enTranslations, // Portuguese fallback
  ru: enTranslations, // Russian fallback
  zh: enTranslations, // Chinese fallback
  ja: enTranslations, // Japanese fallback
  ko: enTranslations, // Korean fallback
  ar: enTranslations, // Arabic fallback
  hi: enTranslations, // Hindi fallback
  el: enTranslations, // Greek fallback
};

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const TranslationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<SupportedLanguage>('en');

  useEffect(() => {
    // Try to get language from localStorage or browser
    const savedLanguage = localStorage.getItem('preferredLanguage') as SupportedLanguage;
    if (savedLanguage && translationData[savedLanguage]) {
      setCurrentLanguage(savedLanguage);
    } else {
      // Detect browser language
      const browserLanguage = navigator.language.split('-')[0] as SupportedLanguage;
      if (translationData[browserLanguage]) {
        setCurrentLanguage(browserLanguage);
      }
    }
  }, []);

  const setLanguage = (language: SupportedLanguage) => {
    setCurrentLanguage(language);
    localStorage.setItem('preferredLanguage', language);
    document.documentElement.lang = language;
  };

  const getNestedValue = (obj: any, path: string): string => {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : null;
    }, obj);
  };

  const t = (key: string): string => {
    const translation = getNestedValue(translationData[currentLanguage], key);
    
    // If translation not found in current language, try English as fallback
    if (!translation && currentLanguage !== 'en') {
      const englishTranslation = getNestedValue(translationData.en, key);
      return englishTranslation || key;
    }
    
    return translation || key;
  };

  return (
    <TranslationContext.Provider 
      value={{ 
        currentLanguage, 
        setLanguage, 
        t, 
        translations: translationData[currentLanguage] 
      }}
    >
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
};