import { useState, useEffect } from 'react';

interface BookingData {
  confirmationNumber: string;
  destination: string;
  departureDate: string;
  returnDate?: string;
  passengers: number;
  totalAmount: string;
  bookingType: 'flight' | 'hotel' | 'car' | 'tour';
  // Flight specific
  airline?: string;
  flightNumber?: string;
  // Hotel specific
  hotelName?: string;
  roomType?: string;
  // Car specific
  carModel?: string;
  pickupLocation?: string;
}

interface CrossSellSettings {
  autoShowDelay: number; // seconds
  showOnPurchaseComplete: boolean;
  showOnSearchResults: boolean;
  maxOffersToShow: number;
}

export const useCrossSellTrigger = (
  bookingData?: BookingData,
  settings: CrossSellSettings = {
    autoShowDelay: 10,
    showOnPurchaseComplete: true,
    showOnSearchResults: false,
    maxOffersToShow: 6
  }
) => {
  const [showCrossSell, setShowCrossSell] = useState(false);
  const [countdown, setCountdown] = useState(settings.autoShowDelay);
  const [userInteracted, setUserInteracted] = useState(false);

  // Auto-trigger cross-sell after purchase
  useEffect(() => {
    if (bookingData && settings.showOnPurchaseComplete && !userInteracted) {
      const timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            setShowCrossSell(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [bookingData, settings.showOnPurchaseComplete, userInteracted]);

  // Track user interactions to prevent auto-show
  useEffect(() => {
    const handleUserInteraction = () => setUserInteracted(true);
    
    window.addEventListener('click', handleUserInteraction);
    window.addEventListener('scroll', handleUserInteraction);
    window.addEventListener('keydown', handleUserInteraction);

    return () => {
      window.removeEventListener('click', handleUserInteraction);
      window.removeEventListener('scroll', handleUserInteraction);
      window.removeEventListener('keydown', handleUserInteraction);
    };
  }, []);

  const triggerCrossSell = () => {
    setShowCrossSell(true);
    setUserInteracted(true);
  };

  const closeCrossSell = () => {
    setShowCrossSell(false);
    setUserInteracted(true);
  };

  const resetTrigger = () => {
    setShowCrossSell(false);
    setCountdown(settings.autoShowDelay);
    setUserInteracted(false);
  };

  return {
    showCrossSell,
    countdown,
    triggerCrossSell,
    closeCrossSell,
    resetTrigger,
    userInteracted
  };
};