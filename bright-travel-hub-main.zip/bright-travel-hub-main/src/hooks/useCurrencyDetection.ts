import { useState, useEffect } from 'react';

export type Currency = 'EUR' | 'USD';
export type CurrencySymbol = '€' | '$';

interface CurrencyInfo {
  currency: Currency;
  symbol: CurrencySymbol;
  country: string | null;
}

// European countries that use EUR or are likely to prefer EUR pricing
const europeanCountries = [
  'AD', 'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE',
  'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO',
  'SK', 'SI', 'ES', 'SE', 'GB', 'NO', 'IS', 'CH', 'LI', 'MC', 'SM', 'VA',
  'RS', 'BA', 'ME', 'MK', 'AL', 'MD', 'UA', 'BY', 'RU'
];

export const useCurrencyDetection = () => {
  const [currencyInfo, setCurrencyInfo] = useState<CurrencyInfo>({
    currency: 'USD',
    symbol: '$',
    country: null
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const detectCurrency = async () => {
      try {
        // Try to get country from IP geolocation
        const response = await fetch('https://ipapi.co/json/');
        const data = await response.json();
        
        if (data.country_code) {
          const isEuropean = europeanCountries.includes(data.country_code.toUpperCase());
          
          setCurrencyInfo({
            currency: isEuropean ? 'EUR' : 'USD',
            symbol: isEuropean ? '€' : '$',
            country: data.country
          });
        }
      } catch (error) {
        console.warn('Could not detect location, defaulting to USD:', error);
        // Fallback: try browser language
        const browserLang = navigator.language || navigator.languages[0];
        const isEuropeanLang = browserLang && (
          browserLang.includes('de') || 
          browserLang.includes('fr') || 
          browserLang.includes('it') || 
          browserLang.includes('es') || 
          browserLang.includes('nl') ||
          browserLang.includes('pl') ||
          browserLang.includes('pt')
        );
        
        setCurrencyInfo({
          currency: isEuropeanLang ? 'EUR' : 'USD',
          symbol: isEuropeanLang ? '€' : '$',
          country: null
        });
      } finally {
        setLoading(false);
      }
    };

    detectCurrency();
  }, []);

  const formatPrice = (amount: number): string => {
    // Convert USD base price to EUR if needed (approximate conversion)
    const convertedAmount = currencyInfo.currency === 'EUR' ? amount * 0.85 : amount;
    
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyInfo.currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(convertedAmount);
  };

  const setCurrency = (currency: Currency) => {
    setCurrencyInfo(prev => ({
      ...prev,
      currency,
      symbol: currency === 'EUR' ? '€' : '$'
    }));
  };

  return {
    ...currencyInfo,
    loading,
    formatPrice,
    setCurrency
  };
};