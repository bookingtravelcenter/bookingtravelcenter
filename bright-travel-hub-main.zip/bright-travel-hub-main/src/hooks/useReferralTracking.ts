import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useReferralTracking = () => {
  useEffect(() => {
    // Track referral clicks when page loads
    const trackReferralClick = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const referralCode = urlParams.get('ref');
      
      if (referralCode) {
        try {
          // Store referral code in localStorage for later use
          localStorage.setItem('referral_code', referralCode);
          
          // Get referrer info
          const { data: referrerData } = await supabase
            .from('customer_referrals')
            .select('user_id')
            .eq('referral_code', referralCode)
            .single();
          
          if (referrerData) {
            // Track the click
            await supabase
              .from('referral_clicks')
              .insert({
                referral_code: referralCode,
                referrer_user_id: referrerData.user_id,
                ip_address: null, // Would need to implement IP detection
                user_agent: navigator.userAgent
              });
          }
        } catch (error) {
          console.error('Error tracking referral click:', error);
        }
      }
    };

    trackReferralClick();
  }, []);

  const processReferralPurchase = async (
    purchaseAmount: number,
    purchaseType: string,
    purchaseReference: string
  ) => {
    try {
      const referralCode = localStorage.getItem('referral_code');
      if (!referralCode) return false;

      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return false;

      // Process the referral purchase
      const { data, error } = await supabase.rpc('process_referral_purchase', {
        referral_code: referralCode,
        customer_id: user.user.id,
        amount: purchaseAmount
      });

      if (!error && data) {
        // Clear the referral code after successful processing
        localStorage.removeItem('referral_code');
        return true;
      }
    } catch (error) {
      console.error('Error processing referral purchase:', error);
    }
    
    return false;
  };

  return {
    processReferralPurchase
  };
};