/**
 * Security utilities for input validation and sanitization
 */

// Input validation patterns
export const ValidationPatterns = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^\+?[\d\s-()]+$/,
  alphanumeric: /^[a-zA-Z0-9\s]+$/,
  safeText: /^[a-zA-Z0-9\s.,!?-]+$/,
} as const;

// Sanitize user input to prevent XSS
export const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: protocols
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim();
};

// Validate email format
export const isValidEmail = (email: string): boolean => {
  return ValidationPatterns.email.test(email.trim());
};

// Validate phone number format
export const isValidPhone = (phone: string): boolean => {
  return ValidationPatterns.phone.test(phone.trim());
};

// Check if text contains only safe characters
export const isSafeText = (text: string): boolean => {
  return ValidationPatterns.safeText.test(text);
};

// Rate limiting helper for form submissions
export class RateLimiter {
  private attempts: Map<string, number[]> = new Map();

  isAllowed(key: string, maxAttempts: number = 5, windowMs: number = 60000): boolean {
    const now = Date.now();
    const attempts = this.attempts.get(key) || [];
    
    // Remove old attempts outside the time window
    const recentAttempts = attempts.filter(time => now - time < windowMs);
    
    if (recentAttempts.length >= maxAttempts) {
      return false;
    }
    
    recentAttempts.push(now);
    this.attempts.set(key, recentAttempts);
    return true;
  }

  reset(key: string): void {
    this.attempts.delete(key);
  }
}

// Global rate limiter instance
export const globalRateLimiter = new RateLimiter();

// Security headers checker (for development)
export const checkSecurityHeaders = (): void => {
  if (process.env.NODE_ENV === 'development') {
    const warnings: string[] = [];
    
    // Check for common security issues in development
    if (window.location.protocol !== 'https:' && window.location.hostname !== 'localhost') {
      warnings.push('Application should use HTTPS in production');
    }
    
    if (warnings.length > 0) {
      console.warn('Security warnings:', warnings);
    }
  }
};