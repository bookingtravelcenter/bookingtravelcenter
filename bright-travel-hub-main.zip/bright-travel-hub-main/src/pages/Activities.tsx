import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Users, Clock, Star, Camera, Mountain, Waves } from "lucide-react";
import { BookingModal } from "@/components/BookingModal";

const Activities = () => {
  const [destination, setDestination] = useState("");
  const [selectedActivity, setSelectedActivity] = useState<any>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const activities = [
    {
      id: 1,
      name: "Helicopter Tour over NYC",
      location: "New York City, USA",
      category: "Aerial Tours",
      duration: "30 minutes",
      price: "$299",
      rating: 4.9,
      reviews: 1250,
      image: "/placeholder.svg",
      description: "See Manhattan from above on this thrilling helicopter tour",
      highlights: ["Statue of Liberty", "Central Park", "Empire State Building"],
      group_size: "Up to 6 people"
    },
    {
      id: 2,
      name: "Santorini Sunset Cruise",
      location: "Santorini, Greece",
      category: "Boat Tours", 
      duration: "5 hours",
      price: "$189",
      rating: 4.8,
      reviews: 890,
      image: "/placeholder.svg",
      description: "Sail around Santorini's caldera with dinner and wine",
      highlights: ["Sunset Views", "Swimming Stops", "Traditional Dinner"],
      group_size: "Small group"
    },
    {
      id: 3,
      name: "Tokyo Food Walking Tour",
      location: "Tokyo, Japan",
      category: "Food Tours",
      duration: "4 hours",
      price: "$129",
      rating: 4.7,
      reviews: 2100,
      image: "/placeholder.svg", 
      description: "Discover authentic Japanese cuisine in local neighborhoods",
      highlights: ["Tsukiji Market", "Ramen Tasting", "Local Guide"],
      group_size: "Max 12 people"
    },
    {
      id: 4,
      name: "Northern Lights Hunt",
      location: "Reykjavik, Iceland",
      category: "Nature Tours",
      duration: "6 hours",
      price: "$159",
      rating: 4.6,
      reviews: 670,
      image: "/placeholder.svg",
      description: "Chase the Aurora Borealis with expert local guides",
      highlights: ["Aurora Forecast", "Hot Chocolate", "Photography Tips"],
      group_size: "Small group"
    },
    {
      id: 5,
      name: "Safari Game Drive",
      location: "Serengeti, Tanzania", 
      category: "Wildlife",
      duration: "Full day",
      price: "$459",
      rating: 4.9,
      reviews: 450,
      image: "/placeholder.svg",
      description: "Witness the Great Migration and Big Five animals",
      highlights: ["Big Five Animals", "Migration Viewing", "Expert Ranger"],
      group_size: "Private vehicle"
    },
    {
      id: 6,
      name: "Machu Picchu Hike",
      location: "Cusco, Peru",
      category: "Adventure",
      duration: "2 days",
      price: "$389",
      rating: 4.8,
      reviews: 1100,
      image: "/placeholder.svg",
      description: "Trek the ancient Inca Trail to the lost city",
      highlights: ["Inca Ruins", "Mountain Views", "Guided Trek"],
      group_size: "Max 16 people"
    }
  ];

  const categories = [
    { name: "All Activities", icon: MapPin, count: activities.length },
    { name: "Adventure", icon: Mountain, count: 1 },
    { name: "Tours", icon: Camera, count: 3 },
    { name: "Water Activities", icon: Waves, count: 2 }
  ];

  const handleBookActivity = (activity: any) => {
    setSelectedActivity(activity);
    setIsBookingOpen(true);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Activities & Experiences - TravelEase", 
    "description": "Book amazing travel activities and experiences worldwide"
  };

  return (
    <>
      <SEOHead 
        title="Activities & Experiences - Book Tours & Adventures | TravelEase"
        description="Discover and book amazing travel activities, tours, and experiences worldwide. From helicopter tours to food walks, create unforgettable memories."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-purple-500/10 to-pink-500/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Activities & Experiences
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Discover unique adventures, cultural tours, and unforgettable experiences at your destination.
              </p>
              
              {/* Search Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-3xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Where are you going?"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      className="pl-10"
                    />
                  </div>
                  <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600">
                    Find Activities
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Categories */}
          <section className="py-8 px-4 border-b">
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-wrap justify-center gap-4">
                {categories.map((category) => (
                  <Button
                    key={category.name}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <category.icon className="h-4 w-4" />
                    {category.name}
                    <Badge variant="secondary" className="ml-1">
                      {category.count}
                    </Badge>
                  </Button>
                ))}
              </div>
            </div>
          </section>

          {/* Activities Grid */}
          <section className="py-16 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">Popular Experiences</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {activities.map((activity) => (
                  <Card key={activity.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-video bg-muted relative">
                      <img 
                        src={activity.image} 
                        alt={activity.name}
                        className="w-full h-full object-cover"
                      />
                      <Badge className="absolute top-4 right-4 bg-purple-600">
                        {activity.category}
                      </Badge>
                    </div>
                    <CardHeader>
                      <CardTitle className="flex justify-between items-start">
                        <div>
                          <div className="text-lg">{activity.name}</div>
                          <div className="text-sm font-normal text-muted-foreground flex items-center mt-1">
                            <MapPin className="h-3 w-3 mr-1" />
                            {activity.location}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">{activity.price}</div>
                          <div className="text-sm text-muted-foreground">per person</div>
                        </div>
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{activity.rating}</span>
                        <span className="text-sm text-muted-foreground">({activity.reviews} reviews)</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="mb-4">
                        {activity.description}
                      </CardDescription>
                      
                      <div className="space-y-3 mb-4">
                        <div className="flex items-center text-sm">
                          <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                          Duration: {activity.duration}
                        </div>
                        <div className="flex items-center text-sm">
                          <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                          {activity.group_size}
                        </div>
                      </div>

                      <div className="mb-4">
                        <h4 className="font-semibold mb-2">Highlights:</h4>
                        <div className="flex flex-wrap gap-1">
                          {activity.highlights.map((highlight) => (
                            <Badge key={highlight} variant="secondary" className="text-xs">
                              {highlight}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600" 
                        onClick={() => handleBookActivity(activity)}
                      >
                        Book Experience
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
        
        {selectedActivity && (
          <BookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            bookingType="activity"
            title={selectedActivity.name}
            price={selectedActivity.price}
            location={selectedActivity.location}
          />
        )}
      </div>
    </>
  );
};

export default Activities;