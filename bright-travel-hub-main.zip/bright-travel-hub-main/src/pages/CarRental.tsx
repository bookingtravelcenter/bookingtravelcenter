import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Car, Calendar, MapPin, Users, Fuel, Settings, Shield } from "lucide-react";
import { BookingModal } from "@/components/BookingModal";

const CarRental = () => {
  const [pickupLocation, setPickupLocation] = useState("");
  const [selectedCar, setSelectedCar] = useState<any>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const cars = [
    {
      id: 1,
      name: "Economy Car",
      model: "Toyota Corolla or similar",
      category: "Economy",
      passengers: 5,
      bags: 2,
      transmission: "Automatic",
      fuel: "Petrol",
      price: "$45",
      image: "/placeholder.svg",
      features: ["Air Conditioning", "Bluetooth", "GPS"]
    },
    {
      id: 2,
      name: "SUV",
      model: "Ford Explorer or similar",
      category: "SUV",
      passengers: 7,
      bags: 4,
      transmission: "Automatic",
      fuel: "Petrol",
      price: "$89",
      image: "/placeholder.svg",
      features: ["Air Conditioning", "Bluetooth", "GPS", "4WD"]
    },
    {
      id: 3,
      name: "Luxury Sedan",
      model: "BMW 5 Series or similar",
      category: "Luxury",
      passengers: 5,
      bags: 3,
      transmission: "Automatic",
      fuel: "Petrol",
      price: "$129",
      image: "/placeholder.svg",
      features: ["Air Conditioning", "Bluetooth", "GPS", "Leather Seats", "Premium Sound"]
    }
  ];

  const handleBookCar = (car: any) => {
    setSelectedCar(car);
    setIsBookingOpen(true);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Car Rental - TravelEase",
    "description": "Rent a car for your next trip with the best deals"
  };

  return (
    <>
      <SEOHead 
        title="Car Rental - Rent a Car Today | TravelEase"
        description="Find the perfect rental car for your trip. Choose from economy cars, SUVs, luxury vehicles and more with competitive prices."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-orange-500/10 to-red-500/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                Rent the Perfect Car
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Choose from our wide selection of vehicles, from economy cars to luxury SUVs. Great prices and excellent service.
              </p>
              
              {/* Search Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-3xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Pickup location"
                      value={pickupLocation}
                      onChange={(e) => setPickupLocation(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      className="pl-10"
                    />
                  </div>
                  <Button size="lg">
                    Search Cars
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Cars Grid */}
          <section className="py-16 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">Available Vehicles</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {cars.map((car) => (
                  <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-video bg-muted relative">
                      <img 
                        src={car.image} 
                        alt={car.name}
                        className="w-full h-full object-cover"
                      />
                      <Badge className="absolute top-4 right-4 bg-primary">
                        {car.category}
                      </Badge>
                    </div>
                    <CardHeader>
                      <CardTitle className="flex justify-between items-start">
                        <div>
                          <div>{car.name}</div>
                          <div className="text-sm font-normal text-muted-foreground">{car.model}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">{car.price}</div>
                          <div className="text-sm text-muted-foreground">per day</div>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center text-sm">
                          <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                          {car.passengers} passengers
                        </div>
                        <div className="flex items-center text-sm">
                          <Car className="h-4 w-4 mr-2 text-muted-foreground" />
                          {car.bags} bags
                        </div>
                        <div className="flex items-center text-sm">
                          <Settings className="h-4 w-4 mr-2 text-muted-foreground" />
                          {car.transmission}
                        </div>
                        <div className="flex items-center text-sm">
                          <Fuel className="h-4 w-4 mr-2 text-muted-foreground" />
                          {car.fuel}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <h4 className="font-semibold mb-2">Features:</h4>
                        <div className="flex flex-wrap gap-1">
                          {car.features.map((feature) => (
                            <Badge key={feature} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full" 
                        onClick={() => handleBookCar(car)}
                      >
                        Book Now
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
        
        {selectedCar && (
          <BookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            bookingType="car_rental"
            title={selectedCar.name}
            price={selectedCar.price}
            location={selectedCar.model}
          />
        )}
      </div>
    </>
  );
};

export default CarRental;