import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Anchor, Calendar, MapPin, Users, Clock, Star } from "lucide-react";
import { BookingModal } from "@/components/BookingModal";
import cruiseBanner from "@/assets/cruise-banner.jpg";

const Cruises = () => {
  const [destination, setDestination] = useState("");
  const [selectedCruise, setSelectedCruise] = useState<any>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const cruises = [
    {
      id: 1,
      name: "Mediterranean Paradise",
      cruise_line: "Royal Caribbean",
      destination: "Mediterranean",
      duration: "7 Days",
      ports: ["Barcelona", "Rome", "Naples", "Florence"],
      departure_date: "2024-06-15",
      price: "$1,299",
      original_price: "$1,599",
      rating: 4.8,
      image: cruiseBanner,
      ship: "Symphony of the Seas",
      features: ["All Meals", "Entertainment", "Pools", "Spa", "Casino"]
    },
    {
      id: 2,
      name: "Caribbean Explorer",
      cruise_line: "Norwegian Cruise Line",
      destination: "Caribbean",
      duration: "10 Days",
      ports: ["Miami", "Cozumel", "Jamaica", "Grand Cayman"],
      departure_date: "2024-07-08",
      price: "$1,899",
      original_price: "$2,299",
      rating: 4.7,
      image: cruiseBanner,
      ship: "Norwegian Epic",
      features: ["All Meals", "Broadway Shows", "Water Parks", "Restaurants"]
    },
    {
      id: 3,
      name: "Alaska Adventure", 
      cruise_line: "Princess Cruises",
      destination: "Alaska",
      duration: "14 Days",
      ports: ["Seattle", "Juneau", "Skagway", "Ketchikan"],
      departure_date: "2024-08-12",
      price: "$2,499",
      original_price: "$2,999",
      rating: 4.9,
      image: cruiseBanner,
      ship: "Crown Princess",
      features: ["Glacier Views", "Wildlife Tours", "Fine Dining", "Balcony Rooms"]
    },
    {
      id: 4,
      name: "Northern Lights",
      cruise_line: "Hurtigruten",
      destination: "Norway",
      duration: "12 Days",
      ports: ["Bergen", "Trondheim", "Tromsø", "Honningsvåg"],
      departure_date: "2024-09-20",
      price: "$3,299",
      original_price: "$3,799",
      rating: 4.6,
      image: cruiseBanner,
      ship: "MS Nordkapp",
      features: ["Aurora Viewing", "Expedition Teams", "Lectures", "Zodiac Tours"]
    },
    {
      id: 5,
      name: "Greek Isles Discovery",
      cruise_line: "Celebrity Cruises",
      destination: "Greek Islands",
      duration: "8 Days",
      ports: ["Athens", "Mykonos", "Santorini", "Rhodes"],
      departure_date: "2024-05-25",
      price: "$1,799",
      original_price: "$2,199",
      rating: 4.8,
      image: cruiseBanner,
      ship: "Celebrity Edge",
      features: ["Rooftop Garden", "Magic Carpet", "Fine Dining", "Spa"]
    },
    {
      id: 6,
      name: "Asian Highlights",
      cruise_line: "Princess Cruises",
      destination: "Asia",
      duration: "15 Days",
      ports: ["Singapore", "Bangkok", "Ho Chi Minh", "Hong Kong"],
      departure_date: "2024-10-15",
      price: "$2,899",
      original_price: "$3,499",
      rating: 4.7,
      image: cruiseBanner,
      ship: "Diamond Princess",
      features: ["Cultural Immersion", "Cooking Classes", "Temple Tours", "Night Markets"]
    }
  ];

  const handleBookCruise = (cruise: any) => {
    setSelectedCruise(cruise);
    setIsBookingOpen(true);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Cruise Bookings - TravelEase",
    "description": "Book amazing cruise vacations to destinations worldwide"
  };

  return (
    <>
      <SEOHead 
        title="Cruise Vacations - Book Your Dream Cruise | TravelEase"
        description="Discover amazing cruise deals to the Mediterranean, Caribbean, Alaska and more. Book your perfect cruise vacation today with the best prices."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-blue-500/10 to-cyan-500/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                Cruise Vacations
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Set sail on unforgettable adventures to stunning destinations around the world. Find the perfect cruise for your next vacation.
              </p>
              
              {/* Search Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-3xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Destination"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      className="pl-10"
                    />
                  </div>
                  <Button size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-600">
                    Search Cruises
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Cruises Grid */}
          <section className="py-16 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">Featured Cruise Deals</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {cruises.map((cruise) => (
                  <Card key={cruise.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-video bg-muted relative">
                      <img 
                        src={cruise.image} 
                        alt={cruise.name}
                        className="w-full h-full object-cover"
                      />
                      <Badge className="absolute top-4 right-4 bg-blue-600">
                        {cruise.duration}
                      </Badge>
                      {cruise.original_price !== cruise.price && (
                        <Badge className="absolute top-4 left-4 bg-red-500">
                          Save ${parseInt(cruise.original_price.replace('$', '').replace(',', '')) - parseInt(cruise.price.replace('$', '').replace(',', ''))}
                        </Badge>
                      )}
                    </div>
                    <CardHeader>
                      <CardTitle className="flex justify-between items-start">
                        <div>
                          <div>{cruise.name}</div>
                          <div className="text-sm font-normal text-muted-foreground">{cruise.cruise_line}</div>
                          <div className="text-sm font-normal text-muted-foreground">{cruise.ship}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">{cruise.price}</div>
                          {cruise.original_price !== cruise.price && (
                            <div className="text-sm text-muted-foreground line-through">{cruise.original_price}</div>
                          )}
                          <div className="text-sm text-muted-foreground">per person</div>
                        </div>
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{cruise.rating}</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4">
                        <div className="flex items-center text-sm mb-2">
                          <Anchor className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="font-medium">Ports:</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mb-3">
                          {cruise.ports.map((port) => (
                            <Badge key={port} variant="secondary" className="text-xs">
                              {port}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <div className="flex items-center text-sm mb-2">
                          <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="font-medium">Departure:</span> {new Date(cruise.departure_date).toLocaleDateString()}
                        </div>
                      </div>

                      <div className="mb-4">
                        <h4 className="font-semibold mb-2">Includes:</h4>
                        <div className="flex flex-wrap gap-1">
                          {cruise.features.map((feature) => (
                            <Badge key={feature} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full bg-gradient-to-r from-blue-600 to-cyan-600" 
                        onClick={() => handleBookCruise(cruise)}
                      >
                        Book This Cruise
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
        
        {selectedCruise && (
          <BookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            bookingType="cruise"
            title={selectedCruise.name}
            price={selectedCruise.price}
            location={selectedCruise.destination}
          />
        )}
      </div>
    </>
  );
};

export default Cruises;