import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { PopularDestinations } from "@/components/PopularDestinations";
import { SEOHead } from "@/components/SEOHead";

const Destinations = () => {
  return (
    <>
      <SEOHead 
        title="Top Travel Destinations 2024 | Best Places to Visit"
        description="Discover the world's most popular travel destinations. Find luxury accommodations, amazing deals, and unforgettable experiences in top destinations worldwide."
        canonical="https://travelease.com/destinations"
      />
      <div className="min-h-screen">
        <Header />
        <main className="pt-16">
          <PopularDestinations />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Destinations;