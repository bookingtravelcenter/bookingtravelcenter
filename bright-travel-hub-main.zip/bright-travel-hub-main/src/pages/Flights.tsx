import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plane, Calendar, MapPin, Clock, ArrowRight } from "lucide-react";
import { BookingModal } from "@/components/BookingModal";

const Flights = () => {
  const [searchParams] = useSearchParams();
  const [fromCity, setFromCity] = useState("");
  const [toCity, setToCity] = useState("");
  const [selectedFlight, setSelectedFlight] = useState<any>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  // Get search parameters from URL
  const searchDestination = searchParams.get('destination');
  const searchCheckIn = searchParams.get('checkIn');
  const searchGuests = searchParams.get('guests');

  useEffect(() => {
    if (searchDestination) {
      setToCity(searchDestination);
    }
  }, [searchDestination]);

  const flights = [
    {
      id: 1,
      airline: "SkyWings Airlines",
      from: "New York (JFK)",
      to: "London (LHR)",
      departure: "10:30 AM",
      arrival: "11:45 PM",
      duration: "7h 15m",
      price: "$599",
      type: "Direct",
      stops: 0
    },
    {
      id: 2,
      airline: "Ocean Air",
      from: "Los Angeles (LAX)",
      to: "Tokyo (NRT)",
      departure: "2:15 PM",
      arrival: "6:30 PM+1",
      duration: "11h 15m",
      price: "$899",
      type: "Direct",
      stops: 0
    },
    {
      id: 3,
      airline: "Continental Express",
      from: "Miami (MIA)",
      to: "Paris (CDG)",
      departure: "8:45 AM",
      arrival: "2:30 PM+1",
      duration: "9h 45m",
      price: "$649",
      type: "1 Stop",
      stops: 1
    },
    {
      id: 4,
      airline: "Global Wings",
      from: "Chicago (ORD)",
      to: "Barcelona (BCN)",
      departure: "3:20 PM",
      arrival: "9:15 AM+1",
      duration: "8h 55m",
      price: "$579",
      type: "Direct",
      stops: 0
    },
    {
      id: 5,
      airline: "Sky Connect",
      from: "San Francisco (SFO)",
      to: "Amsterdam (AMS)",
      departure: "11:10 PM",
      arrival: "7:45 PM+1",
      duration: "10h 35m",
      price: "$729",
      type: "Direct",
      stops: 0
    },
    {
      id: 6,
      airline: "Euro Air",
      from: "Boston (BOS)",
      to: "Rome (FCO)",
      departure: "6:30 PM",
      arrival: "12:15 PM+1",
      duration: "8h 45m",
      price: "$695",
      type: "1 Stop",
      stops: 1
    },
    {
      id: 7,
      airline: "Pacific Express",
      from: "Seattle (SEA)",
      to: "Sydney (SYD)",
      departure: "1:45 AM",
      arrival: "11:30 AM+2",
      duration: "15h 45m",
      price: "$1,299",
      type: "1 Stop",
      stops: 1
    },
    {
      id: 8,
      airline: "Atlantic Airways",
      from: "Atlanta (ATL)",
      to: "Dubai (DXB)",
      departure: "10:15 PM",
      arrival: "8:45 PM+1",
      duration: "13h 30m",
      price: "$899",
      type: "Direct",
      stops: 0
    },
    {
      id: 9,
      airline: "Northern Skies",
      from: "Denver (DEN)",
      to: "Reykjavik (KEF)",
      departure: "4:25 PM",
      arrival: "5:40 AM+1",
      duration: "6h 15m",
      price: "$459",
      type: "Direct",
      stops: 0
    }
  ];

  const handleBookFlight = (flight: any) => {
    setSelectedFlight(flight);
    setIsBookingOpen(true);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Flights - TravelEase",
    "description": "Find and book the best flight deals worldwide"
  };

  return (
    <>
      <SEOHead 
        title="Flights - Find Best Flight Deals | TravelEase"
        description="Search and book cheap flights worldwide. Compare prices from multiple airlines and find the perfect flight for your journey."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-blue-500/10 to-sky-500/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-sky-600 bg-clip-text text-transparent">
                Find Your Perfect Flight
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Compare prices from hundreds of airlines and find the best deals for your next adventure.
              </p>
              {searchDestination && (
                <div className="mb-6 p-4 bg-primary/10 rounded-lg border border-primary/20">
                  <p className="text-lg font-medium">
                    Showing flights to <span className="text-primary">{searchDestination}</span>
                    {searchCheckIn && <span> for {searchGuests || '2'} guest{searchGuests !== '1' ? 's' : ''}</span>}
                  </p>
                </div>
              )}
              
              {/* Search Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-3xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="relative">
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="From"
                      value={fromCity}
                      onChange={(e) => setFromCity(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="To"
                      value={toCity}
                      onChange={(e) => setToCity(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      className="pl-10"
                    />
                  </div>
                  <Button size="lg" className="md:col-span-1">
                    Search Flights
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Flights List */}
          <section className="py-16 px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">Available Flights</h2>
              <div className="space-y-6">
                {flights.map((flight) => (
                  <Card key={flight.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                        <div>
                          <h3 className="font-semibold text-lg">{flight.airline}</h3>
                          <Badge variant={flight.stops === 0 ? "default" : "secondary"}>
                            {flight.type}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-center">
                          <div className="text-center">
                            <div className="font-bold text-lg">{flight.departure}</div>
                            <div className="text-sm text-muted-foreground">{flight.from}</div>
                          </div>
                          <div className="mx-4">
                            <ArrowRight className="h-6 w-6 text-muted-foreground" />
                            <div className="text-xs text-muted-foreground text-center mt-1">
                              {flight.duration}
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="font-bold text-lg">{flight.arrival}</div>
                            <div className="text-sm text-muted-foreground">{flight.to}</div>
                          </div>
                        </div>
                        
                        <div className="text-center">
                          <div className="text-2xl font-bold text-primary">{flight.price}</div>
                          <div className="text-sm text-muted-foreground">per person</div>
                        </div>
                        
                        <div className="text-center">
                          <Button 
                            className="w-full md:w-auto"
                            onClick={() => handleBookFlight(flight)}
                          >
                            Select Flight
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
        
        {selectedFlight && (
          <BookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            bookingType="flight"
            title={`${selectedFlight.from} → ${selectedFlight.to}`}
            price={selectedFlight.price}
            location={selectedFlight.airline}
          />
        )}
      </div>
    </>
  );
};

export default Flights;