import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Users, Star, Wifi, Car, Utensils, Dumbbell, Waves, Heart, TreePine, Building } from "lucide-react";
import { BookingModal } from "@/components/BookingModal";

const Hotels = () => {
  const [searchParams] = useSearchParams();
  const [searchLocation, setSearchLocation] = useState("");
  const [selectedHotel, setSelectedHotel] = useState<any>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  // Get search parameters from URL if coming from main search
  useEffect(() => {
    const destination = searchParams.get('destination');
    if (destination) {
      setSearchLocation(destination);
    }
  }, [searchParams]);

  const hotels = [
    {
      id: 1,
      name: "Grand Plaza Hotel",
      location: searchLocation || "Downtown, New York",
      rating: 4.8,
      price: "$299",
      image: "/placeholder.svg",
      amenities: ["wifi", "parking", "restaurant", "gym"],
      description: "Luxury hotel in the heart of downtown with stunning city views."
    },
    {
      id: 2,
      name: "Seaside Resort",
      location: searchLocation || "Miami Beach, Florida",
      rating: 4.6,
      price: "$189",
      image: "/placeholder.svg",
      amenities: ["wifi", "restaurant", "gym"],
      description: "Beachfront resort with world-class amenities and ocean views."
    },
    {
      id: 3,
      name: "Mountain Lodge",
      location: searchLocation || "Aspen, Colorado",
      rating: 4.7,
      price: "$349",
      image: "/placeholder.svg",
      amenities: ["wifi", "parking", "restaurant"],
      description: "Cozy mountain retreat perfect for ski enthusiasts."
    },
    {
      id: 4,
      name: "Luxury Ocean Resort & Spa",
      location: searchLocation || "Cancun, Mexico",
      rating: 4.9,
      price: "$449",
      image: "/placeholder.svg",
      amenities: ["pool", "spa", "wifi", "restaurant"],
      description: "Ultimate luxury beachfront resort with world-class spa facilities."
    },
    {
      id: 5,
      name: "Boutique City Hotel",
      location: searchLocation || "Paris, France",
      rating: 4.7,
      price: "$259",
      image: "/placeholder.svg",
      amenities: ["wifi", "gym", "restaurant", "parking"],
      description: "Charming boutique hotel in the heart of the city center."
    },
    {
      id: 6,
      name: "Historic Grand Hotel",
      location: searchLocation || "London, UK",
      rating: 4.8,
      price: "$389",
      image: "/placeholder.svg",
      amenities: ["spa", "restaurant", "wifi", "gym"],
      description: "Historic luxury hotel with modern amenities and classic elegance."
    },
    {
      id: 7,
      name: "Modern Business Hotel",
      location: searchLocation || "Tokyo, Japan",
      rating: 4.5,
      price: "$219",
      image: "/placeholder.svg",
      amenities: ["wifi", "gym", "restaurant"],
      description: "Contemporary hotel perfect for business travelers."
    },
    {
      id: 8,
      name: "Family Resort & Water Park",
      location: searchLocation || "Orlando, Florida",
      rating: 4.6,
      price: "$329",
      image: "/placeholder.svg",
      amenities: ["pool", "restaurant", "wifi"],
      description: "Fun-filled family resort with water park and entertainment."
    },
    {
      id: 9,
      name: "Eco-Friendly Lodge",
      location: searchLocation || "Costa Rica",
      rating: 4.7,
      price: "$199",
      image: "/placeholder.svg",
      amenities: ["wifi", "restaurant"],
      description: "Sustainable lodge surrounded by nature and wildlife."
    },
    {
      id: 10,
      name: "Romantic Getaway Inn",
      location: searchLocation || "Santorini, Greece",
      rating: 4.9,
      price: "$359",
      image: "/placeholder.svg",
      amenities: ["spa", "restaurant", "wifi"],
      description: "Perfect romantic escape with breathtaking sunset views."
    },
    {
      id: 11,
      name: "Budget Comfort Hotel",
      location: searchLocation || "Berlin, Germany",
      rating: 4.2,
      price: "$99",
      image: "/placeholder.svg",
      amenities: ["wifi"],
      description: "Affordable comfort in a great location with essential amenities."
    },
    {
      id: 12,
      name: "Executive Business Suite",
      location: searchLocation || "Singapore",
      rating: 4.6,
      price: "$379",
      image: "/placeholder.svg",
      amenities: ["wifi", "gym", "restaurant"],
      description: "Premium business hotel with executive facilities and services."
    }
  ];

  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case "wifi": return <Wifi className="h-4 w-4" />;
      case "parking": return <Car className="h-4 w-4" />;
      case "restaurant": return <Utensils className="h-4 w-4" />;
      case "gym": return <Dumbbell className="h-4 w-4" />;
      case "pool": return <Waves className="h-4 w-4" />;
      case "spa": return <Heart className="h-4 w-4" />;
      default: return null;
    }
  };

  const handleBookHotel = (hotel: any) => {
    setSelectedHotel(hotel);
    setIsBookingOpen(true);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Hotels - TravelEase",
    "description": "Find and book the perfect hotel for your stay"
  };

  return (
    <>
      <SEOHead 
        title="Hotels - Find Your Perfect Stay | TravelEase"
        description="Discover and book amazing hotels worldwide. From luxury resorts to budget-friendly options, find the perfect accommodation for your trip."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-primary/10 to-secondary/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Find Your Perfect Hotel
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Discover amazing accommodations worldwide, from luxury resorts to cozy boutique hotels.
              </p>
              
              {/* Search Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-2xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Where are you going?"
                      value={searchLocation}
                      onChange={(e) => setSearchLocation(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="2 guests"
                      className="pl-10"
                    />
                  </div>
                </div>
                <Button className="w-full mt-4" size="lg">
                  Search Hotels
                </Button>
              </div>
            </div>
          </section>

          {/* Hotels Grid */}
          <section className="py-16 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">
                {searchLocation ? `Hotels in ${searchLocation}` : 'Featured Hotels'}
              </h2>
              <div className="text-center mb-8">
                <p className="text-muted-foreground">
                  {hotels.length} hotels available
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {hotels.map((hotel) => (
                  <Card key={hotel.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-video bg-muted relative">
                      <img 
                        src={hotel.image} 
                        alt={hotel.name}
                        className="w-full h-full object-cover"
                      />
                      <Badge className="absolute top-4 right-4 bg-primary">
                        <Star className="h-3 w-3 mr-1 fill-current" />
                        {hotel.rating}
                      </Badge>
                    </div>
                    <CardHeader>
                      <CardTitle className="flex justify-between items-start">
                        <span>{hotel.name}</span>
                        <span className="text-2xl font-bold text-primary">{hotel.price}</span>
                      </CardTitle>
                      <CardDescription className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {hotel.location}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{hotel.description}</p>
                      <div className="flex gap-2 mb-4">
                        {hotel.amenities.map((amenity) => (
                          <Badge key={amenity} variant="secondary" className="flex items-center gap-1">
                            {getAmenityIcon(amenity)}
                            <span className="capitalize">{amenity}</span>
                          </Badge>
                        ))}
                      </div>
                      <Button 
                        className="w-full" 
                        onClick={() => handleBookHotel(hotel)}
                      >
                        Book Now
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
        
        {selectedHotel && (
          <BookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            bookingType="hotel"
            title={selectedHotel.name}
            price={selectedHotel.price}
            location={selectedHotel.location}
          />
        )}
      </div>
    </>
  );
};

export default Hotels;