import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { SeasonalTropicalShowcase } from "@/components/SeasonalTropicalShowcase";
import { CategoryTabs } from "@/components/CategoryTabs";
import { PopularDestinations } from "@/components/PopularDestinations";
import { ChatSupport } from "@/components/ChatSupport";
import { SEOHead } from "@/components/SEOHead";
import { SocialProof } from "@/components/SocialProof";
import { Footer } from "@/components/Footer";
import { AffiliateServices } from "@/components/AffiliateServices";
import { ServiceCategories } from "@/components/ServiceCategories";

import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useReferralTracking } from "@/hooks/useReferralTracking";

const Index = () => {
  const navigate = useNavigate();
  useReferralTracking(); // Track referral clicks
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "TravelEase",
    "url": "https://travelease.com",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://travelease.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    },
    "sameAs": [
      "https://facebook.com/travelease",
      "https://twitter.com/travelease",
      "https://instagram.com/travelease"
    ]
  };

  return (
    <>
      <SEOHead 
        structuredData={structuredData}
        canonical="https://travelease.com/"
      />
      <div className="min-h-screen">
        <Header />
        <main>
          <HeroSection />
          <ServiceCategories />
          <AffiliateServices />
          <PopularDestinations />
          <SeasonalTropicalShowcase />
          <CategoryTabs />
          <SocialProof />
        </main>
        <Footer />
        <ChatSupport />
      </div>
    </>
  );
};

export default Index;
