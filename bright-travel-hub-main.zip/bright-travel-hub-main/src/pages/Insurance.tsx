import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Check, AlertTriangle, Plane, Car, Heart } from "lucide-react";

const Insurance = () => {
  const [destination, setDestination] = useState("");
  const [travelDates, setTravelDates] = useState("");
  
  const insurancePlans = [
    {
      id: 1,
      name: "Essential Coverage",
      type: "Basic",
      price: "$45",
      coverage_amount: "$50,000",
      features: [
        "Medical Emergency Coverage",
        "Trip Cancellation",
        "Lost Luggage Protection",
        "24/7 Emergency Assistance",
        "Flight Delay Coverage"
      ],
      popular: false,
      color: "from-green-500 to-green-600"
    },
    {
      id: 2,
      name: "Premium Protection",
      type: "Comprehensive", 
      price: "$89",
      coverage_amount: "$100,000",
      features: [
        "All Essential Coverage",
        "Adventure Sports Coverage",
        "Rental Car Protection",
        "Business Equipment Coverage", 
        "Cancel For Any Reason",
        "Pre-existing Medical Conditions"
      ],
      popular: true,
      color: "from-blue-500 to-blue-600"
    },
    {
      id: 3,
      name: "Elite Coverage",
      type: "Premium",
      price: "$149",
      coverage_amount: "$250,000",
      features: [
        "All Premium Coverage",
        "High-Risk Activities",
        "Luxury Item Protection",
        "Concierge Services",
        "Emergency Evacuation",
        "Political Evacuation",
        "Natural Disaster Protection"
      ],
      popular: false,
      color: "from-purple-500 to-purple-600"
    }
  ];

  const coverageTypes = [
    {
      icon: Heart,
      title: "Medical Emergency",
      description: "Coverage for unexpected medical expenses while traveling abroad",
      amount: "Up to $250,000"
    },
    {
      icon: Plane,
      title: "Trip Cancellation",
      description: "Reimbursement for non-refundable trip costs if you need to cancel",
      amount: "100% of trip cost"
    },
    {
      icon: Shield,
      title: "Lost Luggage",
      description: "Compensation for lost, stolen or damaged luggage and personal items",
      amount: "Up to $2,500"
    },
    {
      icon: Car,
      title: "Rental Car Protection",
      description: "Coverage for rental car damage and liability protection", 
      amount: "Up to $50,000"
    }
  ];

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage", 
    "name": "Travel Insurance - TravelEase",
    "description": "Protect your trip with comprehensive travel insurance coverage"
  };

  return (
    <>
      <SEOHead 
        title="Travel Insurance - Protect Your Trip | TravelEase"
        description="Get comprehensive travel insurance coverage for medical emergencies, trip cancellation, lost luggage and more. Compare plans and get instant quotes."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-blue-500/10 to-purple-500/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Travel Insurance
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Protect your investment and travel with confidence. Get comprehensive coverage for medical emergencies, trip cancellations, and more.
              </p>
              
              {/* Quote Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-3xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input
                    placeholder="Destination"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                  />
                  <Input
                    type="date"
                    value={travelDates}
                    onChange={(e) => setTravelDates(e.target.value)}
                  />
                  <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600">
                    Get Quote
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Coverage Types */}
          <section className="py-16 px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-12 text-center">What's Covered</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {coverageTypes.map((coverage, index) => (
                  <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full flex items-center justify-center mb-4">
                        <coverage.icon className="h-8 w-8 text-blue-600" />
                      </div>
                      <CardTitle className="text-lg">{coverage.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="mb-4">
                        {coverage.description}
                      </CardDescription>
                      <Badge variant="secondary" className="font-semibold">
                        {coverage.amount}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Insurance Plans */}
          <section className="py-16 px-4 bg-muted/50">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold mb-12 text-center">Choose Your Plan</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {insurancePlans.map((plan) => (
                  <Card key={plan.id} className={`relative overflow-hidden hover:shadow-lg transition-shadow ${plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''}`}>
                    {plan.popular && (
                      <Badge className="absolute top-4 right-4 bg-blue-500">
                        Most Popular
                      </Badge>
                    )}
                    <CardHeader className={`bg-gradient-to-r ${plan.color} text-white`}>
                      <CardTitle className="text-center">
                        <div className="text-2xl font-bold">{plan.name}</div>
                        <div className="text-sm opacity-90">{plan.type}</div>
                      </CardTitle>
                      <div className="text-center">
                        <div className="text-4xl font-bold">{plan.price}</div>
                        <div className="text-sm opacity-90">per trip</div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="mb-6">
                        <div className="text-center mb-4">
                          <div className="text-sm text-muted-foreground">Coverage up to</div>
                          <div className="text-2xl font-bold text-primary">{plan.coverage_amount}</div>
                        </div>
                      </div>
                      
                      <ul className="space-y-3 mb-6">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center text-sm">
                            <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      
                      <Button 
                        className={`w-full bg-gradient-to-r ${plan.color}`}
                        size="lg"
                      >
                        Get This Plan
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Why Choose Us */}
          <section className="py-16 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-8">Why Choose Our Travel Insurance?</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Shield className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold">24/7 Support</h3>
                  <p className="text-muted-foreground">
                    Round-the-clock emergency assistance wherever you are in the world
                  </p>
                </div>
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Check className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold">Quick Claims</h3>
                  <p className="text-muted-foreground">
                    Fast and easy claims process with most claims settled within 5 business days
                  </p>
                </div>
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Heart className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-semibold">Trusted Coverage</h3>
                  <p className="text-muted-foreground">
                    Backed by A-rated insurance providers with millions of satisfied customers
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Insurance;