import { PurchaseSuccessPage } from "@/components/PurchaseSuccessPage";
import { SEOHead } from "@/components/SEOHead";

const PurchaseDemo = () => {
  // Demo booking data
  const demoBookingData = {
    confirmationNumber: "TRV123456",
    destination: "Paris, France",
    departureDate: "March 15, 2024",
    returnDate: "March 22, 2024",
    passengers: 2,
    totalAmount: "$1,599",
    bookingType: "flight" as const,
    airline: "Air France",
    flightNumber: "AF 1234"
  };

  return (
    <>
      <SEOHead 
        title="Booking Confirmed - Complete Your Trip | TravelEase"
        description="Your flight booking is confirmed! Discover exclusive offers on hotels, car rentals, and activities to complete your perfect trip."
        canonical="https://travelease.com/purchase-success"
      />
      <PurchaseSuccessPage bookingData={demoBookingData} />
    </>
  );
};

export default PurchaseDemo;