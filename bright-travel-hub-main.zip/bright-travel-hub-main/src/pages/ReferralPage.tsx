import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ReferralDashboard } from "@/components/ReferralDashboard";
import { SEOHead } from "@/components/SEOHead";

const ReferralPage = () => {
  return (
    <>
      <SEOHead 
        title="Referral Program - Earn Money for Travel | TravelEase"
        description="Join our referral program and earn €1 for every friend who books with us. Share your unique link and start earning money for your next trip."
        canonical="https://travelease.com/referrals"
      />
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-12">
          <div className="max-w-6xl mx-auto">
            {/* Page Header */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                🎉 Referral Program
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Earn €1 for every friend who books with us. Share your unique link and start earning money for your next adventure!
              </p>
            </div>

            {/* Referral Dashboard */}
            <ReferralDashboard />
          </div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default ReferralPage;