import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Users, Star, Clock } from "lucide-react";
import { BookingModal } from "@/components/BookingModal";
import adventureToursImage from "@/assets/adventure-tours.jpg";
import cruiseBannerImage from "@/assets/cruise-banner.jpg";
import cityToursImage from "@/assets/city-tours.jpg";
import beachResortImage from "@/assets/beach-resort.jpg";

const Tours = () => {
  const [searchParams] = useSearchParams();
  const [searchLocation, setSearchLocation] = useState("");
  const [selectedTour, setSelectedTour] = useState<any>(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  // Get search parameters from URL
  const searchDestination = searchParams.get('destination');
  const searchCheckIn = searchParams.get('checkIn');
  const searchGuests = searchParams.get('guests');

  useEffect(() => {
    if (searchDestination) {
      setSearchLocation(searchDestination);
    }
  }, [searchDestination]);

  const tours = [
    {
      id: 1,
      name: "Mountain Adventure Tours",
      description: "Epic hiking and climbing experiences in breathtaking mountain landscapes with professional guides",
      location: "Swiss Alps",
      duration: "7 Days",
      groupSize: "8-12 People",
      rating: 4.9,
      reviews: 284,
      price: "$1,299",
      image: adventureToursImage,
      category: "Adventure",
      highlights: ["Professional Guide", "All Equipment", "Mountain Hut Stay", "Helicopter Transfer"]
    },
    {
      id: 2,
      name: "Mediterranean Cruise",
      description: "Luxury cruise through the most beautiful Mediterranean destinations with all-inclusive amenities",
      location: "Mediterranean Sea",
      duration: "10 Days",
      groupSize: "200+ Guests",
      rating: 4.8,
      reviews: 156,
      price: "$2,599",
      image: cruiseBannerImage,
      category: "Luxury",
      highlights: ["All Inclusive", "Shore Excursions", "Premium Dining", "Spa Access"]
    },
    {
      id: 3,
      name: "Cultural City Tours",
      description: "Discover rich history, art, and architecture in Europe's greatest cities with expert local guides",
      location: "European Cities",
      duration: "5 Days",
      groupSize: "15-20 People",
      rating: 4.7,
      reviews: 342,
      price: "$899",
      image: cityToursImage,
      category: "Cultural",
      highlights: ["Expert Guide", "Museum Access", "Local Cuisine", "Walking Tours"]
    },
    {
      id: 4,
      name: "Tropical Paradise Escape",
      description: "Relax and unwind in luxurious beachfront resorts with pristine beaches and crystal-clear waters",
      location: "Maldives",
      duration: "6 Days",
      groupSize: "Any Size",
      rating: 4.9,
      reviews: 198,
      price: "$1,799",
      image: beachResortImage,
      category: "Relaxation",
      highlights: ["Beach Villa", "Spa Access", "Water Sports", "Private Beach"]
    },
    {
      id: 5,
      name: "Safari Adventure",
      description: "Experience the Big Five in their natural habitat with luxury lodge accommodation",
      location: "Kenya Safari",
      duration: "8 Days",
      groupSize: "6-10 People",
      rating: 4.9,
      reviews: 167,
      price: "$2,199",
      image: adventureToursImage,
      category: "Wildlife",
      highlights: ["Game Drives", "Luxury Lodge", "Expert Ranger", "Bush Dinner"]
    },
    {
      id: 6,
      name: "Northern Lights Tour",
      description: "Chase the Aurora Borealis in Iceland with thermal baths and glacier exploration",
      location: "Iceland",
      duration: "4 Days",
      groupSize: "12-16 People",
      rating: 4.6,
      reviews: 89,
      price: "$1,599",
      image: cityToursImage,
      category: "Nature",
      highlights: ["Aurora Hunting", "Blue Lagoon", "Glacier Walk", "Ice Cave"]
    },
    {
      id: 7,
      name: "Ancient Wonders Tour",
      description: "Explore Egypt's most famous archaeological sites with Egyptologist guides",
      location: "Egypt",
      duration: "9 Days",
      groupSize: "20-25 People",
      rating: 4.8,
      reviews: 213,
      price: "$1,899",
      image: beachResortImage,
      category: "Historical",
      highlights: ["Pyramids Access", "Nile Cruise", "Valley of Kings", "Expert Guide"]
    },
    {
      id: 8,
      name: "Amazon Rainforest",
      description: "Deep jungle expedition with indigenous communities and wildlife spotting",
      location: "Amazon Basin",
      duration: "6 Days",
      groupSize: "8-12 People",
      rating: 4.7,
      reviews: 124,
      price: "$1,699",
      image: adventureToursImage,
      category: "Eco-tour",
      highlights: ["Canopy Walk", "Night Safari", "Indigenous Village", "River Cruise"]
    },
    {
      id: 9,
      name: "Himalayan Trekking",
      description: "Challenge yourself with high-altitude trekking in the world's highest mountains",
      location: "Nepal Himalayas",
      duration: "14 Days",
      groupSize: "6-10 People",
      rating: 4.8,
      reviews: 95,
      price: "$2,799",
      image: cruiseBannerImage,
      category: "Adventure",
      highlights: ["Base Camp Trek", "Sherpa Guide", "Tea House Stay", "Mountain Views"]
    }
  ];

  const handleBookTour = (tour: any) => {
    setSelectedTour(tour);
    setIsBookingOpen(true);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Tours & Experiences - TravelEase",
    "description": "Discover amazing tours and experiences worldwide"
  };

  return (
    <>
      <SEOHead 
        title="Tours & Experiences - Book Amazing Adventures | TravelEase"
        description="Explore the world with our curated selection of tours and experiences. From cultural trips to adventure tours, find your perfect travel experience."
        structuredData={structuredData}
      />
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-20">
          {/* Hero Section */}
          <section className="py-16 px-4 bg-gradient-to-br from-green-500/10 to-emerald-500/10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                Unforgettable Tours & Experiences
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                From thrilling adventures to cultural discoveries, find the perfect tour that matches your travel dreams.
              </p>
              {searchDestination && (
                <div className="mb-6 p-4 bg-primary/10 rounded-lg border border-primary/20">
                  <p className="text-lg font-medium">
                    Showing tours in <span className="text-primary">{searchDestination}</span>
                    {searchCheckIn && <span> for {searchGuests || '2'} guest{searchGuests !== '1' ? 's' : ''}</span>}
                  </p>
                </div>
              )}
              
              {/* Search Form */}
              <div className="bg-card rounded-2xl p-6 shadow-lg border max-w-3xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Destination"
                      value={searchLocation}
                      onChange={(e) => setSearchLocation(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      type="date"
                      className="pl-10"
                    />
                  </div>
                  <Button size="lg">
                    Search Tours
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* Tours Grid */}
          <section className="py-16 px-4">
            <div className="max-w-7xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center">Available Tours & Experiences</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {tours.map((tour) => (
                  <Card key={tour.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
                    <div className="relative">
                      <div className="aspect-[4/3] overflow-hidden">
                        <img 
                          src={tour.image} 
                          alt={tour.name}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                      </div>
                      <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground">
                        {tour.category}
                      </Badge>
                      <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm rounded-lg px-3 py-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-semibold">{tour.rating}</span>
                        </div>
                      </div>
                    </div>
                    
                    <CardHeader>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <MapPin className="w-4 h-4" />
                        <span>{tour.location}</span>
                      </div>
                      <CardTitle className="text-xl group-hover:text-primary transition-colors">
                        {tour.name}
                      </CardTitle>
                    </CardHeader>
                    
                    <CardContent>
                      <p className="text-muted-foreground mb-4 text-sm line-clamp-2">
                        {tour.description}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-primary" />
                          <span>{tour.duration}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-primary" />
                          <span>{tour.groupSize}</span>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <div className="flex flex-wrap gap-1">
                          {tour.highlights.slice(0, 3).map((highlight) => (
                            <Badge key={highlight} variant="secondary" className="text-xs">
                              {highlight}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm text-muted-foreground">Starting from</div>
                          <div className="text-2xl font-bold text-primary">{tour.price}</div>
                        </div>
                        <Button 
                          onClick={() => handleBookTour(tour)}
                          className="bg-primary hover:bg-primary/90"
                        >
                          Book Tour
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
        
        {selectedTour && (
          <BookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            bookingType="tour"
            title={selectedTour.name}
            price={selectedTour.price}
            location={selectedTour.location}
          />
        )}
      </div>
    </>
  );
};

export default Tours;