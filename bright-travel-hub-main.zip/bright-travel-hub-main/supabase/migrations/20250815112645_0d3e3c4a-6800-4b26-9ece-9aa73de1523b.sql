-- Create tables for affiliate travel data
CREATE TABLE public.travel_providers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('hotel', 'flight', 'car_rental', 'tour', 'restaurant')),
    api_endpoint TEXT,
    affiliate_id TEXT,
    commission_rate DECIMAL(5,2),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create table for travel inventory/offers
CREATE TABLE public.travel_offers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    provider_id UUID REFERENCES public.travel_providers(id),
    external_id TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('hotel', 'flight', 'car_rental', 'tour', 'restaurant')),
    title TEXT NOT NULL,
    description TEXT,
    location JSONB, -- {city, country, coordinates}
    price_data JSONB, -- {currency, amount, original_price, discount}
    availability_data JSONB, -- {available_dates, capacity, restrictions}
    images JSONB, -- array of image URLs
    amenities JSONB, -- array of amenities/features
    rating DECIMAL(3,2),
    review_count INTEGER DEFAULT 0,
    affiliate_url TEXT,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT now(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(provider_id, external_id)
);

-- Create table for user searches and preferences
CREATE TABLE public.travel_searches (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    search_type TEXT NOT NULL CHECK (search_type IN ('hotel', 'flight', 'car_rental', 'tour', 'restaurant')),
    search_params JSONB NOT NULL, -- {destination, dates, guests, preferences}
    results_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create table for affiliate tracking
CREATE TABLE public.affiliate_clicks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    offer_id UUID REFERENCES public.travel_offers(id),
    provider_id UUID REFERENCES public.travel_providers(id),
    click_timestamp TIMESTAMP WITH TIME ZONE DEFAULT now(),
    user_agent TEXT,
    ip_address INET,
    conversion_tracked BOOLEAN DEFAULT false,
    commission_earned DECIMAL(10,2)
);

-- Enable Row Level Security
ALTER TABLE public.travel_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.travel_offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.travel_searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliate_clicks ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access to travel data
CREATE POLICY "Anyone can view active travel providers" 
ON public.travel_providers 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Anyone can view travel offers" 
ON public.travel_offers 
FOR SELECT 
USING (true);

-- Create policies for user-specific data
CREATE POLICY "Users can view their own searches" 
ON public.travel_searches 
FOR SELECT 
USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can create searches" 
ON public.travel_searches 
FOR INSERT 
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Anyone can create affiliate clicks" 
ON public.affiliate_clicks 
FOR INSERT 
WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX idx_travel_offers_type ON public.travel_offers(type);
CREATE INDEX idx_travel_offers_location ON public.travel_offers USING GIN(location);
CREATE INDEX idx_travel_offers_price ON public.travel_offers USING GIN(price_data);
CREATE INDEX idx_travel_offers_updated ON public.travel_offers(last_updated);
CREATE INDEX idx_affiliate_clicks_offer ON public.affiliate_clicks(offer_id);
CREATE INDEX idx_affiliate_clicks_timestamp ON public.affiliate_clicks(click_timestamp);

-- Enable real-time updates for travel offers
ALTER TABLE public.travel_offers REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.travel_offers;

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_travel_providers_updated_at
    BEFORE UPDATE ON public.travel_providers
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert initial travel providers
INSERT INTO public.travel_providers (name, type, commission_rate, is_active) VALUES
('Booking.com', 'hotel', 4.00, true),
('Expedia', 'hotel', 3.50, true),
('Agoda', 'hotel', 5.00, true),
('Skyscanner', 'flight', 2.00, true),
('Kayak', 'flight', 1.50, true),
('Hertz', 'car_rental', 6.00, true),
('Avis', 'car_rental', 5.50, true),
('GetYourGuide', 'tour', 8.00, true),
('Viator', 'tour', 7.00, true),
('OpenTable', 'restaurant', 3.00, true);