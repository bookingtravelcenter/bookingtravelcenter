-- Fix security issue: Restrict access to sensitive travel provider data
-- Drop the current overly permissive policy
DROP POLICY IF EXISTS "Anyone can view active travel providers" ON public.travel_providers;

-- Create a public view that exposes only non-sensitive provider information
CREATE OR REPLACE VIEW public.travel_providers_public AS
SELECT 
    id,
    name,
    type,
    is_active,
    created_at
FROM public.travel_providers
WHERE is_active = true;

-- Create restrictive policies for the main table
-- Only authenticated users can view sensitive provider data
CREATE POLICY "Authenticated users can view travel providers" 
ON public.travel_providers 
FOR SELECT 
TO authenticated
USING (true);

-- Public access is now only through the public view
-- Grant public access to the view
GRANT SELECT ON public.travel_providers_public TO anon;
GRANT SELECT ON public.travel_providers_public TO authenticated;