-- Drop the existing view that has SECURITY DEFINER
DROP VIEW IF EXISTS public.travel_providers_public;

-- Recreate the view with SECURITY INVOKER (this is the secure default)
-- This ensures the view respects the permissions of the querying user
CREATE VIEW public.travel_providers_public 
WITH (security_invoker = true)
AS 
SELECT 
    id,
    name,
    type,
    is_active,
    created_at
FROM public.travel_providers
WHERE is_active = true;

-- Grant appropriate permissions to the view
-- Allow public (including anonymous users) to read from this view
GRANT SELECT ON public.travel_providers_public TO anon;
GRANT SELECT ON public.travel_providers_public TO authenticated;

-- Add a comment explaining the security approach
COMMENT ON VIEW public.travel_providers_public IS 'Public view of active travel providers. Uses SECURITY INVOKER to respect user permissions. Access is controlled through explicit grants rather than SECURITY DEFINER.';