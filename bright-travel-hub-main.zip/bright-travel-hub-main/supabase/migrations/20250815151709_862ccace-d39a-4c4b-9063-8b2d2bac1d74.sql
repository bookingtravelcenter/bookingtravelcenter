-- Create a user profiles table first (needed for admin role management)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
    email TEXT,
    role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'analyst')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    PRIMARY KEY (id)
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile"
ON public.profiles
FOR SELECT
USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
ON public.profiles
FOR UPDATE
USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
ON public.profiles
FOR INSERT
WITH CHECK (auth.uid() = id);

-- Auto-create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (id, email)
    VALUES (new.id, new.email);
    RETURN new;
END;
$$;

-- Trigger for auto-creating profiles
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to get current user role (security definer to avoid recursion)
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
    SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

-- Now create secure policies for affiliate_clicks table
-- Policy 1: Users can view their own clicks (all data since it's their own)
CREATE POLICY "Users can view own clicks"
ON public.affiliate_clicks
FOR SELECT
USING (
    auth.uid() = user_id 
    AND auth.role() = 'authenticated'
);

-- Policy 2: Admins can view all data for compliance/debugging
CREATE POLICY "Admins can view all clicks"
ON public.affiliate_clicks
FOR SELECT
USING (
    public.get_current_user_role() = 'admin'
);

-- Create a secure analytics function that excludes sensitive data
CREATE OR REPLACE FUNCTION public.get_affiliate_analytics(
    start_date timestamp with time zone default null,
    end_date timestamp with time zone default null
)
RETURNS TABLE (
    provider_id uuid,
    offer_id uuid,
    click_count bigint,
    conversion_count bigint,
    total_commission numeric,
    click_date date
)
LANGUAGE SQL
SECURITY DEFINER
AS $$
    -- Only allow analysts and admins to call this function
    SELECT 
        ac.provider_id,
        ac.offer_id,
        COUNT(*) as click_count,
        COUNT(*) FILTER (WHERE ac.conversion_tracked = true) as conversion_count,
        SUM(ac.commission_earned) as total_commission,
        ac.click_timestamp::date as click_date
    FROM public.affiliate_clicks ac
    WHERE 
        -- Role check
        public.get_current_user_role() IN ('admin', 'analyst')
        -- Date filtering
        AND (start_date IS NULL OR ac.click_timestamp >= start_date)
        AND (end_date IS NULL OR ac.click_timestamp <= end_date)
    GROUP BY ac.provider_id, ac.offer_id, ac.click_timestamp::date
    ORDER BY ac.click_timestamp::date DESC;
$$;

-- Grant execute permission to authenticated users (function will check role internally)
GRANT EXECUTE ON FUNCTION public.get_affiliate_analytics TO authenticated;

-- Add comments for documentation
COMMENT ON TABLE public.affiliate_clicks IS 'Stores affiliate click tracking data with sensitive information protected by RLS. Users can only see their own data, admins can see all.';
COMMENT ON FUNCTION public.get_affiliate_analytics IS 'Secure analytics function that provides aggregated data without exposing sensitive IP addresses or user agents. Only accessible to admins and analysts.';
COMMENT ON POLICY "Users can view own clicks" ON public.affiliate_clicks IS 'Allows users to see only their own click history including all fields since its their data';
COMMENT ON POLICY "Admins can view all clicks" ON public.affiliate_clicks IS 'Allows admins to view all click data for compliance and debugging purposes';