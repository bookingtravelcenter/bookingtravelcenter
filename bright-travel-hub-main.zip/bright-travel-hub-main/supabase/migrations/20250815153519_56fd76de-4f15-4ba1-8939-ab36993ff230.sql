-- Create customer referral system

-- Create referral codes table
CREATE TABLE public.customer_referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  referral_code TEXT UNIQUE NOT NULL,
  total_earnings DECIMAL(10,2) DEFAULT 0.00,
  total_referrals INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id)
);

-- Create referral purchases table
CREATE TABLE public.referral_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  referred_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  referral_code TEXT NOT NULL,
  purchase_amount DECIMAL(10,2) NOT NULL,
  commission_earned DECIMAL(10,2) NOT NULL,
  purchase_type TEXT NOT NULL, -- 'flight', 'hotel', 'car', 'tour'
  purchase_reference TEXT, -- booking confirmation number
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create referral link clicks table
CREATE TABLE public.referral_clicks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referral_code TEXT NOT NULL,
  referrer_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  ip_address INET,
  user_agent TEXT,
  converted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.customer_referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_clicks ENABLE ROW LEVEL SECURITY;

-- RLS Policies for customer_referrals
CREATE POLICY "Users can view their own referral data" 
ON public.customer_referrals 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own referral data" 
ON public.customer_referrals 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own referral data" 
ON public.customer_referrals 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- RLS Policies for referral_purchases
CREATE POLICY "Users can view their own referral earnings" 
ON public.referral_purchases 
FOR SELECT 
USING (auth.uid() = referrer_user_id OR auth.uid() = referred_user_id);

CREATE POLICY "System can create referral purchases" 
ON public.referral_purchases 
FOR INSERT 
WITH CHECK (true);

-- RLS Policies for referral_clicks
CREATE POLICY "Users can view their own referral clicks" 
ON public.referral_clicks 
FOR SELECT 
USING (auth.uid() = referrer_user_id);

CREATE POLICY "Anyone can create referral clicks" 
ON public.referral_clicks 
FOR INSERT 
WITH CHECK (true);

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT AS $$
DECLARE
  code TEXT;
  exists_check BOOLEAN;
BEGIN
  LOOP
    -- Generate 8 character alphanumeric code
    code := upper(substr(md5(random()::text), 1, 8));
    
    -- Check if code already exists
    SELECT EXISTS(SELECT 1 FROM public.customer_referrals WHERE referral_code = code) INTO exists_check;
    
    -- Exit loop if code is unique
    IF NOT exists_check THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create referral code for user
CREATE OR REPLACE FUNCTION public.create_user_referral_code(user_uuid UUID)
RETURNS TEXT AS $$
DECLARE
  new_code TEXT;
BEGIN
  -- Generate unique code
  new_code := public.generate_referral_code();
  
  -- Insert or update referral record
  INSERT INTO public.customer_referrals (user_id, referral_code)
  VALUES (user_uuid, new_code)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    referral_code = EXCLUDED.referral_code,
    updated_at = now();
  
  RETURN new_code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to process referral purchase
CREATE OR REPLACE FUNCTION public.process_referral_purchase(
  p_referral_code TEXT,
  p_referred_user_id UUID,
  p_purchase_amount DECIMAL,
  p_purchase_type TEXT,
  p_purchase_reference TEXT DEFAULT NULL,
  p_ip_address INET DEFAULT NULL,
  p_user_agent TEXT DEFAULT NULL
)
RETURNS BOOLEAN AS $$
DECLARE
  referrer_id UUID;
  commission_amount DECIMAL := 1.00; -- Fixed 1 euro commission
BEGIN
  -- Get referrer user ID
  SELECT user_id INTO referrer_id 
  FROM public.customer_referrals 
  WHERE referral_code = p_referral_code AND is_active = true;
  
  -- Return false if referral code not found
  IF referrer_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Don't allow self-referrals
  IF referrer_id = p_referred_user_id THEN
    RETURN false;
  END IF;
  
  -- Record the referral purchase
  INSERT INTO public.referral_purchases (
    referrer_user_id,
    referred_user_id,
    referral_code,
    purchase_amount,
    commission_earned,
    purchase_type,
    purchase_reference,
    ip_address,
    user_agent
  ) VALUES (
    referrer_id,
    p_referred_user_id,
    p_referral_code,
    p_purchase_amount,
    commission_amount,
    p_purchase_type,
    p_purchase_reference,
    p_ip_address,
    p_user_agent
  );
  
  -- Update referrer's total earnings and referral count
  UPDATE public.customer_referrals 
  SET 
    total_earnings = total_earnings + commission_amount,
    total_referrals = total_referrals + 1,
    updated_at = now()
  WHERE user_id = referrer_id;
  
  -- Mark any related clicks as converted
  UPDATE public.referral_clicks 
  SET converted = true 
  WHERE referral_code = p_referral_code 
    AND created_at >= now() - INTERVAL '30 days'
    AND converted = false;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create indexes for better performance
CREATE INDEX idx_customer_referrals_code ON public.customer_referrals(referral_code);
CREATE INDEX idx_customer_referrals_user ON public.customer_referrals(user_id);
CREATE INDEX idx_referral_purchases_referrer ON public.referral_purchases(referrer_user_id);
CREATE INDEX idx_referral_purchases_code ON public.referral_purchases(referral_code);
CREATE INDEX idx_referral_clicks_code ON public.referral_clicks(referral_code);

-- Create updated_at trigger for customer_referrals
CREATE TRIGGER update_customer_referrals_updated_at
  BEFORE UPDATE ON public.customer_referrals
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();