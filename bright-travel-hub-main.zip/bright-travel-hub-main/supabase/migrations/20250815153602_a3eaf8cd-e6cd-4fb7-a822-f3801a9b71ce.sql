-- Fix security warnings by setting proper search paths for functions

-- Update generate_referral_code function with secure search path
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  code TEXT;
  exists_check BOOLEAN;
BEGIN
  LOOP
    -- Generate 8 character alphanumeric code
    code := upper(substr(md5(random()::text), 1, 8));
    
    -- Check if code already exists
    SELECT EXISTS(SELECT 1 FROM public.customer_referrals WHERE referral_code = code) INTO exists_check;
    
    -- Exit loop if code is unique
    IF NOT exists_check THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN code;
END;
$$;

-- Update create_user_referral_code function with secure search path
CREATE OR REPLACE FUNCTION public.create_user_referral_code(user_uuid UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_code TEXT;
BEGIN
  -- Generate unique code
  new_code := public.generate_referral_code();
  
  -- Insert or update referral record
  INSERT INTO public.customer_referrals (user_id, referral_code)
  VALUES (user_uuid, new_code)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    referral_code = EXCLUDED.referral_code,
    updated_at = now();
  
  RETURN new_code;
END;
$$;

-- Update process_referral_purchase function with secure search path
CREATE OR REPLACE FUNCTION public.process_referral_purchase(
  p_referral_code TEXT,
  p_referred_user_id UUID,
  p_purchase_amount DECIMAL,
  p_purchase_type TEXT,
  p_purchase_reference TEXT DEFAULT NULL,
  p_ip_address INET DEFAULT NULL,
  p_user_agent TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_id UUID;
  commission_amount DECIMAL := 1.00; -- Fixed 1 euro commission
BEGIN
  -- Get referrer user ID
  SELECT user_id INTO referrer_id 
  FROM public.customer_referrals 
  WHERE referral_code = p_referral_code AND is_active = true;
  
  -- Return false if referral code not found
  IF referrer_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Don't allow self-referrals
  IF referrer_id = p_referred_user_id THEN
    RETURN false;
  END IF;
  
  -- Record the referral purchase
  INSERT INTO public.referral_purchases (
    referrer_user_id,
    referred_user_id,
    referral_code,
    purchase_amount,
    commission_earned,
    purchase_type,
    purchase_reference,
    ip_address,
    user_agent
  ) VALUES (
    referrer_id,
    p_referred_user_id,
    p_referral_code,
    p_purchase_amount,
    commission_amount,
    p_purchase_type,
    p_purchase_reference,
    p_ip_address,
    p_user_agent
  );
  
  -- Update referrer's total earnings and referral count
  UPDATE public.customer_referrals 
  SET 
    total_earnings = total_earnings + commission_amount,
    total_referrals = total_referrals + 1,
    updated_at = now()
  WHERE user_id = referrer_id;
  
  -- Mark any related clicks as converted
  UPDATE public.referral_clicks 
  SET converted = true 
  WHERE referral_code = p_referral_code 
    AND created_at >= now() - INTERVAL '30 days'
    AND converted = false;
  
  RETURN true;
END;
$$;

-- Update RLS policies to be more restrictive (authenticated users only)
DROP POLICY IF EXISTS "Users can view their own referral data" ON public.customer_referrals;
DROP POLICY IF EXISTS "Users can update their own referral data" ON public.customer_referrals;
DROP POLICY IF EXISTS "Users can insert their own referral data" ON public.customer_referrals;

CREATE POLICY "Authenticated users can view their own referral data" 
ON public.customer_referrals 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can update their own referral data" 
ON public.customer_referrals 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can insert their own referral data" 
ON public.customer_referrals 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Update other RLS policies to be authenticated only
DROP POLICY IF EXISTS "Users can view their own referral earnings" ON public.referral_purchases;
CREATE POLICY "Authenticated users can view their own referral earnings" 
ON public.referral_purchases 
FOR SELECT 
TO authenticated
USING (auth.uid() = referrer_user_id OR auth.uid() = referred_user_id);

DROP POLICY IF EXISTS "Users can view their own referral clicks" ON public.referral_clicks;
CREATE POLICY "Authenticated users can view their own referral clicks" 
ON public.referral_clicks 
FOR SELECT 
TO authenticated
USING (auth.uid() = referrer_user_id);