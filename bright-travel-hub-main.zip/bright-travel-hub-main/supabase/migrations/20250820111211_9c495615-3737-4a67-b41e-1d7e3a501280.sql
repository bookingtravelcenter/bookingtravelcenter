-- Create referral system tables
CREATE TABLE public.customer_referrals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  referral_code TEXT NOT NULL UNIQUE,
  total_referrals INTEGER DEFAULT 0,
  total_earnings DECIMAL(10,2) DEFAULT 0,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE public.referral_clicks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referral_code TEXT NOT NULL,
  referrer_user_id UUID,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE public.referral_purchases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referral_code TEXT NOT NULL,
  referrer_user_id UUID,
  customer_user_id UUID,
  purchase_amount DECIMAL(10,2) NOT NULL,
  commission_amount DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'paid')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.customer_referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_clicks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_purchases ENABLE ROW LEVEL SECURITY;

-- RLS Policies for customer_referrals
CREATE POLICY "Users can view their own referrals" 
ON public.customer_referrals 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own referrals" 
ON public.customer_referrals 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own referrals" 
ON public.customer_referrals 
FOR UPDATE 
USING (auth.uid() = user_id);

-- RLS Policies for referral_clicks (public read for tracking)
CREATE POLICY "Anyone can insert referral clicks" 
ON public.referral_clicks 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can view clicks for their referrals" 
ON public.referral_clicks 
FOR SELECT 
USING (auth.uid() = referrer_user_id);

-- RLS Policies for referral_purchases
CREATE POLICY "Users can view their referral purchases" 
ON public.referral_purchases 
FOR SELECT 
USING (auth.uid() = referrer_user_id OR auth.uid() = customer_user_id);

CREATE POLICY "System can insert referral purchases" 
ON public.referral_purchases 
FOR INSERT 
WITH CHECK (true);

-- Create functions
CREATE OR REPLACE FUNCTION public.create_user_referral_code(user_id UUID)
RETURNS TEXT AS $$
DECLARE
  code TEXT;
BEGIN
  -- Generate a unique referral code
  code := 'REF' || UPPER(SUBSTRING(MD5(user_id::TEXT || NOW()::TEXT) FROM 1 FOR 8));
  
  -- Insert or update the referral record
  INSERT INTO public.customer_referrals (user_id, referral_code)
  VALUES (user_id, code)
  ON CONFLICT (user_id) DO UPDATE SET referral_code = code;
  
  RETURN code;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.process_referral_purchase(
  referral_code TEXT,
  customer_id UUID,
  amount DECIMAL
)
RETURNS BOOLEAN AS $$
DECLARE
  referrer_id UUID;
  commission DECIMAL;
BEGIN
  -- Find the referrer
  SELECT user_id INTO referrer_id 
  FROM public.customer_referrals 
  WHERE referral_code = process_referral_purchase.referral_code;
  
  IF referrer_id IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Calculate commission (5%)
  commission := amount * 0.05;
  
  -- Insert referral purchase
  INSERT INTO public.referral_purchases (
    referral_code, 
    referrer_user_id, 
    customer_user_id, 
    purchase_amount, 
    commission_amount
  ) VALUES (
    process_referral_purchase.referral_code,
    referrer_id,
    customer_id,
    amount,
    commission
  );
  
  -- Update referrer stats
  UPDATE public.customer_referrals 
  SET 
    total_referrals = total_referrals + 1,
    total_earnings = total_earnings + commission,
    updated_at = now()
  WHERE user_id = referrer_id;
  
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;